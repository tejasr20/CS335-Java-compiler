Tests folder for project with example java files 
