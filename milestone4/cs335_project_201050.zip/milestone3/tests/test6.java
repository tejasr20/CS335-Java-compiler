public class test6 {
    public static void main(String[] args) {
        int num1 = 5;
        int num2 = 3;
        int sum = num1 + num2;
        int diff = num1 - num2;
        int mult = num1 * num2;
        int div = mult/num2;
        if(num1==div){
            System.out.println(sum);
        }
        else{
            System.out.println(diff);
        }
        
    }
}
