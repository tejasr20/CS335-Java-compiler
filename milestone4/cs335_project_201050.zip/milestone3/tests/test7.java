public class test7
{	
	
    
	
	public static void main(String[] args)
	{	int x = 3;
		int y = 2;
		System.out.println("In method go. x: " + x + " y: " + y);
		
		System.out.println("in method go. x: " + x + " y: " + y);
		System.out.println("in method go. x: " + x + " y: " + y);
        System.out.println("in method falseSwap. x: " + x + " y: " + y);
		int temp = x;
		x = y;
		y = temp;
		System.out.println("in method falseSwap. x: " + x + " y: " + y);
	}
	


}