// class Laptop {
// 	Laptop() {
// 	  System.out.println("Constructor of Laptop class.");
// 	}
	
// 	void laptop_method() {
// 	  System.out.println("99% Battery available.");
// 	}
//   }

// class Computer {
//   Computer() {
//     System.out.println("Constructor of Computer class.");
//   }
  
// //   void computer_method() {
// //     System.out.println("Power gone! Shut down your PC soon...");
// //   }
  
// //   public static void main(String[] args) {
// //     Computer my = new Computer();
// //     // Laptop your = new Laptop();
    
// //     my.computer_method();
// //     // your.laptop_method();
//   }

// public class MatrixAdditionExample{  
// 	public static void main(String args[]){  
// 	//creating two matrices    
// 	// int a[][]={{1,3,4,4},{2,4,3},{3,4,5}};    
// 	// int b[][]={{1,3,4},{2,4,3},{1,2,4}};    
// 	int d[]=new int[3];  //3 rows and 3 columns
// 	d[2]=7;     
// 	int c[][]=new int[3][4];  //3 rows and 3 columns
// 	c[2][3]=1;     
// 	d[1]= c[1][2];
// 	}}

class Employee{  
    // int id;  
    // String name;  
    // float salary;  
    // // void insert(int i, String n, float s) {  
    // //     id=i;  
    // //     name=n;  
    // //     salary=s;  
    // // }  
	// Employee()
	// {
		
	// }
    // void display(){}  
}  
public class TestEmployee {  

	// TestEmployee(int a)
	// {
		
	// }
public static void main(String[] args) {  
    // TestEmployee e1=new TestEmployee(4);  
    // Employee e2=new Employee();  
    // Employee e3=new Employee();  
    // e1.insert(101,"ajeet",45000);  
    // e2.insert(102,"irfan",25000);  
    // e3.insert(103,"nakul",55000);  
    // e1.display();  
    // e2.display();  
    // e3.display();  
}  
}