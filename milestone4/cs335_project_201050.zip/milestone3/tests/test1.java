// public class test1 {
//     public static int factorial(int n) {
// 		n=2;
//         return n == 0 ? 1 : n * factorial(n - 1);
//     }

//     public static void main(String[] args) {
//         int n = 5;
//         // int result = factorial(n);
//         // System.out.println(result);
//     } 
// }
public class test1 {
  public void fullThrottle(int n) {
    System.out.println("The car is going as fast as it can!");
  }

  public void speed(int maxSpeed) {
    System.out.println("Max speed is: " + maxSpeed);

    fullThrottle(2);      // Call the fullThrottle() method

  }
}
