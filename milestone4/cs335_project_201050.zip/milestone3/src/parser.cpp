/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     ABSTRACT = 258,
     ASSERT = 259,
     BOOLEAN = 260,
     BREAK = 261,
     BYTE = 262,
     CASE = 263,
     CATCH = 264,
     CHAR = 265,
     CLASS = 266,
     COMMENT = 267,
     CONST = 268,
     CONTINUE = 269,
     DEFAULT = 270,
     DO = 271,
     DOUBLE = 272,
     ELSE = 273,
     ENUM = 274,
     ERROR = 275,
     EXTENDS = 276,
     FINALLY = 277,
     FINAL = 278,
     FLOAT = 279,
     FOR = 280,
     IDENTIFIER = 281,
     IF = 282,
     GOTO = 283,
     IMPLEMENTS = 284,
     IMPORT = 285,
     INSTANCEOF = 286,
     INT = 287,
     INTERFACE = 288,
     LITERAL = 289,
     LONG = 290,
     NATIVE = 291,
     NEW = 292,
     PACKAGE = 293,
     PRIVATE = 294,
     PROTECTED = 295,
     PUBLIC = 296,
     RETURN = 297,
     SHORT = 298,
     STATIC = 299,
     STRICTFP = 300,
     SUPER = 301,
     SWITCH = 302,
     SYNCHRONIZED = 303,
     THIS = 304,
     THROWS = 305,
     THROW = 306,
     TRANSIENT = 307,
     TRY = 308,
     VOID = 309,
     VOLATILE = 310,
     WHILE = 311,
     EQUALS = 312,
     GT = 313,
     LT = 314,
     NT = 315,
     TILDA = 316,
     QUESTION_MARK = 317,
     COLON = 318,
     ARROW = 319,
     EQEQ = 320,
     GREQ = 321,
     LEQ = 322,
     NEQUALS = 323,
     PLUSPLUS = 324,
     MINUSMINUS = 325,
     OR = 326,
     AND = 327,
     ADD = 328,
     SUBTRACT = 329,
     MULTIPLY = 330,
     DIVISION = 331,
     BINARYOR = 332,
     BINARYAND = 333,
     POW = 334,
     MOD = 335,
     GRGR = 336,
     LTLT = 337,
     GRGRGR = 338,
     PLEQ = 339,
     SBEQ = 340,
     MULEQ = 341,
     ANDEQ = 342,
     OREQ = 343,
     POWEQ = 344,
     DIVEQ = 345,
     MODEQ = 346,
     DGRGR = 347,
     DLRLR = 348,
     TGRGRGR = 349,
     OC = 350,
     CC = 351,
     OSQ = 352,
     CSQ = 353,
     OS = 354,
     CS = 355,
     COMMA = 356,
     DISTO = 357,
     ATR = 358,
     TDT = 359,
     FST = 360,
     SCLN = 361,
     DST = 362,
     STRING_LITERAL = 363,
     STRING = 364,
     CONST_LITERAL = 365
   };
#endif
/* Tokens.  */
#define ABSTRACT 258
#define ASSERT 259
#define BOOLEAN 260
#define BREAK 261
#define BYTE 262
#define CASE 263
#define CATCH 264
#define CHAR 265
#define CLASS 266
#define COMMENT 267
#define CONST 268
#define CONTINUE 269
#define DEFAULT 270
#define DO 271
#define DOUBLE 272
#define ELSE 273
#define ENUM 274
#define ERROR 275
#define EXTENDS 276
#define FINALLY 277
#define FINAL 278
#define FLOAT 279
#define FOR 280
#define IDENTIFIER 281
#define IF 282
#define GOTO 283
#define IMPLEMENTS 284
#define IMPORT 285
#define INSTANCEOF 286
#define INT 287
#define INTERFACE 288
#define LITERAL 289
#define LONG 290
#define NATIVE 291
#define NEW 292
#define PACKAGE 293
#define PRIVATE 294
#define PROTECTED 295
#define PUBLIC 296
#define RETURN 297
#define SHORT 298
#define STATIC 299
#define STRICTFP 300
#define SUPER 301
#define SWITCH 302
#define SYNCHRONIZED 303
#define THIS 304
#define THROWS 305
#define THROW 306
#define TRANSIENT 307
#define TRY 308
#define VOID 309
#define VOLATILE 310
#define WHILE 311
#define EQUALS 312
#define GT 313
#define LT 314
#define NT 315
#define TILDA 316
#define QUESTION_MARK 317
#define COLON 318
#define ARROW 319
#define EQEQ 320
#define GREQ 321
#define LEQ 322
#define NEQUALS 323
#define PLUSPLUS 324
#define MINUSMINUS 325
#define OR 326
#define AND 327
#define ADD 328
#define SUBTRACT 329
#define MULTIPLY 330
#define DIVISION 331
#define BINARYOR 332
#define BINARYAND 333
#define POW 334
#define MOD 335
#define GRGR 336
#define LTLT 337
#define GRGRGR 338
#define PLEQ 339
#define SBEQ 340
#define MULEQ 341
#define ANDEQ 342
#define OREQ 343
#define POWEQ 344
#define DIVEQ 345
#define MODEQ 346
#define DGRGR 347
#define DLRLR 348
#define TGRGRGR 349
#define OC 350
#define CC 351
#define OSQ 352
#define CSQ 353
#define OS 354
#define CS 355
#define COMMA 356
#define DISTO 357
#define ATR 358
#define TDT 359
#define FST 360
#define SCLN 361
#define DST 362
#define STRING_LITERAL 363
#define STRING 364
#define CONST_LITERAL 365




/* Copy the first part of user declarations.  */
#line 1 "parser.y"

#include<bits/stdc++.h>
#include<math.h>
#include<iostream>
#include<algorithm>
#include <stdio.h>
#include <string>
#include <vector>
#include <unordered_map>
#include "tree.h"
#include "symbol_table.h"
#include "typecheck.h"
#include "3ac.h"
set<string> is_static;
using namespace std;
extern int yylineno;
extern FILE* yyin;
FILE* fp;
extern char* yytext;
extern int column;
string special_type;
extern vector<quad> code;
int constructor_num=1;
int yyerror(const char*);
extern int yylex();
extern int yyparse();
bool verbose= false;
int interrupt_compiler = 0;
FILE* dotfile;
char* file;
char* curr_file;

bool fn_decl = 0;
int func_flag = 0;
int dump_tac = 0;
int dump_sym_table = 0;
int only_lexer = 0;
int block_count = 0;
int if_found = 0;
int previous_if_found = 0;
int stop_compiler = 0;		// shows error while parsing
int isArray = 0;			// true when array is declared
int type_delim = 0;	
int debug_mode = 0;	
int param_size= 0;
int func_size= 0;
int field_size= 0;

string funcName = ""; // global variables. 
string className= "";
string structName = "";
string classType= "";
string structTemp ="";
string funcType = "";
string type = "";
string storage_class = "";
string constructor_temporary="";
stack<int> block_stack;
vector<string> varlist;

int Anon_StructCounter=0;
vector<string> funcArgs;
vector<sym_entry*> args;
vector<string> idList;
vector<string> currArgs;

vector<string> classNamelist;
vector<qid> initializer_list_values;
vector<int> array_dims;
map<string, vector<int> > arr_dimensions;
map<string, int > arr_index;
map<string, vector<int> > gotolablelist;
map<string, int> gotolabel;
map<string, int> func_usage_map;
map<string, vector<qid>> global_array_init_map;
// vector<string, 

extern int yyrestart(FILE*);
int warning(const char* s) ;
extern FILE* yyin;
#define YYERROR_VERBOSE


/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 84 "parser.y"
{
	char* str;
	int number;
	Node* ptr;
	constants* num;
}
/* Line 193 of yacc.c.  */
#line 406 "parser.cpp"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 216 of yacc.c.  */
#line 419 "parser.cpp"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  38
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   3820

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  112
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  158
/* YYNRULES -- Number of rules.  */
#define YYNRULES  367
/* YYNRULES -- Number of states.  */
#define YYNSTATES  723

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   365

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,   111,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     105,   106,   107,   108,   109,   110
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     5,     7,     9,    11,    13,    15,    17,
      19,    21,    23,    25,    27,    29,    31,    33,    35,    37,
      39,    41,    43,    45,    47,    51,    55,    59,    61,    63,
      65,    69,    73,    75,    78,    80,    82,    85,    88,    90,
      93,    95,    98,   102,   104,   106,   110,   115,   117,   119,
     121,   123,   126,   128,   130,   132,   134,   136,   138,   140,
     142,   144,   146,   154,   160,   167,   173,   179,   184,   191,
     198,   199,   201,   204,   207,   209,   213,   216,   221,   223,
     227,   229,   231,   233,   235,   237,   242,   246,   248,   253,
     255,   260,   262,   266,   268,   270,   274,   275,   280,   284,
     287,   292,   296,   300,   303,   307,   309,   316,   321,   325,
     326,   328,   333,   336,   339,   341,   345,   347,   349,   352,
     358,   363,   367,   372,   374,   381,   386,   391,   394,   398,
     402,   408,   413,   419,   424,   431,   437,   442,   448,   450,
     451,   454,   458,   461,   466,   468,   471,   473,   475,   477,
     480,   485,   489,   492,   496,   501,   503,   508,   511,   512,
     515,   517,   519,   521,   524,   527,   529,   531,   533,   535,
     537,   539,   541,   543,   545,   547,   549,   551,   553,   555,
     557,   559,   561,   563,   565,   567,   569,   571,   573,   577,
     581,   584,   586,   588,   590,   592,   594,   596,   598,   602,
     610,   618,   619,   625,   631,   636,   639,   643,   647,   649,
     652,   654,   657,   660,   664,   667,   675,   681,   691,   693,
     695,   709,   720,   728,   736,   743,   752,   761,   769,   783,
     792,   801,   809,   820,   828,   836,   843,   844,   847,   848,
     850,   852,   854,   859,   861,   865,   868,   872,   875,   878,
     882,   886,   892,   896,   900,   905,   908,   910,   916,   919,
     921,   923,   925,   929,   931,   933,   935,   937,   939,   945,
     950,   952,   956,   960,   964,   969,   974,   979,   983,   990,
     996,  1003,  1009,  1014,  1018,  1023,  1027,  1030,  1032,  1036,
    1039,  1043,  1045,  1047,  1049,  1050,  1055,  1057,  1059,  1061,
    1063,  1065,  1067,  1069,  1071,  1073,  1075,  1077,  1079,  1081,
    1083,  1085,  1087,  1095,  1098,  1099,  1101,  1105,  1108,  1110,
    1114,  1117,  1118,  1120,  1124,  1126,  1130,  1132,  1136,  1138,
    1142,  1146,  1148,  1152,  1156,  1160,  1164,  1168,  1170,  1174,
    1176,  1180,  1184,  1186,  1190,  1194,  1198,  1200,  1202,  1205,
    1208,  1210,  1213,  1216,  1219,  1222,  1224,  1226,  1228,  1230,
    1232,  1234,  1237,  1240,  1246,  1251,  1256,  1262
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
     128,     0,    -1,   110,    -1,   108,    -1,    26,    -1,   116,
      -1,   118,    -1,   124,    -1,   117,    -1,   125,    -1,   119,
      -1,     5,    -1,   121,    -1,   120,    -1,    35,    -1,     7,
      -1,    32,    -1,    10,    -1,    43,    -1,   109,    -1,    17,
      -1,    24,    -1,   117,    -1,   117,    -1,   118,    97,    98,
      -1,   124,    97,    98,    -1,   125,    97,    98,    -1,   127,
      -1,   126,    -1,   114,    -1,   125,   105,    26,    -1,   131,
     129,   130,    -1,   130,    -1,   131,   129,    -1,   129,    -1,
     131,    -1,   129,   130,    -1,   131,   130,    -1,   132,    -1,
     129,   132,    -1,   135,    -1,   130,   135,    -1,    38,   125,
     106,    -1,   134,    -1,   133,    -1,    30,   125,   106,    -1,
      30,   125,   107,   106,    -1,   170,    -1,   106,    -1,   138,
      -1,   137,    -1,   136,   137,    -1,    23,    -1,    39,    -1,
      40,    -1,    36,    -1,    48,    -1,    44,    -1,    41,    -1,
      52,    -1,     3,    -1,    55,    -1,   136,    11,   140,   141,
     142,   139,   144,    -1,    11,   140,   142,   139,   144,    -1,
     136,    11,   140,   141,   139,   144,    -1,    11,   140,   141,
     139,   144,    -1,   136,    11,   140,   139,   144,    -1,    11,
     140,   139,   144,    -1,    11,   140,   141,   142,   139,   144,
      -1,   136,    11,   140,   142,   139,   144,    -1,    -1,    26,
      -1,    21,   122,    -1,    29,   143,    -1,   123,    -1,   143,
     101,   123,    -1,    95,    96,    -1,    95,   182,   145,    96,
      -1,   146,    -1,   145,   252,   146,    -1,   165,    -1,   164,
      -1,   147,    -1,   153,    -1,   148,    -1,   136,   115,   149,
     106,    -1,   115,   149,   106,    -1,   150,    -1,   149,   101,
     252,   150,    -1,   151,    -1,   151,    57,   252,   152,    -1,
      26,    -1,   151,    97,    98,    -1,   239,    -1,   179,    -1,
     155,   154,   163,    -1,    -1,   136,   115,   157,   161,    -1,
     115,   157,   161,    -1,   115,   157,    -1,   136,    54,   157,
     161,    -1,    54,   157,   161,    -1,   136,    54,   157,    -1,
      54,   157,    -1,   136,   115,   157,    -1,    26,    -1,   156,
      99,   158,   159,   100,   252,    -1,   156,    99,   158,   100,
      -1,   157,    97,    97,    -1,    -1,   160,    -1,   159,   101,
     252,   160,    -1,   115,   151,    -1,    50,   162,    -1,   122,
      -1,   162,   101,   122,    -1,   106,    -1,   181,    -1,    44,
     181,    -1,   136,   167,   161,   154,   168,    -1,   136,   167,
     154,   168,    -1,   167,   154,   168,    -1,   167,   161,   154,
     168,    -1,    26,    -1,   166,    99,   158,   159,   100,   252,
      -1,   166,    99,   158,   100,    -1,    95,   169,   183,    96,
      -1,    95,    96,    -1,    95,   169,    96,    -1,    95,   183,
      96,    -1,    49,    99,   231,   100,   106,    -1,    49,    99,
     100,   106,    -1,    46,    99,   231,   100,   106,    -1,    46,
      99,   100,   106,    -1,   136,    33,   171,   173,   172,   174,
      -1,   136,    33,   171,   172,   174,    -1,    33,   171,   172,
     174,    -1,    33,   171,   173,   172,   174,    -1,    26,    -1,
      -1,    21,   123,    -1,   173,   101,   123,    -1,    95,    96,
      -1,    95,   182,   175,    96,    -1,   176,    -1,   175,   176,
      -1,   177,    -1,   178,    -1,   148,    -1,   155,   106,    -1,
      95,   180,   101,    96,    -1,    95,   180,    96,    -1,    95,
      96,    -1,    95,   101,    96,    -1,   180,   101,   252,   152,
      -1,   152,    -1,    95,   182,   183,    96,    -1,    95,    96,
      -1,    -1,   183,   184,    -1,   184,    -1,   185,    -1,   187,
      -1,   186,   106,    -1,   115,   149,    -1,   206,    -1,   189,
      -1,   209,    -1,   191,    -1,   195,    -1,   196,    -1,   207,
      -1,   192,    -1,   189,    -1,   197,    -1,   210,    -1,   224,
      -1,   208,    -1,   219,    -1,   193,    -1,   222,    -1,   200,
      -1,   220,    -1,   181,    -1,   190,    -1,   221,    -1,   223,
      -1,   106,    -1,    26,    63,   187,    -1,    26,    63,   188,
      -1,   194,   106,    -1,   230,    -1,   267,    -1,   263,    -1,
     234,    -1,   266,    -1,   262,    -1,   241,    -1,   198,   252,
     187,    -1,   198,   252,   188,   215,    18,   252,   187,    -1,
     198,   252,   188,   215,    18,   252,   188,    -1,    -1,    27,
     199,    99,   239,   100,    -1,    47,    99,   239,   100,   201,
      -1,    95,   202,   203,    96,    -1,    95,    96,    -1,    95,
     202,    96,    -1,    95,   203,    96,    -1,   204,    -1,   202,
     204,    -1,   205,    -1,   203,   205,    -1,   203,   183,    -1,
       8,   269,    63,    -1,    15,    63,    -1,    56,    99,   252,
     213,   100,   252,   187,    -1,    56,    99,   239,   100,   188,
      -1,    16,   252,   187,    56,    99,   252,   213,   100,   106,
      -1,   211,    -1,   212,    -1,    25,    99,   216,   106,   252,
     213,   106,   252,   217,   215,   100,   252,   187,    -1,    25,
      99,   216,   252,   106,   213,   106,   100,   252,   187,    -1,
      25,    99,   106,   239,   106,   100,   187,    -1,    25,    99,
     216,   106,   106,   100,   187,    -1,    25,    99,   106,   106,
     100,   187,    -1,    25,    99,   106,   239,   106,   217,   100,
     187,    -1,    25,    99,   216,   106,   106,   217,   100,   187,
      -1,    25,    99,   106,   106,   217,   100,   187,    -1,    25,
      99,   216,   106,   252,   213,   106,   252,   217,   215,   100,
     252,   188,    -1,    25,    99,   106,   239,   106,   217,   100,
     188,    -1,    25,    99,   216,   106,   106,   217,   100,   188,
      -1,    25,    99,   106,   106,   217,   100,   188,    -1,    25,
      99,   216,   106,   252,   213,   106,   100,   252,   188,    -1,
      25,    99,   106,   239,   106,   100,   188,    -1,    25,    99,
     216,   106,   106,   100,   188,    -1,    25,    99,   106,   106,
     100,   188,    -1,    -1,   214,   239,    -1,    -1,   218,    -1,
     186,    -1,   218,    -1,   218,   101,   252,   194,    -1,   194,
      -1,     6,    26,   106,    -1,     6,   106,    -1,    14,    26,
     106,    -1,    14,   106,    -1,    42,   106,    -1,    42,   239,
     106,    -1,    51,   239,   106,    -1,    48,    99,   239,   100,
     181,    -1,    53,   181,   225,    -1,    53,   181,   227,    -1,
      53,   181,   225,   227,    -1,   225,   226,    -1,   226,    -1,
       9,    99,   160,   100,   181,    -1,    22,   181,    -1,   229,
      -1,   235,    -1,   234,    -1,    99,   239,   100,    -1,   233,
      -1,   232,    -1,    49,    -1,   113,    -1,   230,    -1,    37,
     122,    99,   231,   100,    -1,    37,   122,    99,   100,    -1,
     239,    -1,   231,   101,   239,    -1,   228,   105,   114,    -1,
      46,   105,    26,    -1,   125,    97,   239,    98,    -1,   229,
      97,   239,    98,    -1,   125,    99,   231,   100,    -1,   125,
      99,   100,    -1,   228,   105,    26,    99,   231,   100,    -1,
     228,   105,    26,    99,   100,    -1,    46,   105,   114,    99,
     231,   100,    -1,    46,   105,   114,    99,   100,    -1,    37,
     118,   236,   238,    -1,    37,   118,   236,    -1,    37,   117,
     236,   238,    -1,    37,   117,   236,    -1,   236,   237,    -1,
     237,    -1,    97,   239,    98,    -1,    97,    98,    -1,   238,
      97,    98,    -1,   240,    -1,   245,    -1,   241,    -1,    -1,
     243,   244,   242,   239,    -1,   125,    -1,   232,    -1,   233,
      -1,    85,    -1,    90,    -1,    88,    -1,    84,    -1,    57,
      -1,    93,    -1,    94,    -1,    91,    -1,    87,    -1,    92,
      -1,    89,    -1,    86,    -1,   248,    -1,   246,   252,   239,
     247,    63,   252,   245,    -1,   248,    62,    -1,    -1,   250,
      -1,   249,   252,   250,    -1,   248,    71,    -1,   253,    -1,
     251,   252,   253,    -1,   250,    72,    -1,    -1,   254,    -1,
     253,    77,   254,    -1,   255,    -1,   254,    79,   255,    -1,
     256,    -1,   255,    78,   256,    -1,   257,    -1,   256,    65,
     257,    -1,   256,    68,   257,    -1,   258,    -1,   257,    66,
     258,    -1,   257,    31,   116,    -1,   257,    59,   258,    -1,
     257,    58,   258,    -1,   257,    67,   258,    -1,   259,    -1,
     258,    82,   259,    -1,   260,    -1,   259,    73,   260,    -1,
     259,    74,   260,    -1,   261,    -1,   260,    75,   261,    -1,
     260,    76,   261,    -1,   260,    80,   261,    -1,   262,    -1,
     263,    -1,    73,   261,    -1,    74,   261,    -1,   264,    -1,
      61,   261,    -1,    60,   261,    -1,    69,   261,    -1,    70,
     261,    -1,   265,    -1,   268,    -1,   228,    -1,   125,    -1,
     266,    -1,   267,    -1,   265,    69,    -1,   265,    70,    -1,
      99,   118,   238,   100,   261,    -1,    99,   118,   100,   261,
      -1,    99,   239,   100,   264,    -1,    99,   125,   238,   100,
     264,    -1,   239,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   115,   115,   132,   146,   220,   221,   225,   226,   229,
     231,   232,   243,   244,   247,   257,   266,   275,   284,   293,
     304,   312,   322,   347,   350,   356,   362,   373,   374,   377,
     384,   434,   442,   443,   449,   450,   452,   458,   467,   468,
     476,   477,   485,   493,   494,   500,   507,   514,   515,   516,
     519,   520,   535,   541,   546,   551,   556,   561,   566,   571,
     576,   581,   590,   604,   617,   630,   644,   660,   675,   689,
     706,   724,   732,   739,   747,   748,   756,   757,   777,   778,
     798,   799,   800,   803,   804,   807,   838,   870,   874,   891,
     931,  1065,  1084,  1124,  1127,  1130,  1180,  1225,  1235,  1242,
    1249,  1256,  1263,  1269,  1275,  1287,  1302,  1382,  1426,  1460,
    1471,  1474,  1489,  1524,  1533,  1534,  1549,  1550,  1557,  1565,
    1615,  1664,  1712,  1759,  1772,  1833,  1880,  1886,  1887,  1888,
    1891,  1896,  1901,  1905,  1912,  1930,  1946,  1961,  1981,  1987,
    1993,  1998,  2006,  2007,  2025,  2026,  2034,  2043,  2046,  2049,
    2058,  2068,  2075,  2079,  2088,  2101,  2105,  2126,  2130,  2146,
    2152,  2155,  2156,  2159,  2162,  2180,  2181,  2182,  2183,  2184,
    2185,  2188,  2189,  2190,  2191,  2192,  2195,  2196,  2197,  2198,
    2199,  2200,  2201,  2202,  2203,  2204,  2205,  2207,  2210,  2213,
    2216,  2219,  2220,  2221,  2222,  2223,  2224,  2225,  2229,  2247,
    2269,  2293,  2293,  2308,  2325,  2331,  2332,  2333,  2336,  2337,
    2345,  2346,  2354,  2363,  2368,  2375,  2398,  2407,  2426,  2429,
    2432,  2454,  2473,  2480,  2487,  2494,  2501,  2508,  2518,  2541,
    2548,  2555,  2562,  2581,  2588,  2595,  2606,  2606,  2622,  2630,
    2631,  2634,  2637,  2657,  2660,  2668,  2677,  2690,  2698,  2702,
    2716,  2724,  2731,  2737,  2743,  2752,  2758,  2761,  2770,  2778,
    2779,  2782,  2783,  2784,  2785,  2786,  2791,  2792,  2795,  2890,
    2972,  3002,  3032,  3124,  3142,  3225,  3318,  3405,  3460,  3567,
    3655,  3664,  3674,  3683,  3710,  3718,  3728,  3737,  3746,  3749,
    3750,  3758,  3761,  3762,  3765,  3765,  3816,  3817,  3818,  3821,
    3822,  3823,  3824,  3825,  3826,  3827,  3828,  3829,  3830,  3831,
    3832,  3835,  3836,  3892,  3910,  3917,  3918,  3959,  3975,  3976,
    4017,  4034,  4039,  4040,  4102,  4103,  4147,  4148,  4191,  4192,
    4235,  4279,  4280,  4325,  4331,  4377,  4430,  4478,  4479,  4526,
    4527,  4594,  4661,  4662,  4728,  4792,  4830,  4831,  4832,  4839,
    4846,  4851,  4858,  4869,  4903,  4934,  4935,  4940,  4941,  4942,
    4943,  4946,  4979,  5013,  5040,  5065,  5073,  5100
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "ABSTRACT", "ASSERT", "BOOLEAN", "BREAK",
  "BYTE", "CASE", "CATCH", "CHAR", "CLASS", "COMMENT", "CONST", "CONTINUE",
  "DEFAULT", "DO", "DOUBLE", "ELSE", "ENUM", "ERROR", "EXTENDS", "FINALLY",
  "FINAL", "FLOAT", "FOR", "IDENTIFIER", "IF", "GOTO", "IMPLEMENTS",
  "IMPORT", "INSTANCEOF", "INT", "INTERFACE", "LITERAL", "LONG", "NATIVE",
  "NEW", "PACKAGE", "PRIVATE", "PROTECTED", "PUBLIC", "RETURN", "SHORT",
  "STATIC", "STRICTFP", "SUPER", "SWITCH", "SYNCHRONIZED", "THIS",
  "THROWS", "THROW", "TRANSIENT", "TRY", "VOID", "VOLATILE", "WHILE",
  "EQUALS", "GT", "LT", "NT", "TILDA", "QUESTION_MARK", "COLON", "ARROW",
  "EQEQ", "GREQ", "LEQ", "NEQUALS", "PLUSPLUS", "MINUSMINUS", "OR", "AND",
  "ADD", "SUBTRACT", "MULTIPLY", "DIVISION", "BINARYOR", "BINARYAND",
  "POW", "MOD", "GRGR", "LTLT", "GRGRGR", "PLEQ", "SBEQ", "MULEQ", "ANDEQ",
  "OREQ", "POWEQ", "DIVEQ", "MODEQ", "DGRGR", "DLRLR", "TGRGRGR", "OC",
  "CC", "OSQ", "CSQ", "OS", "CS", "COMMA", "DISTO", "ATR", "TDT", "FST",
  "SCLN", "DST", "STRING_LITERAL", "STRING", "CONST_LITERAL", "';'",
  "$accept", "Literal", "Identifier", "Type", "RefType",
  "ClassOrIntfaceType", "PrimitiveType", "Numbers", "Integers",
  "FloatingPoint", "ClassType", "IntfaceType", "ArrKind", "Name",
  "SimpleName", "QualName", "CompUnit", "ImportDecnRec", "TypeDecRec",
  "PackageDecn", "ImportDecn", "SingleTypeImportDecn", "ImportDDec",
  "TypeDec", "Modifiers", "Modifier", "ClassDec", "C", "ClassName",
  "Super", "Intfaces", "IntfaceTypeList", "ClassBody", "ClassBodyDecRec",
  "ClassBodyDec", "MemberDec", "FieldDecn", "VariableDecltrs",
  "VariableDecltr", "VariableDecltrId", "VariableInit", "MethodDecn", "F",
  "MethodHead", "MethodIdentifier", "MethodDecltr", "M", "FormalParamList",
  "FormalParam", "Throws", "ClassTypeList", "MethodBody", "StaticInit",
  "ConstructorDecn", "ConstructorName", "ConstructorDecltr",
  "ConstructorBody", "ExplicitConstructorInvocation", "IntfaceDecn",
  "StructName", "S", "ExtendsIntfaces", "IntfaceBody",
  "IntfaceMemberDecnRec", "IntfaceMemberDecn", "ConstantDec",
  "AbstractMethod", "ArrInit", "VariableInitList", "Block", "CT",
  "BlockStmts", "BlockStmt", "LocalVariableDecnStmt", "LocalVariableDecn",
  "Stmt", "StmtKind", "StmtWithoutTrailingSubStmt", "EmptyStmt",
  "LabeledStmt", "LabeledStmtNoShortIf", "ExprStmt", "StmtExpr",
  "IfThenStmt", "IfThenElseStmt", "IfThenElseStmtKind", "IF_CODE", "@1",
  "SwitchStmt", "SwitchBlock", "SwitchBlockStmtGroups", "SwitchLabels",
  "SwitchBlockStmtGroup", "SwitchLabel", "WhileStmt", "WhileStmtKind",
  "DoStmt", "ForStatement", "ForStatementKind", "ForStmt", "ForStmtKind",
  "EXPR_STMT_CODE", "@2", "N", "ForInit", "ForUpdate", "StmtExprList",
  "BreakStmt", "ContinueStmt", "ReturnStmt", "ThrowStmt",
  "SynchronizedStmt", "TryStmt", "Catches", "CatchClause", "ResEnd",
  "Primary", "PrimaryNoNewArr", "ClassCreation", "ArgLst", "FieldAccess",
  "ArrOp", "MethodInvocation", "NewArr", "DimExprs", "DimExpr", "Dims",
  "Expr", "AssignExpr", "Assign", "@3", "LeftHandSide", "AssignOp",
  "ConditionExpr", "GOTO_COND", "WRITE_GOTO", "ConditionOrExpr", "GOTO_OR",
  "ConditionAndExpr", "GOTO_AND", "NEXT_QUAD", "InclusiveOrExpr",
  "ExclusiveOrExpr", "AndExpr", "EqExpr", "RtlExpr", "ShiftExpr",
  "AddExpr", "MultExpr", "UnaryExpr", "PreIncExpr", "PreDecExpr",
  "UnaryExprExtra", "PostfixExpr", "PostIncrementExpr",
  "PostDecrementExpr", "CastExpr", "ConstExpr", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,   360,   361,   362,   363,   364,
     365,    59
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint16 yyr1[] =
{
       0,   112,   113,   113,   114,   115,   115,   116,   116,   117,
     118,   118,   119,   119,   120,   120,   120,   120,   120,   120,
     121,   121,   122,   123,   124,   124,   124,   125,   125,   126,
     127,   128,   128,   128,   128,   128,   128,   128,   129,   129,
     130,   130,   131,   132,   132,   133,   134,   135,   135,   135,
     136,   136,   137,   137,   137,   137,   137,   137,   137,   137,
     137,   137,   138,   138,   138,   138,   138,   138,   138,   138,
     139,   140,   141,   142,   143,   143,   144,   144,   145,   145,
     146,   146,   146,   147,   147,   148,   148,   149,   149,   150,
     150,   151,   151,   152,   152,   153,   154,   155,   155,   155,
     155,   155,   155,   155,   155,   156,   157,   157,   157,   158,
     159,   159,   160,   161,   162,   162,   163,   163,   164,   165,
     165,   165,   165,   166,   167,   167,   168,   168,   168,   168,
     169,   169,   169,   169,   170,   170,   170,   170,   171,   172,
     173,   173,   174,   174,   175,   175,   176,   176,   177,   178,
     179,   179,   179,   179,   180,   180,   181,   181,   182,   183,
     183,   184,   184,   185,   186,   187,   187,   187,   187,   187,
     187,   188,   188,   188,   188,   188,   189,   189,   189,   189,
     189,   189,   189,   189,   189,   189,   189,   190,   191,   192,
     193,   194,   194,   194,   194,   194,   194,   194,   195,   196,
     197,   199,   198,   200,   201,   201,   201,   201,   202,   202,
     203,   203,   204,   205,   205,   206,   207,   208,   209,   210,
     211,   211,   211,   211,   211,   211,   211,   211,   212,   212,
     212,   212,   212,   212,   212,   212,   214,   213,   215,   216,
     216,   217,   218,   218,   219,   219,   220,   220,   221,   221,
     222,   223,   224,   224,   224,   225,   225,   226,   227,   228,
     228,   229,   229,   229,   229,   229,   229,   229,   230,   230,
     231,   231,   232,   232,   233,   233,   234,   234,   234,   234,
     234,   234,   235,   235,   235,   235,   236,   236,   237,   238,
     238,   239,   240,   240,   242,   241,   243,   243,   243,   244,
     244,   244,   244,   244,   244,   244,   244,   244,   244,   244,
     244,   245,   245,   246,   247,   248,   248,   249,   250,   250,
     251,   252,   253,   253,   254,   254,   255,   255,   256,   256,
     256,   257,   257,   257,   257,   257,   257,   258,   258,   259,
     259,   259,   260,   260,   260,   260,   261,   261,   261,   261,
     261,   261,   261,   262,   263,   264,   264,   265,   265,   265,
     265,   266,   267,   268,   268,   268,   268,   269
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     3,     3,     3,     1,     1,     1,
       3,     3,     1,     2,     1,     1,     2,     2,     1,     2,
       1,     2,     3,     1,     1,     3,     4,     1,     1,     1,
       1,     2,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     7,     5,     6,     5,     5,     4,     6,     6,
       0,     1,     2,     2,     1,     3,     2,     4,     1,     3,
       1,     1,     1,     1,     1,     4,     3,     1,     4,     1,
       4,     1,     3,     1,     1,     3,     0,     4,     3,     2,
       4,     3,     3,     2,     3,     1,     6,     4,     3,     0,
       1,     4,     2,     2,     1,     3,     1,     1,     2,     5,
       4,     3,     4,     1,     6,     4,     4,     2,     3,     3,
       5,     4,     5,     4,     6,     5,     4,     5,     1,     0,
       2,     3,     2,     4,     1,     2,     1,     1,     1,     2,
       4,     3,     2,     3,     4,     1,     4,     2,     0,     2,
       1,     1,     1,     2,     2,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     3,     3,
       2,     1,     1,     1,     1,     1,     1,     1,     3,     7,
       7,     0,     5,     5,     4,     2,     3,     3,     1,     2,
       1,     2,     2,     3,     2,     7,     5,     9,     1,     1,
      13,    10,     7,     7,     6,     8,     8,     7,    13,     8,
       8,     7,    10,     7,     7,     6,     0,     2,     0,     1,
       1,     1,     4,     1,     3,     2,     3,     2,     2,     3,
       3,     5,     3,     3,     4,     2,     1,     5,     2,     1,
       1,     1,     3,     1,     1,     1,     1,     1,     5,     4,
       1,     3,     3,     3,     4,     4,     4,     3,     6,     5,
       6,     5,     4,     3,     4,     3,     2,     1,     3,     2,
       3,     1,     1,     1,     0,     4,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     7,     2,     0,     1,     3,     2,     1,     3,
       2,     0,     1,     3,     1,     3,     1,     3,     1,     3,
       3,     1,     3,     3,     3,     3,     3,     1,     3,     1,
       3,     3,     1,     3,     3,     3,     1,     1,     2,     2,
       1,     2,     2,     2,     2,     1,     1,     1,     1,     1,
       1,     2,     2,     5,     4,     4,     5,     1
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint16 yydefact[] =
{
       0,    60,     0,    52,     0,     0,    55,     0,    53,    54,
      58,    57,    56,    59,    61,    48,     0,    34,    32,    35,
      38,    44,    43,    40,     0,    50,    49,    47,    71,    70,
       4,    29,     0,    28,    27,   138,   139,     0,     1,    36,
      39,    41,    33,    37,     0,     0,    51,     0,     0,     0,
      70,    70,     0,    45,     0,     0,     0,   139,    42,    31,
      70,   139,    22,    72,     9,    23,    74,    73,   158,    67,
       0,    70,     0,    30,    46,   140,   158,   136,     0,     0,
       0,    70,    70,     0,   139,     0,    76,     0,    65,     0,
      63,   142,     0,   141,   137,    66,     0,    70,     0,   135,
       0,    75,    11,    15,    17,    20,    21,     4,    16,    14,
      18,    57,     0,    19,     0,     5,     8,     6,    10,    13,
      12,     7,     9,     0,   321,    78,    82,    84,    83,    96,
      81,    80,     0,    96,    68,     0,   148,     0,     0,   144,
     146,   147,    64,     0,    69,   134,   158,   118,   105,     0,
     103,    91,     0,    87,    89,    99,     0,     0,     0,     0,
       0,    96,    77,     0,     0,   109,     0,     0,    96,   149,
     143,   145,    62,   157,     0,   109,     0,   101,   321,    86,
     321,     0,    98,    24,    25,    26,   102,     0,   104,     0,
      96,    79,   116,    95,   117,     0,   114,   113,     0,   121,
       0,     0,     0,   321,     0,     4,   201,     0,     0,     0,
       0,     0,   265,     0,     0,     0,     0,     0,     0,   187,
       3,     2,   266,     0,   296,   183,     0,   160,   161,     0,
     162,   166,   184,   168,   179,     0,   169,   170,   321,   181,
     165,   177,   167,   218,   178,   182,   185,   180,   186,   176,
     357,   259,   267,   264,   263,   261,   260,   197,     0,   196,
     193,     0,   195,   192,     0,   108,     0,     0,    92,   100,
      85,    97,   120,     0,   125,     0,     0,   110,     0,     0,
     265,   127,     0,     0,   122,     0,   245,     0,   247,     0,
       0,     0,     0,    22,     0,     0,     0,     0,     0,     0,
       0,   248,   358,   267,   261,     0,   291,   293,   292,   321,
     311,   321,   315,   321,   318,   322,   324,   326,   328,   331,
     337,   339,   342,   346,   347,   350,   355,   359,   360,   356,
       0,     0,     0,     0,     0,   321,   358,   264,   263,   353,
     354,     0,    91,   164,     0,     0,   156,   159,   163,   190,
       0,     0,     0,   303,   302,   299,   310,   307,   301,   309,
     300,   306,   308,   304,   305,   294,   361,   362,   107,     0,
      88,     0,    90,    94,    93,   119,   112,   321,   321,   115,
       0,     0,   128,     0,   129,   244,   246,     0,     0,   240,
     243,     0,   239,   188,     0,     0,   285,   287,   283,     0,
     352,   351,   348,   349,     0,   358,     0,     0,   249,     0,
     313,   317,     0,   320,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   273,     0,     0,     0,   250,     0,     0,   252,   256,
     253,   236,   262,     0,   277,     0,   270,     0,     4,     0,
     198,   238,   166,   172,   174,   321,   171,   175,   219,     4,
     272,     0,     0,   321,   152,     0,   155,     0,   124,     0,
       0,     0,     0,     0,   126,     0,     0,     0,   321,     0,
     321,     0,     0,     0,   286,   284,   282,   269,     0,     0,
       0,     0,     0,     0,   262,   314,   316,   319,   323,   325,
     327,   329,   330,   333,     0,   335,   334,   332,   336,   338,
     340,   341,   343,   344,   345,     0,     0,     0,     0,   258,
     255,   254,     0,     0,   274,   276,     0,     0,     0,     0,
       0,     0,     0,   275,   295,   106,   153,   151,   321,   111,
     133,     0,   131,     0,   321,     0,     0,   241,     0,     0,
     236,   236,     0,   202,   288,   289,     0,   268,   364,     0,
       0,   365,     0,   281,     0,     0,   203,   251,     0,   321,
     237,   271,     0,     0,   189,     0,   321,   238,   279,     0,
     150,     0,   132,   130,   236,   224,     0,     0,     0,     0,
       0,     0,     0,   242,   290,   363,   366,   321,   280,     0,
       0,   205,     0,     0,   208,   210,     0,     0,     0,     0,
     321,     0,     0,     0,   278,   154,     0,   227,   222,     0,
     223,     0,   321,     0,     0,   367,     0,   214,   206,     0,
     209,   207,   212,   211,   257,   215,     0,     0,     0,     0,
     236,     0,     4,     0,   216,   173,   321,   199,   321,     0,
     225,   226,     0,   321,   312,   213,   204,   235,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   217,
     238,     0,   231,   233,     0,   234,     0,   321,     0,     0,
     238,   200,     0,   221,   229,   230,   321,     0,     0,     0,
     321,     0,   321,     0,   238,     0,     0,     0,     0,   236,
     321,     0,   232,     0,     0,     0,     0,     0,     0,     0,
       0,   220,   321,     0,     0,   321,     0,     0,   228,   238,
       0,   321,     0
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,   222,    31,   223,   115,   116,   117,   118,   119,   120,
      63,    66,   121,   302,    33,    34,    16,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    49,    29,    50,
      51,    67,    69,   124,   125,   126,   127,   152,   153,   154,
     372,   128,   164,   129,   149,   150,   195,   276,   277,   168,
     197,   193,   130,   131,   132,   133,   199,   282,    27,    36,
      56,    57,    77,   138,   139,   140,   141,   373,   467,   225,
      87,   632,   227,   228,   229,   230,   574,   231,   232,   233,
     453,   234,   235,   236,   237,   454,   238,   292,   239,   566,
     602,   603,   604,   605,   240,   456,   241,   242,   457,   243,
     458,   522,   523,   530,   391,   546,   547,   244,   245,   246,
     247,   248,   249,   438,   439,   440,   250,   251,   252,   445,
     253,   254,   255,   256,   396,   397,   485,   446,   306,   257,
     462,   258,   365,   308,   309,   562,   310,   311,   312,   313,
     441,   314,   315,   316,   317,   318,   319,   320,   321,   322,
     259,   260,   325,   261,   262,   263,   329,   626
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -571
static const yytype_int16 yypact[] =
{
     761,  -571,    50,  -571,    64,    81,  -571,    64,  -571,  -571,
    -571,  -571,  -571,  -571,  -571,  -571,   140,  1019,   280,  1019,
    -571,  -571,  -571,  -571,  1354,  -571,  -571,  -571,  -571,   163,
    -571,  -571,   332,  -571,  -571,  -571,   129,    83,  -571,   280,
    -571,  -571,  1019,   280,    50,    81,  -571,    64,    64,    61,
     144,  -571,   143,  -571,    99,    64,   125,   133,  -571,   280,
     163,   129,  -571,  -571,   152,  -571,  -571,   137,   253,  -571,
      61,  -571,    61,  -571,  -571,  -571,   255,  -571,    64,   125,
      61,   144,  -571,   125,   133,    64,  -571,  1532,  -571,    61,
    -571,  -571,  1790,  -571,  -571,  -571,    61,  -571,    61,  -571,
     125,  -571,  -571,  -571,  -571,  -571,  -571,   227,  -571,  -571,
    -571,   223,   311,  -571,   318,  -571,  -571,   258,  -571,  -571,
    -571,   260,    88,  2048,   274,  -571,  -571,  -571,  -571,  -571,
    -571,  -571,   273,   325,  -571,  2245,  -571,   271,  1274,  -571,
    -571,  -571,  -571,    61,  -571,  -571,   289,  -571,  -571,   284,
     -17,   291,   108,  -571,    48,   -17,   301,   308,   345,   311,
     318,   325,  -571,  1532,    52,  -571,    64,   314,  -571,  -571,
    -571,  -571,  -571,  -571,  3000,  -571,   334,  -571,  -571,  -571,
    -571,   352,  -571,  -571,  -571,  -571,   -17,   131,   -17,   314,
    -571,  -571,  -571,  -571,  -571,   201,  -571,   350,  2565,  -571,
     314,   -15,     6,  -571,   353,   390,  -571,    24,  1585,   357,
     356,   358,  -571,  3710,   223,   364,  3710,  3710,  3710,  -571,
    -571,  -571,  -571,   440,   261,  -571,  2652,  -571,  -571,   362,
    -571,  -571,  -571,  -571,  -571,   363,  -571,  -571,  -571,  -571,
    -571,  -571,  -571,  -571,  -571,  -571,  -571,  -571,  -571,  -571,
     365,   375,   141,  2029,  2271,   155,  -571,  -571,  2466,  -571,
    -571,   128,   219,   230,   241,  -571,   440,  1843,  -571,  -571,
    -571,  -571,  -571,   314,  -571,   440,   222,  -571,    64,    39,
     374,  -571,  2739,  2826,  -571,   368,  -571,   369,  -571,  3225,
    3112,  3225,   378,   381,   381,   383,  3710,  3710,  3710,  3710,
    3054,  -571,  2359,  -571,  -571,   377,  -571,  -571,  -571,  -571,
     106,  -571,   412,  -571,   408,   410,   409,     7,   239,   411,
     288,   205,  -571,  -571,  -571,  -571,   128,  -571,  -571,  -571,
     468,  3710,  3710,   389,   130,  -571,   210,  -571,  -571,  -571,
    -571,   397,  -571,   398,  3368,  3386,  -571,  -571,  -571,  -571,
    3290,   472,  3710,  -571,  -571,  -571,  -571,  -571,  -571,  -571,
    -571,  -571,  -571,  -571,  -571,  -571,  -571,  -571,  -571,   264,
    -571,   811,  -571,  -571,  -571,  -571,   403,  -571,  -571,  -571,
    3431,  3438,  -571,  2913,  -571,  -571,  -571,   446,  3483,  -571,
    -571,   400,   406,  -571,  3710,  3710,   407,  -571,   407,  3514,
    -571,  -571,  -571,  -571,   211,  3701,   415,  3710,  -571,  3710,
    -571,  -571,  3710,  -571,  3710,  3710,  3710,  3710,  3710,  3710,
      24,  3710,  3710,  3710,  3710,  3710,  3710,  3710,  3710,  3710,
    3710,   413,   417,   418,   419,  -571,   421,   223,   130,  -571,
    -571,  -571,  -571,   424,  -571,   267,  -571,   425,   445,   426,
    -571,  -571,   491,  -571,  -571,  -571,  -571,  -571,  -571,   427,
    -571,   429,  3710,  -571,  -571,   414,  -571,   158,  -571,    24,
     405,   287,   422,   296,  -571,   430,   604,   428,   432,   436,
    -571,   431,   434,  3559,  -571,   438,   438,  -571,   303,   447,
    3710,   248,  3559,   256,   226,  -571,   412,   408,   410,   409,
       7,   239,   239,  -571,   258,   411,   411,   411,   411,   288,
     205,   205,  -571,  -571,  -571,  3566,   441,   223,    24,  -571,
    -571,  -571,   443,  3710,  -571,  -571,  3710,  3160,  3290,  3710,
     528,  3290,  3622,  -571,  -571,  -571,  -571,  -571,   451,  -571,
    -571,   442,  -571,   448,  -571,  3225,   449,   406,  1036,  1330,
    -571,  -571,   111,  -571,  -571,  -571,   454,  -571,  -571,  3710,
     226,  -571,   490,  -571,   333,    22,  -571,  -571,   457,  -571,
    -571,  -571,  3638,   452,  -571,   464,  -571,  -571,  -571,   341,
    -571,  1843,  -571,  -571,  -571,  -571,  3225,  3225,   465,  3225,
     466,   461,   463,  -571,  -571,  -571,  -571,  -571,  -571,  3710,
     508,  -571,    31,  2372,  -571,  -571,   223,  3225,  2496,   467,
     469,  3355,  3225,   554,  -571,  -571,   474,  -571,  -571,  3225,
    -571,  3225,  -571,   476,  3710,  -571,   515,  -571,  -571,  2478,
    -571,  -571,  3000,  -571,  -571,  -571,  3290,   479,  2583,  2670,
    -571,   481,   519,   485,  -571,  -571,  -571,  -571,  -571,   480,
    -571,  -571,   111,  -571,  -571,  -571,  -571,  -571,  3290,  3290,
     487,  3290,   488,   483,  3191,  3355,  3710,  3355,  3290,  -571,
    -571,  3225,  -571,  -571,  3290,  -571,  3290,   492,  3644,   484,
    -571,  -571,   493,  -571,  -571,  -571,  -571,   111,  2757,   494,
     495,   567,  -571,  3355,  -571,  3355,   496,  2844,  2931,  -571,
    -571,  3225,  -571,   497,  3355,  3355,   498,  3355,   502,   499,
    3355,  -571,  -571,  3355,  3355,   492,  3290,   111,  -571,  -571,
     504,  -571,  3355
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -571,  -571,  -216,   -74,   189,   -43,  -197,  -571,  -571,  -571,
    -152,    23,  -571,    -4,  -571,  -571,  -571,   591,   198,  -571,
      43,  -571,  -571,   124,   -10,    -3,  -571,   292,   569,   551,
     101,  -571,   360,  -571,   453,  -571,   -27,   -98,   348,   342,
    -365,  -571,    63,     3,  -571,   -67,   444,   354,  -416,   116,
    -571,  -571,  -571,  -571,  -571,   500,  -164,  -571,  -571,   576,
     117,   561,   -13,  -571,   486,  -571,  -571,  -571,  -571,  -110,
     -31,  -146,  -204,  -571,  -288,   109,  1328,   812,  -571,  -571,
    -571,  -571,  -147,  -571,  -571,  -571,  1070,  -571,  -571,  -571,
    -571,    25,    29,  -545,  -571,  -571,  -571,  -571,  -571,  -571,
    -571,  -527,  -571,  -570,  -518,  -522,  -282,  -571,  -571,  -571,
    -571,  -571,  -571,  -571,   188,   191,  -571,  -571,   263,  -361,
     544,   802,   521,  -571,   338,   -84,   -65,  -145,  -571,  1795,
    -571,  -571,  -571,     9,  -571,  -571,  -571,  -571,   224,  -571,
    -109,   221,   231,   229,   225,    27,   -30,   213,    21,  -200,
    1553,  1811,  -454,   779,  1037,  1295,  -571,  -571
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -361
static const yytype_int16 yytable[] =
{
      32,   147,   389,    37,    62,    65,   466,   613,   392,   573,
     294,   285,    65,   114,   196,   163,   339,   340,   114,   471,
     473,    46,   347,   591,   592,   272,   588,   590,   226,   102,
     599,   103,   287,   166,   104,    65,   284,   600,   488,   599,
     561,   105,    65,    64,    64,    92,   600,   155,   106,   160,
      30,    64,   283,   539,   194,   295,   108,   616,   633,   109,
      40,   160,   187,   305,   114,   136,    94,   110,   333,   266,
      99,   267,   418,   341,    64,   419,    28,   123,    75,   347,
     176,    64,   135,   122,   633,    40,   637,   145,   122,   114,
      30,   286,   186,   188,   289,   137,   400,   401,   402,   403,
     682,    93,   568,   404,   334,   180,   596,    35,   101,   375,
     691,   136,   288,   663,   432,   174,   660,   662,   601,   122,
      46,   275,   374,    62,   703,   343,   379,   628,   135,   350,
     670,   122,    46,   113,   122,   460,   383,    30,   380,   436,
      38,   137,    41,   390,   330,   181,   679,   146,   207,   720,
      55,    71,   437,   123,   564,   406,    68,   209,   192,   122,
     212,    82,    64,    41,   293,   694,   696,    41,   410,    73,
     224,   579,   709,    48,    79,   706,   708,   411,    83,   347,
     216,   217,    97,    41,    47,   158,   433,   434,    52,    58,
     275,   122,    48,    52,   224,   719,   167,   366,   367,   443,
     409,   100,   412,    64,   414,    74,   102,   461,   103,   178,
     218,   104,   336,   336,   179,    39,   615,    43,   105,   220,
      76,   221,   224,   504,   189,   106,   374,    30,   512,   513,
     514,   200,   178,   108,    78,    62,   109,   270,    85,   389,
      59,  -191,  -191,   477,   110,   392,   102,  -191,   103,   481,
     482,   104,    30,   273,   537,  -194,  -194,    52,   105,   538,
     122,  -194,   443,   207,   495,   106,   177,    30,   468,   469,
     420,   182,   209,   108,    64,   212,   109,   190,   224,   224,
     428,   429,   479,     1,   110,   430,   224,    -9,  -359,  -359,
     558,     2,   336,   336,   336,   336,   405,   421,   422,  -360,
    -360,   274,   269,     3,   271,   423,   424,   407,   489,   345,
     113,   490,   484,     5,   484,    52,     6,   534,   146,     8,
       9,    10,   377,   378,    11,   300,  -123,   519,    12,   390,
    -358,  -358,    13,   486,   220,    14,   221,   148,   482,   491,
     493,   368,    70,    72,   151,   556,   531,   443,   559,    86,
     113,    91,    80,   556,   535,   156,   560,   157,   344,   595,
     345,   426,   427,    89,   463,   378,    52,   525,   526,   550,
     162,   552,   165,    96,    98,   166,   389,   169,   570,   224,
     390,   571,   392,   175,   575,   173,    15,   541,   526,   143,
    -105,   505,   506,   507,   508,   275,   543,   526,   387,   183,
     393,   390,   390,   557,   526,   593,   184,   567,   336,   198,
     336,   336,   336,   336,   336,   336,   122,   336,   336,   336,
     336,   336,   336,   336,   336,   336,   336,   609,   347,   581,
      88,   265,    90,   598,   526,   584,   374,    52,    53,    54,
      95,   614,   526,   185,   275,   501,   502,   510,   511,   134,
     268,   278,   290,   291,   625,   331,   142,   332,   144,   450,
     607,   390,   330,   335,   479,   122,   342,   612,   348,   349,
     351,   303,   352,   381,   385,   386,   303,   394,   395,   303,
     303,   303,   399,   408,   413,   415,   336,   417,   624,   416,
     336,   390,   390,   425,   431,   435,   634,   442,   459,   178,
     181,   640,   475,   172,   483,   390,   478,   480,   528,  -173,
     536,   540,    -4,   652,   122,   494,   515,   390,   516,   517,
     518,   575,   524,   224,   527,   529,   532,   533,   542,   544,
     303,   553,   554,   689,   548,   556,   565,   667,   549,   668,
     390,   390,   551,   569,   671,   555,   576,   580,   582,   586,
     390,   390,   594,   597,   583,   336,   336,   606,   610,   303,
     303,   303,   303,   303,   611,   619,   621,   622,   687,   623,
     390,   627,   648,   638,   649,   639,   653,   693,   655,   658,
     664,   699,   665,   701,   666,   700,   669,   674,   676,   677,
     690,   710,   686,   692,   303,   303,   704,   712,   713,   224,
     697,   698,   714,   716,   721,   715,   717,   303,   303,   503,
      42,    81,   722,    60,   370,   303,   191,   376,   369,   264,
     336,    61,    84,   161,   171,   224,   520,   629,   224,   521,
      30,   630,   398,   654,   303,   497,   496,   393,   509,     0,
     450,   207,   500,   303,   303,   499,   498,     0,     0,     0,
     209,   303,     0,   212,   585,     0,     0,   303,   303,     0,
     224,     0,   303,     0,     0,     0,     0,     0,     0,     0,
     303,     0,   303,   216,   217,   303,     0,   303,   303,   303,
     303,   303,   303,     0,   303,   303,   303,   303,   303,   303,
     303,   303,   303,   303,     0,   617,   618,     0,   620,     0,
       0,     0,     0,   218,   545,     0,     0,     0,     0,     0,
       0,     0,   220,     0,   221,     0,   635,     0,     0,     0,
       0,   647,     0,     0,     0,   303,     0,     0,   650,   304,
     651,     0,     0,     0,   304,     0,     0,   304,   304,   304,
       0,     0,     0,     0,     0,   585,   303,     0,     0,     0,
       0,     0,     0,   303,     0,   303,     0,   303,     0,     0,
     337,   337,     0,     0,     1,     0,     0,   617,   618,     0,
     620,     0,     2,     0,     0,     0,     0,   647,   303,     0,
     683,     0,     0,   650,     3,   651,   303,     0,   304,   303,
       0,     4,   303,     0,     5,   303,     0,     6,     0,     7,
       8,     9,    10,     0,     0,    11,     0,     0,     0,    12,
     711,     0,     0,    13,     0,     0,    14,   304,   304,   304,
     304,   304,   303,   303,     0,   711,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   303,     0,    30,     0,     0,
     337,   337,   337,   337,   303,     0,     0,     0,   207,     0,
       0,     0,   304,   304,     0,     0,     0,   209,     0,     0,
     212,     0,   303,     0,     0,   304,   304,    15,     0,     0,
       0,   296,   297,   304,     0,     0,     0,     0,     0,     0,
     216,   217,     0,     0,   298,   299,     0,   303,     0,     0,
       0,     0,   304,     0,     0,     0,     0,     0,     0,     0,
       0,   304,   304,     0,     0,     0,   371,   464,     0,   304,
     300,     0,   465,     0,     0,   304,   304,     0,     0,   220,
     304,   221,     0,     0,     0,     0,     0,     0,   304,   303,
     304,     0,     0,   304,     0,   304,   304,   304,   304,   304,
     304,   303,   304,   304,   304,   304,   304,   304,   304,   304,
     304,   304,     0,     0,     0,     0,   337,     0,   337,   337,
     337,   337,   337,   337,     0,   337,   337,   337,   337,   337,
     337,   337,   337,   337,   337,     0,     0,     0,     0,     0,
       0,     0,     0,   304,     0,     0,     0,   326,     0,     0,
       0,     0,   326,     0,     0,   326,   326,   326,     0,     0,
       0,     0,     0,     0,   304,     0,     0,     0,     0,     0,
       0,   304,     0,   304,     0,   304,     0,     0,   338,   338,
       0,     0,     1,     0,     0,     0,     0,     0,     0,     0,
       2,     0,     0,     0,   337,     0,   304,     0,   337,     0,
       0,     0,     3,     0,   304,     0,   326,   304,     0,     4,
     304,     0,     5,   304,     0,     6,     0,     0,     8,     9,
      10,     0,    30,    11,     0,     0,     0,    12,     0,     0,
       0,    13,     0,   207,    14,   326,   326,   326,   326,   326,
     304,   304,   209,     0,     0,   212,     0,     0,     0,     0,
       0,     0,     0,   304,     0,     0,     0,     0,   338,   338,
     338,   338,   304,   337,   337,   216,   217,     0,     0,     0,
     326,   326,     0,     0,     0,     0,     0,     0,     0,     0,
     304,     0,     0,   326,   326,    15,     0,     0,     0,     0,
       0,   326,     0,     0,     0,   218,   587,     0,     0,     0,
       0,     0,     0,     0,   220,   304,   221,     0,     0,     0,
     326,     0,     0,     0,     0,     0,     0,     0,     0,   326,
     326,     0,   452,     0,     0,     0,     0,   326,   337,     0,
       0,     0,     0,   326,   326,     0,     0,     0,   326,     0,
       0,     0,     0,     0,     0,     0,   326,   304,   326,     0,
       0,   326,     0,   326,   326,   326,   326,   326,   326,   304,
     326,   326,   326,   326,   326,   326,   326,   326,   326,   326,
       0,     0,     0,     0,   338,     0,   338,   338,   338,   338,
     338,   338,     0,   338,   338,   338,   338,   338,   338,   338,
     338,   338,   338,     0,     0,     0,     0,     0,     0,     0,
       0,   326,     0,     0,     0,   327,     0,     0,     0,     0,
     327,     0,     0,   327,   327,   327,     0,     0,     0,     0,
       0,     0,   326,     0,     0,     0,     0,     0,     0,   326,
       0,   326,     0,   326,     0,     0,     0,     1,     0,   102,
       0,   103,     0,     0,   104,     0,     0,     0,     0,     0,
       0,   105,   338,     0,   326,     0,   338,     3,   106,     0,
      30,     0,   326,     0,   327,   326,   108,     0,   326,   109,
       6,   326,     0,     8,     9,    10,     0,   110,    11,     0,
       0,     0,    12,     0,     0,     0,    13,     0,   112,    14,
       0,     0,     0,   327,   327,   327,   327,   327,   326,   326,
     452,     0,     0,   452,     0,     0,     0,     0,     0,     0,
       0,   326,     0,     0,     0,     0,    30,     1,     0,     0,
     326,   338,   338,     0,     0,    44,     0,   207,   327,   327,
     170,     0,     0,     0,     0,     0,   209,     3,   326,   212,
       0,   327,   327,   113,     0,     0,     0,    45,     0,   327,
       6,     0,     0,     8,     9,    10,     0,     0,    11,   216,
     217,     0,    12,   326,     0,     0,    13,     0,   327,    14,
       0,     0,     0,     0,     0,     0,     0,   327,   327,     0,
     455,     0,     0,   645,     0,   327,   338,     0,     0,   218,
     589,   327,   327,     0,     0,     0,   327,     0,   220,     0,
     221,     0,     0,     0,   327,   326,   327,     0,   452,   327,
       0,   327,   327,   327,   327,   327,   327,   326,   327,   327,
     327,   327,   327,   327,   327,   327,   327,   327,     0,     0,
     452,   452,     0,   452,     0,     0,     0,   645,     0,   645,
     452,     0,     0,     0,     0,     0,   452,     0,   452,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   327,
       0,     0,     0,   328,     0,   645,     0,   645,   328,     0,
       0,   328,   328,   328,     0,     0,   645,   645,     0,   645,
     327,     0,   645,     0,     0,   645,   645,   327,   452,   327,
       0,   327,     0,     0,   645,     1,     0,   102,     0,   103,
       0,     0,   104,     0,     0,     0,     0,     0,     0,   105,
       0,     0,   327,     0,     0,     3,   106,     0,   107,     0,
     327,     0,   328,   327,   108,     0,   327,   109,     6,   327,
       0,     8,     9,    10,     0,   110,   111,     0,     0,     0,
      12,     0,     0,     0,    13,     0,   112,    14,     0,     0,
       0,   328,   328,   328,   328,   328,   327,   327,   455,     0,
       0,   455,     0,     0,     0,     0,     0,     0,     0,   327,
       0,    30,     0,     0,     0,     0,     0,     0,   327,     0,
       0,     0,   207,     0,     0,     0,   328,   328,     0,     0,
       0,   209,     0,     0,   212,     0,   327,     0,     0,   328,
     328,   113,     0,     0,     0,   296,   297,   328,     0,     0,
       0,     0,     0,     0,   216,   217,     0,     0,   298,   299,
       0,   327,     0,     0,     0,     0,   328,     0,     0,     0,
       0,     0,     0,     0,     0,   328,   328,     0,   451,     0,
       0,   646,     0,   328,   300,     0,     0,     0,     0,   328,
     328,   301,     0,   220,   328,   221,     0,     0,     0,     0,
       0,     0,   328,   327,   328,     0,   455,   328,     0,   328,
     328,   328,   328,   328,   328,   327,   328,   328,   328,   328,
     328,   328,   328,   328,   328,   328,     0,     0,   455,   455,
       0,   455,     0,     0,     0,   646,     0,   646,   455,     0,
       0,     0,     0,     0,   455,     0,   455,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   328,     0,     0,
       0,   323,     0,   646,     0,   646,   323,     0,     0,   323,
     323,   323,     0,     0,   646,   646,     0,   646,   328,     0,
     646,     0,     0,   646,   646,   328,   455,   328,     0,   328,
       0,     0,   646,     1,     0,   102,     0,   103,     0,     0,
     104,     0,     0,     0,     0,     0,     0,   105,     0,     0,
     328,     0,     0,     3,   106,     0,    30,     0,   328,     0,
     323,   328,   108,     0,   328,   109,     6,   328,     0,     8,
       9,    10,     0,   110,    11,     0,     0,     0,    12,     0,
       0,     0,    13,     0,   112,    14,     0,     0,     0,   323,
     323,   323,   323,   323,   328,   328,     0,     0,     0,   577,
       0,     0,     0,     0,     0,     0,     0,   328,     0,    30,
       0,     0,     0,     0,     0,     0,   328,     0,     0,     0,
     207,     0,     0,     0,   323,   323,     0,     0,     0,   209,
       0,     0,   212,     0,   328,     0,     0,   323,   323,   113,
       0,     0,     0,   296,   297,   323,     0,     0,     0,     0,
       0,     0,   216,   217,     0,     0,   298,   299,     0,   328,
       0,     0,     0,     0,   323,     0,     0,     0,     0,     0,
       0,     0,     0,   323,   323,     0,     0,     0,   371,   644,
       0,   323,   300,     0,     0,     0,     0,   323,   323,     0,
       0,   220,   323,   221,     0,     0,     0,     0,     0,     0,
     323,   328,   323,     0,   657,   323,     0,   323,   323,   323,
     323,   323,   323,   328,   323,   323,   323,   323,   323,   323,
     323,   323,   323,   323,     0,     0,   672,   673,     0,   675,
       0,     0,     0,     0,     0,   680,   681,     0,     0,     0,
       0,     0,   684,   307,   685,     0,     0,     0,   307,     0,
       0,     0,     0,   307,     0,   323,     0,     0,     0,   324,
       0,   702,     0,   657,   324,     0,     0,   324,   324,   324,
       0,     0,   672,   673,     0,   675,   323,     0,   681,     0,
       0,   684,   685,   323,   718,   323,     0,     0,     0,     0,
     718,     1,     0,   102,     0,   103,     0,     0,   104,     0,
       0,     0,   307,     0,     0,   105,     0,     0,   323,     0,
       0,     3,   106,     0,   107,     0,   323,     0,   324,   323,
     108,     0,   323,   109,     6,   323,  -297,     8,     9,    10,
       0,   110,    11,     0,     0,   307,    12,     0,     0,     0,
      13,     0,   159,    14,     0,     0,     0,   324,   324,   324,
     324,   324,   323,  -297,  -297,  -297,  -297,  -297,  -297,  -297,
    -297,  -297,  -297,  -297,     0,   323,   307,   307,     0,     0,
       0,     0,     0,     0,   323,     0,     0,     0,     0,   307,
     307,     0,   324,   324,     0,     0,     0,   307,     0,     0,
       0,     0,   323,     0,     0,   324,   324,   113,     0,     0,
       0,     0,     0,   324,     0,     0,   307,     0,     0,     0,
       0,     0,     0,     0,     0,   307,   307,   323,     0,     0,
       0,     0,   324,   307,     0,     0,     0,     0,     0,   307,
     307,   324,   324,     0,   307,     0,     0,     0,     0,   324,
       0,     0,   307,     0,   307,   324,   324,     0,     0,     0,
     324,     0,     0,     0,     0,     0,     0,     0,   324,   323,
     324,     0,     0,   324,     0,   324,   324,   324,   324,   324,
     324,   323,   324,   324,   324,   324,   324,   324,   324,   324,
     324,   324,     0,     0,     0,     0,     0,     0,     1,     0,
     102,     0,   103,     0,     0,   104,     0,   307,     0,     0,
       0,     0,   105,     0,     0,     0,     0,     0,     3,   106,
       0,    30,     0,   324,     0,     0,     0,   108,   307,     0,
     109,     6,     0,     0,     8,     9,    10,   307,   110,    11,
       0,     0,     0,    12,   324,     0,     0,    13,     0,   159,
      14,   324,     0,   324,     0,     0,     0,     0,     0,     0,
     307,     0,     0,     0,     0,     0,     0,     0,   307,     0,
       0,   307,     0,     0,   307,     0,   324,   307,  -298,     0,
       0,     0,     0,     0,   324,     0,     0,   324,     0,     0,
     324,     0,     0,   324,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   113,  -298,  -298,  -298,  -298,  -298,
    -298,  -298,  -298,  -298,  -298,  -298,     0,   307,     0,     0,
     324,     0,     0,     0,     0,     0,   307,   102,   201,   103,
     599,     0,   104,   324,     0,     0,   202,   600,   203,   105,
       0,     0,   324,     0,   307,     0,   106,   204,   205,   206,
       0,     0,     0,     0,   108,     0,     0,   109,     0,   207,
     324,     0,     0,     0,   208,   110,  -296,     0,   209,   210,
     211,   212,     0,   213,     0,   214,     0,     0,   215,     0,
       0,     0,     0,     0,     0,   324,     0,     0,     0,     0,
       0,   216,   217,  -296,  -296,  -296,  -296,  -296,  -296,  -296,
    -296,  -296,  -296,  -296,     0,     0,   407,     0,   345,     0,
       0,   307,     0,     0,    52,     0,     0,   146,   631,     0,
       0,   218,     0,   307,     0,     0,     0,   324,   219,     0,
     220,   113,   221,   102,   201,   103,   599,     0,   104,   324,
       0,     0,   202,   600,   203,   105,     0,     0,     0,     0,
       0,     0,   106,   204,   205,   206,     0,     0,     0,     0,
     108,     0,     0,   109,     0,   207,     0,     0,     0,     0,
     208,   110,    30,   353,   209,   210,   211,   212,     0,   213,
       0,   214,     0,   207,   215,     0,     0,     0,     0,     0,
       0,     0,   209,     0,     0,   212,     0,   216,   217,     0,
     354,   355,   356,   357,   358,   359,   360,   361,   362,   363,
     364,     0,     0,     0,     0,   216,   217,     0,     0,     0,
     102,   201,   103,   146,   656,   104,     0,   218,     0,   202,
       0,   203,   105,     0,   219,     0,   220,   113,   221,   106,
     204,   205,   206,     0,     0,   218,   636,   108,     0,     0,
     109,     0,   207,     0,   220,     0,   221,   208,   110,    30,
       0,   279,   210,   211,   280,     0,   213,     0,   214,     0,
     207,   215,     0,     0,     0,     0,     0,     0,     0,   209,
       0,     0,   212,     0,   216,   217,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   216,   217,     0,     0,     0,   102,   201,   103,
     146,   281,   104,     0,   218,     0,   202,     0,   203,   105,
       0,   219,     0,   220,   113,   221,   106,   204,   205,   206,
       0,     0,   218,   659,   108,     0,     0,   109,     0,   207,
       0,   220,     0,   221,   208,   110,    30,     0,   209,   210,
     211,   212,     0,   213,     0,   214,     0,   207,   215,     0,
       0,     0,     0,     0,     0,     0,   209,     0,     0,   212,
       0,   216,   217,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   216,
     217,     0,     0,     0,   102,   201,   103,   146,   346,   104,
       0,   218,     0,   202,     0,   203,   105,     0,   219,     0,
     220,   113,   221,   106,   204,   205,   206,     0,     0,   218,
     661,   108,     0,     0,   109,     0,   207,     0,   220,     0,
     221,   208,   110,    30,     0,   209,   210,   211,   212,     0,
     213,     0,   214,     0,   207,   215,     0,     0,     0,     0,
       0,     0,     0,   209,     0,     0,   212,     0,   216,   217,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   216,   217,     0,     0,
       0,   102,   201,   103,   146,   382,   104,     0,   218,     0,
     202,     0,   203,   105,     0,   219,     0,   220,   113,   221,
     106,   204,   205,   206,     0,     0,   218,   695,   108,     0,
       0,   109,     0,   207,     0,   220,     0,   221,   208,   110,
      30,     0,   209,   210,   211,   212,     0,   213,     0,   214,
       0,   207,   215,     0,     0,     0,     0,     0,     0,     0,
     209,     0,     0,   212,     0,   216,   217,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   216,   217,     0,     0,     0,   102,   201,
     103,   146,   384,   104,     0,   218,     0,   202,     0,   203,
     105,     0,   219,     0,   220,   113,   221,   106,   204,   205,
     206,     0,     0,   218,   705,   108,     0,     0,   109,     0,
     207,     0,   220,     0,   221,   208,   110,    30,     0,   209,
     210,   211,   212,     0,   213,     0,   214,     0,   207,   215,
       0,     0,     0,     0,     0,     0,     0,   209,     0,     0,
     212,     0,   216,   217,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     216,   217,     0,     0,     0,   102,   201,   103,   146,   474,
     104,     0,   218,     0,   202,     0,   203,   105,     0,   219,
       0,   220,   113,   221,   106,   204,   205,   206,     0,     0,
     218,   707,   108,     0,     0,   109,     0,   207,     0,   220,
       0,   221,   208,   110,     0,     0,   209,   210,   211,   212,
       0,   213,     0,   214,     0,     0,   215,     0,     0,   102,
       0,   103,     0,     0,   104,     0,     0,     0,     0,   216,
     217,   105,     0,     0,     0,     0,     0,     0,   106,     0,
      30,     0,     0,     0,     0,     0,   108,     0,     0,   109,
       0,   207,     0,     0,     0,   146,     0,   110,     0,   218,
     209,     0,     0,   212,     0,     0,   219,     0,   220,   113,
     221,     0,     0,     0,   296,   297,     0,   102,     0,   103,
       0,     0,   104,   216,   217,     0,     0,   298,   299,   105,
       0,     0,     0,     0,     0,     0,   106,     0,    30,     0,
       0,     0,     0,     0,   108,     0,     0,   109,     0,   207,
       0,     0,     0,   300,     0,   110,     0,     0,   209,     0,
       0,   212,   220,   113,   221,   102,     0,   103,     0,     0,
     104,     0,     0,     0,     0,     0,     0,   105,     0,     0,
       0,   216,   217,     0,   106,     0,    30,     0,     0,     0,
       0,     0,   108,     0,     0,   109,   102,   207,   103,     0,
       0,   104,     0,   110,     0,     0,   209,     0,   105,   212,
       0,   218,     0,     0,     0,   106,     0,    30,   388,     0,
     220,   113,   221,   108,     0,     0,   109,     0,   207,   216,
     217,   201,     0,     0,   110,     0,     0,   209,     0,   202,
     212,   203,     0,     0,     0,     0,     0,     0,     0,     0,
     204,   205,   206,     0,     0,     0,     0,     0,     0,   218,
     216,   217,   207,     0,     0,     0,   572,   208,   220,   113,
     221,   209,   210,   211,   212,     0,   213,     0,   214,     0,
       0,   215,     0,     0,     0,     0,     0,     0,     0,     0,
     218,     0,     0,     0,   216,   217,   201,   678,     0,   220,
     113,   221,     0,     0,   202,     0,   203,     0,     0,     0,
       0,     0,     0,     0,     0,   447,   448,   206,     0,     0,
     146,     0,     0,     0,   218,     0,     0,   207,     0,     0,
       0,   219,   208,   220,     0,   221,   209,   210,   211,   212,
       0,   213,     0,   214,     0,     0,   449,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   216,
     217,   201,     0,     0,     0,     0,     0,     0,     0,   202,
       0,   203,     0,     0,     0,     0,     0,     0,     0,     0,
     641,   642,   206,     0,     0,   146,     0,     0,     0,   218,
       0,     0,   207,     0,    30,     0,   219,   208,   220,     0,
     221,   209,   210,   211,   212,   207,   213,     0,   214,     0,
       0,   643,    30,     0,   209,     0,     0,   212,     0,     0,
       0,     0,     0,   207,   216,   217,     0,     0,   296,   297,
       0,     0,   209,     0,     0,   212,     0,   216,   217,     0,
       0,   298,   299,     0,     0,     0,   296,   297,     0,     0,
     146,     0,     0,     0,   218,   216,   217,    30,     0,   298,
     299,   219,     0,   220,    30,   221,   185,   300,   207,     0,
       0,     0,     0,     0,     0,   207,   220,   209,   221,     0,
     212,     0,     0,     0,   209,   300,   444,   212,     0,     0,
       0,   296,   297,     0,   220,     0,   221,     0,   296,   297,
     216,   217,     0,     0,   298,   299,     0,   216,   217,    30,
       0,   298,   299,     0,     0,     0,     0,     0,     0,     0,
     207,     0,     0,     0,     0,     0,     0,     0,     0,   209,
     300,   470,   212,     0,     0,     0,     0,   300,   472,   220,
      30,   221,     0,   296,   297,     0,   220,     0,   221,     0,
       0,   207,   216,   217,     0,     0,   298,   299,     0,     0,
     209,     0,     0,   212,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   296,   297,     0,     0,     0,     0,
       0,     0,   300,   216,   217,    30,     0,   298,   299,   476,
       0,   220,    30,   221,     0,     0,   207,     0,     0,     0,
       0,     0,     0,   207,     0,   209,     0,     0,   212,     0,
       0,     0,   209,   300,   487,   212,     0,     0,     0,   296,
     297,     0,   220,     0,   221,     0,   296,   297,   216,   217,
       0,     0,   298,   299,     0,   216,   217,     0,     0,   298,
     299,     0,     0,     0,     0,     0,     0,     0,    30,     0,
       0,     0,     0,     0,     0,     0,     0,   555,   300,   207,
       0,     0,     0,     0,    30,   300,   563,   220,   209,   221,
      30,   212,     0,     0,   220,   207,   221,     0,     0,     0,
       0,   207,   296,   297,   209,     0,     0,   212,     0,     0,
     209,   216,   217,   212,     0,   298,   299,     0,   296,   297,
       0,     0,     0,     0,   296,   297,     0,   216,   217,     0,
       0,   298,   299,   216,   217,     0,     0,   298,   299,     0,
       0,   300,   578,     0,     0,     0,     0,     0,     0,     0,
     220,     0,   221,     0,     0,     0,    30,   300,     0,     0,
       0,     0,     0,   300,   608,     0,   220,   207,   221,     0,
     688,     0,   220,     0,   221,     0,   209,     0,  -296,   212,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     296,   297,     0,     0,     0,     0,     0,     0,     0,   216,
     217,     0,     0,   298,   299,  -296,  -296,  -296,  -296,  -296,
    -296,  -296,  -296,  -296,  -296,  -296,     0,     0,   492,     0,
     345,     0,     0,     0,     0,     0,    52,     0,     0,   300,
       0,     0,     0,     0,     0,     0,     0,     0,   220,     0,
     221
};

static const yytype_int16 yycheck[] =
{
       4,   111,   290,     7,    47,    48,   371,   577,   290,   527,
     207,    26,    55,    87,   166,   124,   216,   217,    92,   380,
     381,    24,   226,   550,   551,   189,   548,   549,   174,     5,
       8,     7,    26,    50,    10,    78,   200,    15,   399,     8,
     494,    17,    85,    47,    48,    76,    15,   114,    24,   123,
      26,    55,   198,   469,   164,   207,    32,   584,   603,    35,
      17,   135,   160,   208,   138,    92,    79,    43,   213,   178,
      83,   180,    65,   218,    78,    68,    26,    87,    55,   283,
      97,    85,    92,    87,   629,    42,   608,   100,    92,   163,
      26,   106,   159,   160,   203,    92,   296,   297,   298,   299,
     670,    78,   518,   300,   214,    57,   560,    26,    85,   273,
     680,   138,   106,   640,   330,   146,   638,   639,    96,   123,
     123,   195,   267,   166,   694,   223,   278,    96,   138,   238,
     652,   135,   135,   109,   138,   351,   282,    26,    99,     9,
       0,   138,    18,   290,   105,    97,   664,    95,    37,   719,
      21,    50,    22,   163,   515,   300,    95,    46,   106,   163,
      49,    60,   166,    39,   207,   687,   688,    43,    62,    26,
     174,   532,   699,    29,    57,   697,   698,    71,    61,   383,
      69,    70,    81,    59,    21,    97,   331,   332,   105,   106,
     264,   195,    29,   105,   198,   717,   133,    69,    70,   344,
     309,    84,   311,   207,   313,   106,     5,   352,     7,   101,
      99,    10,   216,   217,   106,    17,   581,    19,    17,   108,
      95,   110,   226,   420,   161,    24,   371,    26,   428,   429,
     430,   168,   101,    32,   101,   278,    35,   106,   101,   527,
      42,   100,   101,   388,    43,   527,     5,   106,     7,   394,
     395,    10,    26,   190,    96,   100,   101,   105,    17,   101,
     264,   106,   407,    37,   409,    24,   150,    26,   377,   378,
      31,   155,    46,    32,   278,    49,    35,   161,   282,   283,
      75,    76,   391,     3,    43,    80,   290,    26,    69,    70,
     490,    11,   296,   297,   298,   299,   300,    58,    59,    69,
      70,   100,   186,    23,   188,    66,    67,    97,    97,    99,
     109,   100,   396,    33,   398,   105,    36,   462,    95,    39,
      40,    41,   100,   101,    44,    99,    99,   437,    48,   476,
      69,    70,    52,   398,   108,    55,   110,    26,   483,   404,
     405,   100,    50,    51,    26,    97,   455,   492,   100,    96,
     109,    96,    60,    97,   463,    97,   100,    97,    97,   559,
      99,    73,    74,    71,   100,   101,   105,   100,   101,   478,
      96,   480,    99,    81,    82,    50,   664,   106,   523,   383,
     527,   526,   664,    99,   529,    96,   106,   100,   101,    97,
      99,   421,   422,   423,   424,   469,   100,   101,   289,    98,
     291,   548,   549,   100,   101,   552,    98,   517,   412,    95,
     414,   415,   416,   417,   418,   419,   420,   421,   422,   423,
     424,   425,   426,   427,   428,   429,   430,   572,   632,   538,
      70,    97,    72,   100,   101,   544,   581,   105,   106,   107,
      80,   100,   101,    98,   518,   418,   419,   426,   427,    89,
      98,   101,    99,    63,   599,    99,    96,    99,    98,   350,
     569,   608,   105,    99,   573,   469,    26,   576,   106,   106,
     105,   208,    97,    99,   106,   106,   213,    99,    97,   216,
     217,   218,    99,   106,    72,    77,   490,    78,   597,    79,
     494,   638,   639,    82,    26,   106,   606,   100,    26,   101,
      97,   610,    56,   143,    97,   652,   106,   101,    63,    18,
      96,   106,    99,   622,   518,   100,    99,   664,   100,   100,
      99,   666,    98,   527,    99,    99,    99,    98,   106,    99,
     267,   100,    98,   678,   106,    97,    95,   646,   106,   648,
     687,   688,   106,   100,   653,    98,    18,    96,   106,   100,
     697,   698,    98,    63,   106,   559,   560,   100,   106,   296,
     297,   298,   299,   300,   100,   100,   100,   106,   677,   106,
     717,    63,    18,   106,   100,   106,   100,   686,    63,   100,
      99,   690,    63,   692,    99,    18,   106,   100,   100,   106,
     106,   700,   100,   100,   331,   332,   100,   100,   100,   603,
     106,   106,   100,   712,   100,   106,   715,   344,   345,   420,
      19,    60,   721,    44,   266,   352,   163,   275,   264,   175,
     624,    45,    61,   123,   138,   629,   438,   602,   632,   438,
      26,   602,   294,   624,   371,   414,   412,   528,   425,    -1,
     531,    37,   417,   380,   381,   416,   415,    -1,    -1,    -1,
      46,   388,    -1,    49,   545,    -1,    -1,   394,   395,    -1,
     664,    -1,   399,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     407,    -1,   409,    69,    70,   412,    -1,   414,   415,   416,
     417,   418,   419,    -1,   421,   422,   423,   424,   425,   426,
     427,   428,   429,   430,    -1,   586,   587,    -1,   589,    -1,
      -1,    -1,    -1,    99,   100,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,   108,    -1,   110,    -1,   607,    -1,    -1,    -1,
      -1,   612,    -1,    -1,    -1,   462,    -1,    -1,   619,   208,
     621,    -1,    -1,    -1,   213,    -1,    -1,   216,   217,   218,
      -1,    -1,    -1,    -1,    -1,   636,   483,    -1,    -1,    -1,
      -1,    -1,    -1,   490,    -1,   492,    -1,   494,    -1,    -1,
     216,   217,    -1,    -1,     3,    -1,    -1,   658,   659,    -1,
     661,    -1,    11,    -1,    -1,    -1,    -1,   668,   515,    -1,
     671,    -1,    -1,   674,    23,   676,   523,    -1,   267,   526,
      -1,    30,   529,    -1,    33,   532,    -1,    36,    -1,    38,
      39,    40,    41,    -1,    -1,    44,    -1,    -1,    -1,    48,
     701,    -1,    -1,    52,    -1,    -1,    55,   296,   297,   298,
     299,   300,   559,   560,    -1,   716,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   572,    -1,    26,    -1,    -1,
     296,   297,   298,   299,   581,    -1,    -1,    -1,    37,    -1,
      -1,    -1,   331,   332,    -1,    -1,    -1,    46,    -1,    -1,
      49,    -1,   599,    -1,    -1,   344,   345,   106,    -1,    -1,
      -1,    60,    61,   352,    -1,    -1,    -1,    -1,    -1,    -1,
      69,    70,    -1,    -1,    73,    74,    -1,   624,    -1,    -1,
      -1,    -1,   371,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   380,   381,    -1,    -1,    -1,    95,    96,    -1,   388,
      99,    -1,   101,    -1,    -1,   394,   395,    -1,    -1,   108,
     399,   110,    -1,    -1,    -1,    -1,    -1,    -1,   407,   666,
     409,    -1,    -1,   412,    -1,   414,   415,   416,   417,   418,
     419,   678,   421,   422,   423,   424,   425,   426,   427,   428,
     429,   430,    -1,    -1,    -1,    -1,   412,    -1,   414,   415,
     416,   417,   418,   419,    -1,   421,   422,   423,   424,   425,
     426,   427,   428,   429,   430,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   462,    -1,    -1,    -1,   208,    -1,    -1,
      -1,    -1,   213,    -1,    -1,   216,   217,   218,    -1,    -1,
      -1,    -1,    -1,    -1,   483,    -1,    -1,    -1,    -1,    -1,
      -1,   490,    -1,   492,    -1,   494,    -1,    -1,   216,   217,
      -1,    -1,     3,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      11,    -1,    -1,    -1,   490,    -1,   515,    -1,   494,    -1,
      -1,    -1,    23,    -1,   523,    -1,   267,   526,    -1,    30,
     529,    -1,    33,   532,    -1,    36,    -1,    -1,    39,    40,
      41,    -1,    26,    44,    -1,    -1,    -1,    48,    -1,    -1,
      -1,    52,    -1,    37,    55,   296,   297,   298,   299,   300,
     559,   560,    46,    -1,    -1,    49,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   572,    -1,    -1,    -1,    -1,   296,   297,
     298,   299,   581,   559,   560,    69,    70,    -1,    -1,    -1,
     331,   332,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     599,    -1,    -1,   344,   345,   106,    -1,    -1,    -1,    -1,
      -1,   352,    -1,    -1,    -1,    99,   100,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   108,   624,   110,    -1,    -1,    -1,
     371,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   380,
     381,    -1,   350,    -1,    -1,    -1,    -1,   388,   624,    -1,
      -1,    -1,    -1,   394,   395,    -1,    -1,    -1,   399,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   407,   666,   409,    -1,
      -1,   412,    -1,   414,   415,   416,   417,   418,   419,   678,
     421,   422,   423,   424,   425,   426,   427,   428,   429,   430,
      -1,    -1,    -1,    -1,   412,    -1,   414,   415,   416,   417,
     418,   419,    -1,   421,   422,   423,   424,   425,   426,   427,
     428,   429,   430,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   462,    -1,    -1,    -1,   208,    -1,    -1,    -1,    -1,
     213,    -1,    -1,   216,   217,   218,    -1,    -1,    -1,    -1,
      -1,    -1,   483,    -1,    -1,    -1,    -1,    -1,    -1,   490,
      -1,   492,    -1,   494,    -1,    -1,    -1,     3,    -1,     5,
      -1,     7,    -1,    -1,    10,    -1,    -1,    -1,    -1,    -1,
      -1,    17,   490,    -1,   515,    -1,   494,    23,    24,    -1,
      26,    -1,   523,    -1,   267,   526,    32,    -1,   529,    35,
      36,   532,    -1,    39,    40,    41,    -1,    43,    44,    -1,
      -1,    -1,    48,    -1,    -1,    -1,    52,    -1,    54,    55,
      -1,    -1,    -1,   296,   297,   298,   299,   300,   559,   560,
     528,    -1,    -1,   531,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   572,    -1,    -1,    -1,    -1,    26,     3,    -1,    -1,
     581,   559,   560,    -1,    -1,    11,    -1,    37,   331,   332,
      96,    -1,    -1,    -1,    -1,    -1,    46,    23,   599,    49,
      -1,   344,   345,   109,    -1,    -1,    -1,    33,    -1,   352,
      36,    -1,    -1,    39,    40,    41,    -1,    -1,    44,    69,
      70,    -1,    48,   624,    -1,    -1,    52,    -1,   371,    55,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   380,   381,    -1,
     350,    -1,    -1,   611,    -1,   388,   624,    -1,    -1,    99,
     100,   394,   395,    -1,    -1,    -1,   399,    -1,   108,    -1,
     110,    -1,    -1,    -1,   407,   666,   409,    -1,   636,   412,
      -1,   414,   415,   416,   417,   418,   419,   678,   421,   422,
     423,   424,   425,   426,   427,   428,   429,   430,    -1,    -1,
     658,   659,    -1,   661,    -1,    -1,    -1,   665,    -1,   667,
     668,    -1,    -1,    -1,    -1,    -1,   674,    -1,   676,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   462,
      -1,    -1,    -1,   208,    -1,   693,    -1,   695,   213,    -1,
      -1,   216,   217,   218,    -1,    -1,   704,   705,    -1,   707,
     483,    -1,   710,    -1,    -1,   713,   714,   490,   716,   492,
      -1,   494,    -1,    -1,   722,     3,    -1,     5,    -1,     7,
      -1,    -1,    10,    -1,    -1,    -1,    -1,    -1,    -1,    17,
      -1,    -1,   515,    -1,    -1,    23,    24,    -1,    26,    -1,
     523,    -1,   267,   526,    32,    -1,   529,    35,    36,   532,
      -1,    39,    40,    41,    -1,    43,    44,    -1,    -1,    -1,
      48,    -1,    -1,    -1,    52,    -1,    54,    55,    -1,    -1,
      -1,   296,   297,   298,   299,   300,   559,   560,   528,    -1,
      -1,   531,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   572,
      -1,    26,    -1,    -1,    -1,    -1,    -1,    -1,   581,    -1,
      -1,    -1,    37,    -1,    -1,    -1,   331,   332,    -1,    -1,
      -1,    46,    -1,    -1,    49,    -1,   599,    -1,    -1,   344,
     345,   109,    -1,    -1,    -1,    60,    61,   352,    -1,    -1,
      -1,    -1,    -1,    -1,    69,    70,    -1,    -1,    73,    74,
      -1,   624,    -1,    -1,    -1,    -1,   371,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   380,   381,    -1,   350,    -1,
      -1,   611,    -1,   388,    99,    -1,    -1,    -1,    -1,   394,
     395,   106,    -1,   108,   399,   110,    -1,    -1,    -1,    -1,
      -1,    -1,   407,   666,   409,    -1,   636,   412,    -1,   414,
     415,   416,   417,   418,   419,   678,   421,   422,   423,   424,
     425,   426,   427,   428,   429,   430,    -1,    -1,   658,   659,
      -1,   661,    -1,    -1,    -1,   665,    -1,   667,   668,    -1,
      -1,    -1,    -1,    -1,   674,    -1,   676,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   462,    -1,    -1,
      -1,   208,    -1,   693,    -1,   695,   213,    -1,    -1,   216,
     217,   218,    -1,    -1,   704,   705,    -1,   707,   483,    -1,
     710,    -1,    -1,   713,   714,   490,   716,   492,    -1,   494,
      -1,    -1,   722,     3,    -1,     5,    -1,     7,    -1,    -1,
      10,    -1,    -1,    -1,    -1,    -1,    -1,    17,    -1,    -1,
     515,    -1,    -1,    23,    24,    -1,    26,    -1,   523,    -1,
     267,   526,    32,    -1,   529,    35,    36,   532,    -1,    39,
      40,    41,    -1,    43,    44,    -1,    -1,    -1,    48,    -1,
      -1,    -1,    52,    -1,    54,    55,    -1,    -1,    -1,   296,
     297,   298,   299,   300,   559,   560,    -1,    -1,    -1,   531,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,   572,    -1,    26,
      -1,    -1,    -1,    -1,    -1,    -1,   581,    -1,    -1,    -1,
      37,    -1,    -1,    -1,   331,   332,    -1,    -1,    -1,    46,
      -1,    -1,    49,    -1,   599,    -1,    -1,   344,   345,   109,
      -1,    -1,    -1,    60,    61,   352,    -1,    -1,    -1,    -1,
      -1,    -1,    69,    70,    -1,    -1,    73,    74,    -1,   624,
      -1,    -1,    -1,    -1,   371,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   380,   381,    -1,    -1,    -1,    95,   611,
      -1,   388,    99,    -1,    -1,    -1,    -1,   394,   395,    -1,
      -1,   108,   399,   110,    -1,    -1,    -1,    -1,    -1,    -1,
     407,   666,   409,    -1,   636,   412,    -1,   414,   415,   416,
     417,   418,   419,   678,   421,   422,   423,   424,   425,   426,
     427,   428,   429,   430,    -1,    -1,   658,   659,    -1,   661,
      -1,    -1,    -1,    -1,    -1,   667,   668,    -1,    -1,    -1,
      -1,    -1,   674,   208,   676,    -1,    -1,    -1,   213,    -1,
      -1,    -1,    -1,   218,    -1,   462,    -1,    -1,    -1,   208,
      -1,   693,    -1,   695,   213,    -1,    -1,   216,   217,   218,
      -1,    -1,   704,   705,    -1,   707,   483,    -1,   710,    -1,
      -1,   713,   714,   490,   716,   492,    -1,    -1,    -1,    -1,
     722,     3,    -1,     5,    -1,     7,    -1,    -1,    10,    -1,
      -1,    -1,   267,    -1,    -1,    17,    -1,    -1,   515,    -1,
      -1,    23,    24,    -1,    26,    -1,   523,    -1,   267,   526,
      32,    -1,   529,    35,    36,   532,    57,    39,    40,    41,
      -1,    43,    44,    -1,    -1,   300,    48,    -1,    -1,    -1,
      52,    -1,    54,    55,    -1,    -1,    -1,   296,   297,   298,
     299,   300,   559,    84,    85,    86,    87,    88,    89,    90,
      91,    92,    93,    94,    -1,   572,   331,   332,    -1,    -1,
      -1,    -1,    -1,    -1,   581,    -1,    -1,    -1,    -1,   344,
     345,    -1,   331,   332,    -1,    -1,    -1,   352,    -1,    -1,
      -1,    -1,   599,    -1,    -1,   344,   345,   109,    -1,    -1,
      -1,    -1,    -1,   352,    -1,    -1,   371,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   380,   381,   624,    -1,    -1,
      -1,    -1,   371,   388,    -1,    -1,    -1,    -1,    -1,   394,
     395,   380,   381,    -1,   399,    -1,    -1,    -1,    -1,   388,
      -1,    -1,   407,    -1,   409,   394,   395,    -1,    -1,    -1,
     399,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   407,   666,
     409,    -1,    -1,   412,    -1,   414,   415,   416,   417,   418,
     419,   678,   421,   422,   423,   424,   425,   426,   427,   428,
     429,   430,    -1,    -1,    -1,    -1,    -1,    -1,     3,    -1,
       5,    -1,     7,    -1,    -1,    10,    -1,   462,    -1,    -1,
      -1,    -1,    17,    -1,    -1,    -1,    -1,    -1,    23,    24,
      -1,    26,    -1,   462,    -1,    -1,    -1,    32,   483,    -1,
      35,    36,    -1,    -1,    39,    40,    41,   492,    43,    44,
      -1,    -1,    -1,    48,   483,    -1,    -1,    52,    -1,    54,
      55,   490,    -1,   492,    -1,    -1,    -1,    -1,    -1,    -1,
     515,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   523,    -1,
      -1,   526,    -1,    -1,   529,    -1,   515,   532,    57,    -1,
      -1,    -1,    -1,    -1,   523,    -1,    -1,   526,    -1,    -1,
     529,    -1,    -1,   532,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   109,    84,    85,    86,    87,    88,
      89,    90,    91,    92,    93,    94,    -1,   572,    -1,    -1,
     559,    -1,    -1,    -1,    -1,    -1,   581,     5,     6,     7,
       8,    -1,    10,   572,    -1,    -1,    14,    15,    16,    17,
      -1,    -1,   581,    -1,   599,    -1,    24,    25,    26,    27,
      -1,    -1,    -1,    -1,    32,    -1,    -1,    35,    -1,    37,
     599,    -1,    -1,    -1,    42,    43,    57,    -1,    46,    47,
      48,    49,    -1,    51,    -1,    53,    -1,    -1,    56,    -1,
      -1,    -1,    -1,    -1,    -1,   624,    -1,    -1,    -1,    -1,
      -1,    69,    70,    84,    85,    86,    87,    88,    89,    90,
      91,    92,    93,    94,    -1,    -1,    97,    -1,    99,    -1,
      -1,   666,    -1,    -1,   105,    -1,    -1,    95,    96,    -1,
      -1,    99,    -1,   678,    -1,    -1,    -1,   666,   106,    -1,
     108,   109,   110,     5,     6,     7,     8,    -1,    10,   678,
      -1,    -1,    14,    15,    16,    17,    -1,    -1,    -1,    -1,
      -1,    -1,    24,    25,    26,    27,    -1,    -1,    -1,    -1,
      32,    -1,    -1,    35,    -1,    37,    -1,    -1,    -1,    -1,
      42,    43,    26,    57,    46,    47,    48,    49,    -1,    51,
      -1,    53,    -1,    37,    56,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    46,    -1,    -1,    49,    -1,    69,    70,    -1,
      84,    85,    86,    87,    88,    89,    90,    91,    92,    93,
      94,    -1,    -1,    -1,    -1,    69,    70,    -1,    -1,    -1,
       5,     6,     7,    95,    96,    10,    -1,    99,    -1,    14,
      -1,    16,    17,    -1,   106,    -1,   108,   109,   110,    24,
      25,    26,    27,    -1,    -1,    99,   100,    32,    -1,    -1,
      35,    -1,    37,    -1,   108,    -1,   110,    42,    43,    26,
      -1,    46,    47,    48,    49,    -1,    51,    -1,    53,    -1,
      37,    56,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    46,
      -1,    -1,    49,    -1,    69,    70,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    69,    70,    -1,    -1,    -1,     5,     6,     7,
      95,    96,    10,    -1,    99,    -1,    14,    -1,    16,    17,
      -1,   106,    -1,   108,   109,   110,    24,    25,    26,    27,
      -1,    -1,    99,   100,    32,    -1,    -1,    35,    -1,    37,
      -1,   108,    -1,   110,    42,    43,    26,    -1,    46,    47,
      48,    49,    -1,    51,    -1,    53,    -1,    37,    56,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    46,    -1,    -1,    49,
      -1,    69,    70,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    69,
      70,    -1,    -1,    -1,     5,     6,     7,    95,    96,    10,
      -1,    99,    -1,    14,    -1,    16,    17,    -1,   106,    -1,
     108,   109,   110,    24,    25,    26,    27,    -1,    -1,    99,
     100,    32,    -1,    -1,    35,    -1,    37,    -1,   108,    -1,
     110,    42,    43,    26,    -1,    46,    47,    48,    49,    -1,
      51,    -1,    53,    -1,    37,    56,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    46,    -1,    -1,    49,    -1,    69,    70,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    69,    70,    -1,    -1,
      -1,     5,     6,     7,    95,    96,    10,    -1,    99,    -1,
      14,    -1,    16,    17,    -1,   106,    -1,   108,   109,   110,
      24,    25,    26,    27,    -1,    -1,    99,   100,    32,    -1,
      -1,    35,    -1,    37,    -1,   108,    -1,   110,    42,    43,
      26,    -1,    46,    47,    48,    49,    -1,    51,    -1,    53,
      -1,    37,    56,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      46,    -1,    -1,    49,    -1,    69,    70,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    69,    70,    -1,    -1,    -1,     5,     6,
       7,    95,    96,    10,    -1,    99,    -1,    14,    -1,    16,
      17,    -1,   106,    -1,   108,   109,   110,    24,    25,    26,
      27,    -1,    -1,    99,   100,    32,    -1,    -1,    35,    -1,
      37,    -1,   108,    -1,   110,    42,    43,    26,    -1,    46,
      47,    48,    49,    -1,    51,    -1,    53,    -1,    37,    56,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    46,    -1,    -1,
      49,    -1,    69,    70,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      69,    70,    -1,    -1,    -1,     5,     6,     7,    95,    96,
      10,    -1,    99,    -1,    14,    -1,    16,    17,    -1,   106,
      -1,   108,   109,   110,    24,    25,    26,    27,    -1,    -1,
      99,   100,    32,    -1,    -1,    35,    -1,    37,    -1,   108,
      -1,   110,    42,    43,    -1,    -1,    46,    47,    48,    49,
      -1,    51,    -1,    53,    -1,    -1,    56,    -1,    -1,     5,
      -1,     7,    -1,    -1,    10,    -1,    -1,    -1,    -1,    69,
      70,    17,    -1,    -1,    -1,    -1,    -1,    -1,    24,    -1,
      26,    -1,    -1,    -1,    -1,    -1,    32,    -1,    -1,    35,
      -1,    37,    -1,    -1,    -1,    95,    -1,    43,    -1,    99,
      46,    -1,    -1,    49,    -1,    -1,   106,    -1,   108,   109,
     110,    -1,    -1,    -1,    60,    61,    -1,     5,    -1,     7,
      -1,    -1,    10,    69,    70,    -1,    -1,    73,    74,    17,
      -1,    -1,    -1,    -1,    -1,    -1,    24,    -1,    26,    -1,
      -1,    -1,    -1,    -1,    32,    -1,    -1,    35,    -1,    37,
      -1,    -1,    -1,    99,    -1,    43,    -1,    -1,    46,    -1,
      -1,    49,   108,   109,   110,     5,    -1,     7,    -1,    -1,
      10,    -1,    -1,    -1,    -1,    -1,    -1,    17,    -1,    -1,
      -1,    69,    70,    -1,    24,    -1,    26,    -1,    -1,    -1,
      -1,    -1,    32,    -1,    -1,    35,     5,    37,     7,    -1,
      -1,    10,    -1,    43,    -1,    -1,    46,    -1,    17,    49,
      -1,    99,    -1,    -1,    -1,    24,    -1,    26,   106,    -1,
     108,   109,   110,    32,    -1,    -1,    35,    -1,    37,    69,
      70,     6,    -1,    -1,    43,    -1,    -1,    46,    -1,    14,
      49,    16,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      25,    26,    27,    -1,    -1,    -1,    -1,    -1,    -1,    99,
      69,    70,    37,    -1,    -1,    -1,   106,    42,   108,   109,
     110,    46,    47,    48,    49,    -1,    51,    -1,    53,    -1,
      -1,    56,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      99,    -1,    -1,    -1,    69,    70,     6,   106,    -1,   108,
     109,   110,    -1,    -1,    14,    -1,    16,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    25,    26,    27,    -1,    -1,
      95,    -1,    -1,    -1,    99,    -1,    -1,    37,    -1,    -1,
      -1,   106,    42,   108,    -1,   110,    46,    47,    48,    49,
      -1,    51,    -1,    53,    -1,    -1,    56,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    69,
      70,     6,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    14,
      -1,    16,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      25,    26,    27,    -1,    -1,    95,    -1,    -1,    -1,    99,
      -1,    -1,    37,    -1,    26,    -1,   106,    42,   108,    -1,
     110,    46,    47,    48,    49,    37,    51,    -1,    53,    -1,
      -1,    56,    26,    -1,    46,    -1,    -1,    49,    -1,    -1,
      -1,    -1,    -1,    37,    69,    70,    -1,    -1,    60,    61,
      -1,    -1,    46,    -1,    -1,    49,    -1,    69,    70,    -1,
      -1,    73,    74,    -1,    -1,    -1,    60,    61,    -1,    -1,
      95,    -1,    -1,    -1,    99,    69,    70,    26,    -1,    73,
      74,   106,    -1,   108,    26,   110,    98,    99,    37,    -1,
      -1,    -1,    -1,    -1,    -1,    37,   108,    46,   110,    -1,
      49,    -1,    -1,    -1,    46,    99,   100,    49,    -1,    -1,
      -1,    60,    61,    -1,   108,    -1,   110,    -1,    60,    61,
      69,    70,    -1,    -1,    73,    74,    -1,    69,    70,    26,
      -1,    73,    74,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      37,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    46,
      99,   100,    49,    -1,    -1,    -1,    -1,    99,   100,   108,
      26,   110,    -1,    60,    61,    -1,   108,    -1,   110,    -1,
      -1,    37,    69,    70,    -1,    -1,    73,    74,    -1,    -1,
      46,    -1,    -1,    49,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    60,    61,    -1,    -1,    -1,    -1,
      -1,    -1,    99,    69,    70,    26,    -1,    73,    74,   106,
      -1,   108,    26,   110,    -1,    -1,    37,    -1,    -1,    -1,
      -1,    -1,    -1,    37,    -1,    46,    -1,    -1,    49,    -1,
      -1,    -1,    46,    99,   100,    49,    -1,    -1,    -1,    60,
      61,    -1,   108,    -1,   110,    -1,    60,    61,    69,    70,
      -1,    -1,    73,    74,    -1,    69,    70,    -1,    -1,    73,
      74,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    26,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    98,    99,    37,
      -1,    -1,    -1,    -1,    26,    99,   100,   108,    46,   110,
      26,    49,    -1,    -1,   108,    37,   110,    -1,    -1,    -1,
      -1,    37,    60,    61,    46,    -1,    -1,    49,    -1,    -1,
      46,    69,    70,    49,    -1,    73,    74,    -1,    60,    61,
      -1,    -1,    -1,    -1,    60,    61,    -1,    69,    70,    -1,
      -1,    73,    74,    69,    70,    -1,    -1,    73,    74,    -1,
      -1,    99,   100,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
     108,    -1,   110,    -1,    -1,    -1,    26,    99,    -1,    -1,
      -1,    -1,    -1,    99,   106,    -1,   108,    37,   110,    -1,
     106,    -1,   108,    -1,   110,    -1,    46,    -1,    57,    49,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      60,    61,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    69,
      70,    -1,    -1,    73,    74,    84,    85,    86,    87,    88,
      89,    90,    91,    92,    93,    94,    -1,    -1,    97,    -1,
      99,    -1,    -1,    -1,    -1,    -1,   105,    -1,    -1,    99,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   108,    -1,
     110
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint16 yystos[] =
{
       0,     3,    11,    23,    30,    33,    36,    38,    39,    40,
      41,    44,    48,    52,    55,   106,   128,   129,   130,   131,
     132,   133,   134,   135,   136,   137,   138,   170,    26,   140,
      26,   114,   125,   126,   127,    26,   171,   125,     0,   130,
     132,   135,   129,   130,    11,    33,   137,    21,    29,   139,
     141,   142,   105,   106,   107,    21,   172,   173,   106,   130,
     140,   171,   117,   122,   125,   117,   123,   143,    95,   144,
     139,   142,   139,    26,   106,   123,    95,   174,   101,   172,
     139,   141,   142,   172,   173,   101,    96,   182,   144,   139,
     144,    96,   182,   123,   174,   144,   139,   142,   139,   174,
     172,   123,     5,     7,    10,    17,    24,    26,    32,    35,
      43,    44,    54,   109,   115,   116,   117,   118,   119,   120,
     121,   124,   125,   136,   145,   146,   147,   148,   153,   155,
     164,   165,   166,   167,   144,   136,   148,   155,   175,   176,
     177,   178,   144,   139,   144,   174,    95,   181,    26,   156,
     157,    26,   149,   150,   151,   157,    97,    97,    97,    54,
     115,   167,    96,   252,   154,    99,    50,   154,   161,   106,
      96,   176,   144,    96,   182,    99,    97,   161,   101,   106,
      57,    97,   161,    98,    98,    98,   157,   149,   157,   154,
     161,   146,   106,   163,   181,   158,   122,   162,    95,   168,
     154,     6,    14,    16,    25,    26,    27,    37,    42,    46,
      47,    48,    49,    51,    53,    56,    69,    70,    99,   106,
     108,   110,   113,   115,   125,   181,   183,   184,   185,   186,
     187,   189,   190,   191,   193,   194,   195,   196,   198,   200,
     206,   208,   209,   211,   219,   220,   221,   222,   223,   224,
     228,   229,   230,   232,   233,   234,   235,   241,   243,   262,
     263,   265,   266,   267,   158,    97,   252,   252,    98,   161,
     106,   161,   168,   154,   100,   115,   159,   160,   101,    46,
      49,    96,   169,   183,   168,    26,   106,    26,   106,   252,
      99,    63,   199,   117,   118,   122,    60,    61,    73,    74,
      99,   106,   125,   230,   234,   239,   240,   241,   245,   246,
     248,   249,   250,   251,   253,   254,   255,   256,   257,   258,
     259,   260,   261,   262,   263,   264,   265,   266,   267,   268,
     105,    99,    99,   239,   181,    99,   125,   232,   233,   261,
     261,   239,    26,   149,    97,    99,    96,   184,   106,   106,
     252,   105,    97,    57,    84,    85,    86,    87,    88,    89,
      90,    91,    92,    93,    94,   244,    69,    70,   100,   159,
     150,    95,   152,   179,   239,   168,   151,   100,   101,   122,
      99,    99,    96,   183,    96,   106,   106,   187,   106,   186,
     194,   216,   218,   187,    99,    97,   236,   237,   236,    99,
     261,   261,   261,   261,   118,   125,   239,    97,   106,   252,
      62,    71,   252,    72,   252,    77,    79,    78,    65,    68,
      31,    58,    59,    66,    67,    82,    73,    74,    75,    76,
      80,    26,   114,   239,   239,   106,     9,    22,   225,   226,
     227,   252,   100,   239,   100,   231,   239,    25,    26,    56,
     187,   188,   189,   192,   197,   198,   207,   210,   212,    26,
     114,   239,   242,   100,    96,   101,   152,   180,   252,   252,
     100,   231,   100,   231,    96,    56,   106,   239,   106,   252,
     101,   239,   239,    97,   237,   238,   238,   100,   231,    97,
     100,   238,    97,   238,   100,   239,   250,   253,   254,   255,
     256,   257,   257,   116,   118,   258,   258,   258,   258,   259,
     260,   260,   261,   261,   261,    99,   100,   100,    99,   181,
     226,   227,   213,   214,    98,   100,   101,    99,    63,    99,
     215,   252,    99,    98,   239,   252,    96,    96,   101,   160,
     106,   100,   106,   100,    99,   100,   217,   218,   106,   106,
     252,   106,   252,   100,    98,    98,    97,   100,   261,   100,
     100,   264,   247,   100,   231,    95,   201,   181,   160,   100,
     239,   239,   106,   216,   188,   239,    18,   188,   100,   231,
      96,   252,   106,   106,   252,   187,   100,   100,   217,   100,
     217,   213,   213,   194,    98,   261,   264,    63,   100,     8,
      15,    96,   202,   203,   204,   205,   100,   252,   106,   239,
     106,   100,   252,   215,   100,   152,   213,   187,   187,   100,
     187,   100,   106,   106,   252,   239,   269,    63,    96,   203,
     204,    96,   183,   205,   181,   187,   100,   217,   106,   106,
     252,    25,    26,    56,   188,   189,   198,   187,    18,   100,
     187,   187,   252,   100,   245,    63,    96,   188,   100,   100,
     217,   100,   217,   213,    99,    63,    99,   252,   252,   106,
     217,   252,   188,   188,   100,   188,   100,   106,   106,   216,
     188,   188,   215,   187,   188,   188,   100,   252,   106,   239,
     106,   215,   100,   252,   217,   100,   217,   106,   106,   252,
      18,   252,   188,   215,   100,   100,   217,   100,   217,   213,
     252,   187,   100,   100,   100,   106,   252,   252,   188,   217,
     215,   100,   252
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 115 "parser.y"
    { 
								(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].num)->str, "CONST_LITERAL");
								(yyval.ptr)->type = (yyvsp[(1) - (1)].num)->type; // either "int" or "double"
								(yyval.ptr)->int_val = (yyvsp[(1) - (1)].num)->int_val;
								(yyval.ptr)->real_val = (yyvsp[(1) - (1)].num)->real_val;
								(yyval.ptr)->expType = 4; // expression type 4 
								(yyval.ptr)->temp_name = (yyvsp[(1) - (1)].num)->str;
								(yyval.ptr)->isInit = 1;
								//--3AC
								sym_entry* temp = new sym_entry;
								if((yyvsp[(1) - (1)].num)->type != "char" ) (yyval.ptr)->place = qid(to_string((yyvsp[(1) - (1)].num)->int_val), temp);
								// if($1->type != "char" && $1->int_val==-1 ) $$->place = qid(to_string($1->real_val), temp);
								// if($1->type != "char") $$->place = qid(to_string($1->int_val), temp);
								else (yyval.ptr)->place = qid((yyvsp[(1) - (1)].num)->str, temp);
								(yyval.ptr)->nextlist.clear();
								
					 ;}
    break;

  case 3:
#line 132 "parser.y"
    {
						(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "STRING_LITERAL");
						(yyval.ptr)->type = string("char*"); // may need to change later 
						(yyval.ptr)->temp_name = string((yyvsp[(1) - (1)].str));
						(yyval.ptr)->str_val = string((yyvsp[(1) - (1)].str)); 
						
						//--3AC
						string str = string((yyvsp[(1) - (1)].str));
						sym_entry* temp = new sym_entry;
						(yyval.ptr)->place = qid(str, temp);
						(yyval.ptr)->nextlist.clear();
					;}
    break;

  case 4:
#line 146 "parser.y"
    { 
									(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "IDENTIFIER");

									bool is_place_set= false;
									string t;
									int flag=0;
									//
									
									string temp= primExpr("CLASS_"+string((yyvsp[(1) - (1)].str)));
									
									if(temp!="") 
									{
										flag=1;
									}
									if(temp=="")  temp = primExpr(string((yyvsp[(1) - (1)].str)));
									
									if(temp == ""){
										yyerror(("Undeclared Identifier " + string((yyvsp[(1) - (1)].str))).c_str());
									}
									else{
										if(temp.substr(0, 5) == "FUNC_"){
											(yyval.ptr)->expType = 3; // 3 is function 
										}
										else if(temp.back() == '*'){ 
											(yyval.ptr)->expType = 2;  // 2 is array
											sym_entry* sym=  Lookup(string((yyvsp[(1) - (1)].str)));
											if(sym==nullptr) 
											{
												yyerror((string((yyvsp[(1) - (1)].str)) + " array not declared before access").c_str());
											}
											// cout<<"Array id "<<sym->place<<"\n";
											(yyval.ptr)->place= qid(sym->place, sym);
											is_place_set= true;
										}
										else (yyval.ptr)->expType = 1; // 1 is variable 
										if(temp.substr(0,5)=="FUNC_" && temp.back() == '#'){
											// which case? 
											temp.pop_back();
											(yyval.ptr)->type = temp;
											(yyval.ptr)->temp_name = string((yyvsp[(1) - (1)].str)); 
											(yyval.ptr)->nextlist.clear();
										}
										else{

											(yyval.ptr)->type = temp;
											string s;
											if(flag) s= "CLASS_"+string((yyvsp[(1) - (1)].str));
											else s= string((yyvsp[(1) - (1)].str));
											(yyval.ptr)->isInit = Lookup(s)->init;
											// sym_entry* has init and node* has isInit 
											(yyval.ptr)->size = GetSize(temp); // returns size of type of the identifier s. 
											(yyval.ptr)->temp_name = string((yyvsp[(1) - (1)].str)); 
											//--3AC
											sym_entry* sym= Lookup(s);
											// cout<<"In id offsets  "<<string($1)<<" "<<sym->offset<<endl;
											if(find(classNamelist.begin(), classNamelist.end(), sym->type)!=classNamelist.end())
											{
												(yyval.ptr)->place= qid(sym->place, sym);
												is_place_set= true;
											}
											if(sym->offset<0) // function argument 
											{
												//  cout<<"Is offfset negative?\n";
												 (yyval.ptr)->place= qid(sym->place, sym);
												 is_place_set= true;
											}
											if(!is_place_set) (yyval.ptr)->place = qid(string((yyvsp[(1) - (1)].str)), Lookup(s));
											(yyval.ptr)->nextlist.clear();
										}
									
									} 
							;}
    break;

  case 5:
#line 220 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 6:
#line 221 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 7:
#line 225 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 8:
#line 226 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 9:
#line 229 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 10:
#line 231 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 11:
#line 232 "parser.y"
    { 
									(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "BOOLEAN"); 
									// Semantics
									if(type == "") type ="int";
									else type += " int";
									// boolean treated as one byte
									(yyval.ptr)->size= 4;
									(yyval.ptr)->type= "bool";
							;}
    break;

  case 12:
#line 243 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 13:
#line 244 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 14:
#line 247 "parser.y"
    { 
							(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "LONG"); 
								// Semantics
							if(type == "") type = string((yyvsp[(1) - (1)].str));
							// only primiive types are supported 
							// long long not likely to occur 
							else type += " " + string((yyvsp[(1) - (1)].str));
							(yyval.ptr)->size= 8;
							(yyval.ptr)->type= "long";
					;}
    break;

  case 15:
#line 257 "parser.y"
    { 
				  			(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "BYTE");
			  				
							// Semantics
							if(type == "") type = string((yyvsp[(1) - (1)].str));
							else type += " " + string((yyvsp[(1) - (1)].str));
							(yyval.ptr)->size= 1;
							(yyval.ptr)->type= "byte";
				  ;}
    break;

  case 16:
#line 266 "parser.y"
    { 
							(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "INT"); 

							// Semantics
							if(type == "") type = string((yyvsp[(1) - (1)].str));
							else type += " " + string((yyvsp[(1) - (1)].str));
							(yyval.ptr)->size= 4;
							(yyval.ptr)->type= "int";
					;}
    break;

  case 17:
#line 275 "parser.y"
    { 
				  			(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "CHAR");
							
							// Semantics
							if(type == "") type = string((yyvsp[(1) - (1)].str));
							else type += " " + string((yyvsp[(1) - (1)].str));
							(yyval.ptr)->size= 1;
							(yyval.ptr)->type= "char";
				 ;}
    break;

  case 18:
#line 284 "parser.y"
    { 
				  			(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "SHORT"); 

							// Semantics
							if(type == "") type = string((yyvsp[(1) - (1)].str));
							else type += " " + string((yyvsp[(1) - (1)].str));
							(yyval.ptr)->size= 2;
							(yyval.ptr)->type= "short";
			  ;}
    break;

  case 19:
#line 293 "parser.y"
    {
								(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "STRING"); 

								// Semantics
								if(type == "") type = "char*";
								else type += " char*";
								(yyval.ptr)->size= 8;
								(yyval.ptr)->type= "String";
			  ;}
    break;

  case 20:
#line 304 "parser.y"
    {
								 (yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "DOUBLE"); 
								 
								// Semantics
								if(type == "") type = string((yyvsp[(1) - (1)].str));
								else type += " " + string((yyvsp[(1) - (1)].str));
								(yyval.ptr)->size= 8;
						;}
    break;

  case 21:
#line 312 "parser.y"
    { 
						 			(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "FLOAT");
								
									// Semantics
									if(type == "") type = string((yyvsp[(1) - (1)].str));
									else type += " " + string((yyvsp[(1) - (1)].str));
									(yyval.ptr)->size= 4;
					;}
    break;

  case 22:
#line 322 "parser.y"
    {
						(yyval.ptr) = (yyvsp[(1) - (1)].ptr);
						qid tmp = newtemp((yyval.ptr)->type);
						qid tmp1 = newtemp((yyval.ptr)->type);
						// cout<<"If found kdhe "<<if_found<<"\n";
						int temp=1;
						// cout<<"SISZEEC "<<$3->dims[0]<<" "<<$3->dims.size()<<endl;
						// cout<<"DA TYPEC IS "<<$2->type<<endl;
						// for(int i=0;i<$3->dims.size();i++)
						// {
						// 	temp*=$3->dims[i];
						// }
						sym_entry* sym= Lookup(className);
						// cout<<"Found type is "<<sym->type<<endl;
						if (sym ==nullptr){
							yyerror(("Field size not found in class "+ className).c_str());
						}
						emit(qid("NEW", sym), qid(to_string(sym->fieldsize), NULL), tmp1, tmp, -1);	
						(yyval.ptr)->place= tmp1;
						(yyval.ptr)->expType= 3;
						// qid tmp1 = newtemp($$->type);
						// emit(qid("NEW", sym), qid(to_string(sym->fieldsize), NULL), qid("", NULL), tmp, -1);	
		;}
    break;

  case 23:
#line 347 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 24:
#line 350 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(v, NULL, "[ ]", 0);
		(yyval.ptr) = create_AST_node("ArrKind1", v);
	;}
    break;

  case 25:
#line 356 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(v, NULL, "[ ]", 0);
		(yyval.ptr) = create_AST_node("ArrKind2", v);
	;}
    break;

  case 26:
#line 362 "parser.y"
    { // ASSUMING NAME IS IDENITFIER FOR NOE
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(v, NULL, "[ ]", 0);
		(yyval.ptr) = create_AST_node("ArrKind3", v);

		// needs to be filled in for type checking and 3AC. Arrays incomplete 
	;}
    break;

  case 27:
#line 373 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 28:
#line 374 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 29:
#line 377 "parser.y"
    {
								(yyval.ptr) = (yyvsp[(1) - (1)].ptr);
								// special_type= $1->temp_name;
								// special_type was an attempt to recognise class names. 
								// Not used. 
						;}
    break;

  case 30:
#line 384 "parser.y"
    {
	// Name FST IDENTIFIER {
		vector<treeNode> attr;
		add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(attr, create_AST_leaf((yyvsp[(3) - (3)].str), "IDENTIFIER"), "", 1);
		(yyval.ptr) = create_AST_node("QualName", attr);

		// treats similar to a struct 
		if(!(yyvsp[(1) - (3)].ptr)->is_error && (yyvsp[(1) - (3)].ptr)->expType!=4){
			string temp = string((yyvsp[(3) - (3)].str));
			// cout<<"Will call find_table now"<<"\n";
			sym_table* ret = find_table("CLASS_"+(yyvsp[(1) - (3)].ptr)->type);
			if(ret == nullptr){
				yyerror(("Class " + (yyvsp[(1) - (3)].ptr)->name + " not defined").c_str());
				(yyval.ptr)->is_error = 1;
			}
			// else{
			// 	cout<<"ret="<<"CLASS_"+$1->type<<endl;
			// 	for(map<string, sym_entry*>::iterator it = ret->begin(); it!=ret->end(); it++){ cout<<it->first<<endl; }
			// }
			sym_entry* r;
			r= find_in_table(temp, ret);
			if (r == nullptr){
				yyerror(("Class " + (yyvsp[(1) - (3)].ptr)->type + " has no field " + string((yyvsp[(3) - (3)].str))).c_str());
				(yyval.ptr)->is_error = 1;
			}
			else{
				(yyval.ptr)->type = r->type;
				(yyval.ptr)->temp_name = (yyvsp[(1) - (3)].ptr)->temp_name + "." + temp;
				qid temp_var1 = newtemp((yyval.ptr)->type);
				emit(qid("=", r), qid(to_string(r->offset),NULL), qid("",NULL), temp_var1, -1);
				qid temp_var = newtemp((yyval.ptr)->type);
				// adds a temporary variable(for 3AC) to symbol table. 
				// cout<<"In qual name "<<$1->place.first<<endl;
				sym_entry* attr_sym = retTypeAttrEntry(r);
				emit(qid("qualname", r), (yyvsp[(1) - (3)].ptr)->place, temp_var1, temp_var, -1);
				temp_var.second->array_dims = attr_sym->array_dims;
				(yyval.ptr)->place = temp_var;
			}
		}
		else{
			if((yyvsp[(1) - (3)].ptr)->expType==4){
				yyerror("constant expression cannot be used as lvalue");
			}
			(yyval.ptr)->is_error = 1;
		}
	;}
    break;

  case 31:
#line 434 "parser.y"
    {
	// have not supported imports and packages yet. 
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("CompUnit1",v);
	;}
    break;

  case 32:
#line 442 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 33:
#line 443 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (2)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("CompUnit2",v);
	;}
    break;

  case 34:
#line 449 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 35:
#line 450 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 36:
#line 452 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (2)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("CompUnit3",v);
	;}
    break;

  case 37:
#line 458 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (2)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("CompUnit4",v);
	;}
    break;

  case 38:
#line 467 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 39:
#line 468 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (2)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ImportDecnRec",v);
	;}
    break;

  case 40:
#line 476 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 41:
#line 477 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (2)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("TypeDecRec",v);
	;}
    break;

  case 42:
#line 485 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, create_AST_leaf((yyvsp[(1) - (3)].str), ""), "", 1);
		add_attribute(v, (yyvsp[(2) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("PackageDecn", v);
	;}
    break;

  case 43:
#line 493 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 44:
#line 494 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 45:
#line 500 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(2) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("SingleTypeImportDecn",v); 
	;}
    break;

  case 46:
#line 507 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(2) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ImportDDec ",v); 
	;}
    break;

  case 47:
#line 514 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 48:
#line 515 "parser.y"
    { (yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "SCLN"); ;}
    break;

  case 49:
#line 516 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr); ;}
    break;

  case 50:
#line 519 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 51:
#line 520 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (2)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("Modifiers",v);

		//Semantic 
		(yyval.ptr)->type= (yyvsp[(1) - (2)].ptr)->type+ " "+ (yyvsp[(2) - (2)].ptr)->type;
	;}
    break;

  case 52:
#line 535 "parser.y"
    {  
										(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "FINAL");
										// Semantic
										(yyval.ptr)->type= string((yyvsp[(1) - (1)].str));
										// $$->modifiers[0]=1;
				 ;}
    break;

  case 53:
#line 541 "parser.y"
    { 
			  						(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "PRIVATE");
		  							// Semantic
									(yyval.ptr)->type= string((yyvsp[(1) - (1)].str));
			   ;}
    break;

  case 54:
#line 546 "parser.y"
    { 
			  						(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "PROTECTED"); 
		  							// Semantic
									(yyval.ptr)->type= string((yyvsp[(1) - (1)].str));
			   ;}
    break;

  case 55:
#line 551 "parser.y"
    { 
			  					(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "NATIVE");
		  							// Semantic
									(yyval.ptr)->type= string((yyvsp[(1) - (1)].str));
			   ;}
    break;

  case 56:
#line 556 "parser.y"
    { 
			  					(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "SYNCHRONIZED");
		  							// Semantic
									(yyval.ptr)->type= string((yyvsp[(1) - (1)].str));
			   ;}
    break;

  case 57:
#line 561 "parser.y"
    { 
			  					(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "STATIC");
		  							// Semantic
									(yyval.ptr)->type= string((yyvsp[(1) - (1)].str));
			   ;}
    break;

  case 58:
#line 566 "parser.y"
    { 
			  					 (yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "PUBLIC");
		  							// Semantic
									(yyval.ptr)->type= string((yyvsp[(1) - (1)].str));
			   ;}
    break;

  case 59:
#line 571 "parser.y"
    { 
			  					 (yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "TRANSIENT"); 
		  							// Semantic
									(yyval.ptr)->type= string((yyvsp[(1) - (1)].str));
			   ;}
    break;

  case 60:
#line 576 "parser.y"
    { 
			  					(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "ABSTRACT"); 
		  							// Semantic
									(yyval.ptr)->type= string((yyvsp[(1) - (1)].str));
			   ;}
    break;

  case 61:
#line 581 "parser.y"
    { 
			  				(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "VOLATILE");
		  							// Semantic
									(yyval.ptr)->type= string((yyvsp[(1) - (1)].str));
		  ;}
    break;

  case 62:
#line 590 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (7)].ptr), "", 1);
		add_attribute(v, create_AST_leaf((yyvsp[(3) - (7)].str), "IDENTIFIER"), "", 1);
		add_attribute(v, (yyvsp[(4) - (7)].ptr), "", 1);
		add_attribute(v, (yyvsp[(5) - (7)].ptr), "", 1);
		add_attribute(v, (yyvsp[(7) - (7)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ClassDecn1", v);

		string cName= className.substr(6, className.size()-6);
		classType= string((yyvsp[(1) - (7)].ptr)->type); // by default it is private
		printSymbolTable(curr_table ,className + ".csv");
		SymbolTableUpdation(className, 1);		
	;}
    break;

  case 63:
#line 604 "parser.y"
    {
		vector<treeNode> v;
		// add_attribute(v, $2, "", 1);
		add_attribute(v, create_AST_leaf((yyvsp[(2) - (5)].str), "IDENTIFIER"), "",1);
		add_attribute(v, (yyvsp[(3) - (5)].ptr), "", 1);
		add_attribute(v, (yyvsp[(5) - (5)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ClassDecn4", v);

		string cName= className.substr(6, className.size()-6);
		classType= "private"; // by default it is private
		printSymbolTable(curr_table ,className + ".csv");
		SymbolTableUpdation(className, 1);		
	;}
    break;

  case 64:
#line 617 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (6)].ptr), "", 1);
		add_attribute(v, create_AST_leaf((yyvsp[(3) - (6)].str), "IDENTIFIER"), "",1);
		add_attribute(v, (yyvsp[(4) - (6)].ptr), "", 1);
		add_attribute(v, (yyvsp[(6) - (6)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ClassDecn5", v);
		// Symbol table 
		string cName= className.substr(6, className.size()-6);
		classType= string((yyvsp[(1) - (6)].ptr)->type); // by default it is private
		printSymbolTable(curr_table ,className + ".csv");
		SymbolTableUpdation(className, 1);				
	;}
    break;

  case 65:
#line 630 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, create_AST_leaf((yyvsp[(2) - (5)].str), "IDENTIFIER"), "",1);
		add_attribute(v, (yyvsp[(3) - (5)].ptr), "", 1);
		add_attribute(v, (yyvsp[(5) - (5)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ClassDecn6", v);
		classType= "private"; // by default it is private
		type = "";
		field_size=0;
		string cName= className.substr(6, className.size()-6);
		printSymbolTable(curr_table ,className + ".csv");
		SymbolTableUpdation(className, 1);	
	;}
    break;

  case 66:
#line 644 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (5)].ptr), "", 1);
		add_attribute(v, create_AST_leaf((yyvsp[(3) - (5)].str), "IDENTIFIER"), "",1);
		add_attribute(v, (yyvsp[(5) - (5)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ClassDecn7", v);
		
		// Symbol table 
		classType= string((yyvsp[(1) - (5)].ptr)->type);
		type = "";
		field_size=0;
		string cName= className.substr(6, className.size()-6);
		printSymbolTable(curr_table ,className + ".csv");
		SymbolTableUpdation(className, 1);

	;}
    break;

  case 67:
#line 660 "parser.y"
    {
					
		vector<treeNode> v;
		add_attribute(v, create_AST_leaf((yyvsp[(2) - (4)].str), "IDENTIFIER"), "",1);
		add_attribute(v, (yyvsp[(4) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ClassDecn8", v);

		// Symbol tabl
		// cout<<"Class table "<<className<<endl; 
		classType= string("private"); // by default it is private
		type = "";
		string cName= className.substr(6, className.size()-6);
		printSymbolTable(curr_table ,className + ".csv");
		SymbolTableUpdation(className, 1);		
	;}
    break;

  case 68:
#line 675 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, create_AST_leaf((yyvsp[(2) - (6)].str), "IDENTIFIER"), "",1);
		add_attribute(v, (yyvsp[(3) - (6)].ptr), "", 1);
		add_attribute(v, (yyvsp[(4) - (6)].ptr), "", 1);
		add_attribute(v, (yyvsp[(6) - (6)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ClassDecn2", v);

		classType= string("private"); // by default it is private
		type = "";
		string cName= className.substr(6, className.size()-6);
		printSymbolTable(curr_table ,className + ".csv");
		SymbolTableUpdation(className, 1);	
	;}
    break;

  case 69:
#line 689 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (6)].ptr), "", 1);
		add_attribute(v, create_AST_leaf((yyvsp[(3) - (6)].str), "IDENTIFIER"), "",1);
		add_attribute(v, (yyvsp[(4) - (6)].ptr), "", 1);
		add_attribute(v, (yyvsp[(6) - (6)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ClassDecn3", v);

		classType= string((yyvsp[(1) - (6)].ptr)->type);
		type = "";
		string cName= className.substr(6, className.size()-6);
		field_size=0;
		printSymbolTable(curr_table ,cName + ".csv");
		SymbolTableUpdation(className, 1);
	;}
    break;

  case 70:
#line 706 "parser.y"
    { 	
		string cName= string("DummyC_name"+to_string(classnum));
		classnum++;

			// cout<<"CLass name is "<<className<<"\n";
		classType= string("private"); // by default it is private
		if (gst.find(className) != gst.end()){
			yyerror(("Redefinition of class " + cName).c_str());
		}
		else{
			CreateSymbolTable(className, classType, 0,0 ); // global vars
		
			// insertSymbol(*curr_table, className, className.substr(6, className.size()-6), 0, 0, NULL);
			block_count = 1;
		}
		type = "";
 	;}
    break;

  case 71:
#line 724 "parser.y"
    {
							(yyval.str)=(yyvsp[(1) - (1)].str);
							className= "CLASS_"+string((yyvsp[(1) - (1)].str));
							classNamelist.push_back(string((yyvsp[(1) - (1)].str)));
							// add 3AC support. 
;}
    break;

  case 72:
#line 732 "parser.y"
    {
		vector<treeNode> v;
		// add_attribute(v, create_AST_leaf($1, "EXTENDS"), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("Super", v);
	;}
    break;

  case 73:
#line 739 "parser.y"
    {
		vector<treeNode> v;
		// add_attribute(v, create_AST_leaf($1, "IMPLEMENTS"), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("Intfaces", v);
	;}
    break;

  case 74:
#line 747 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 75:
#line 748 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("IntfaceTypeList", v);
	;}
    break;

  case 76:
#line 756 "parser.y"
    {(yyval.ptr) = create_AST_leaf("{ }", "LITERAL");;}
    break;

  case 77:
#line 757 "parser.y"
    {
			   
			//    $$=$2;
			vector<treeNode> v;
			add_attribute(v, (yyvsp[(3) - (4)].ptr), "", 1);
			(yyval.ptr) = create_AST_node("Block", v);

			if(func_flag>=2){
				int bc = block_stack.top();
				block_stack.pop();
				string str = "Block" + to_string(bc);
				string name = funcName+str+".csv";
				printSymbolTable(curr_table, name);
				SymbolTableUpdation(str, 0);
				func_flag--;
			}
		;}
    break;

  case 78:
#line 777 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 79:
#line 778 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("Class!", v);

		if((yyvsp[(1) - (3)].ptr)->is_error || (yyvsp[(3) - (3)].ptr)->is_error)	{
			(yyval.ptr)->is_error = 1;
		}
        backpatch((yyvsp[(1) - (3)].ptr)->nextlist, (yyvsp[(2) - (3)].number));
        (yyval.ptr)->nextlist = (yyvsp[(3) - (3)].ptr)->nextlist;
		(yyvsp[(1) - (3)].ptr)->caselist.insert((yyvsp[(1) - (3)].ptr)->caselist.end(), (yyvsp[(3) - (3)].ptr)->caselist.begin(), (yyvsp[(3) - (3)].ptr)->caselist.end());
        (yyval.ptr)->caselist = (yyvsp[(1) - (3)].ptr)->caselist;
		(yyvsp[(1) - (3)].ptr)->continuelist.insert((yyvsp[(1) - (3)].ptr)->continuelist.end(), (yyvsp[(3) - (3)].ptr)->continuelist.begin(), (yyvsp[(3) - (3)].ptr)->continuelist.end());
        (yyvsp[(1) - (3)].ptr)->breaklist.insert((yyvsp[(1) - (3)].ptr)->breaklist.end(), (yyvsp[(3) - (3)].ptr)->breaklist.begin(), (yyvsp[(3) - (3)].ptr)->breaklist.end());
        (yyval.ptr)->continuelist = (yyvsp[(1) - (3)].ptr)->continuelist;
        (yyval.ptr)->breaklist = (yyvsp[(1) - (3)].ptr)->breaklist;
	;}
    break;

  case 80:
#line 798 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 81:
#line 799 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 82:
#line 800 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 83:
#line 803 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 84:
#line 804 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 85:
#line 807 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("FieldDecn1", v);

		// $$->type= $2->type;
		// $$->size= $2->size;
		type = "";
		type_delim = 0;
		storage_class = "";
		
		if(!(yyvsp[(2) - (4)].ptr)->is_error && !(yyvsp[(3) - (4)].ptr)->is_error){
			// 3AC
			(yyval.ptr)->nextlist = (yyvsp[(3) - (4)].ptr)->nextlist;
		}
		else (yyval.ptr)->is_error = 1;
		// cout<<"Field decn ."<<$2->type<<" "<<type<<endl;
		field_size+= GetSize((yyvsp[(2) - (4)].ptr)->type);
		sym_entry* sym= Lookup(className);
		if (sym ==nullptr){
			yyerror((className+ " not inserted in symbol table").c_str());
		}
		else 
		{
			sym->fieldsize= field_size;
			//cout<<"FIelddejnb2 "<<field_size<<" "<<sym->type<<endl;
		}
		// field_size=0;
;}
    break;

  case 86:
#line 838 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("FieldDecn2", v);

		type = "";
		type_delim = 0;
		storage_class = "";
		
		if(!(yyvsp[(1) - (3)].ptr)->is_error && !(yyvsp[(2) - (3)].ptr)->is_error){
			// 3AC
			(yyval.ptr)->nextlist = (yyvsp[(2) - (3)].ptr)->nextlist;
		}
		else (yyval.ptr)->is_error = 1;
		//cout<<"Field decn1 "<<$2->type<<" "<<type<<endl;
		field_size+= GetSize((yyvsp[(2) - (3)].ptr)->type);
		sym_entry* sym= Lookup(className);
		if (sym ==nullptr){
			yyerror((className+ " not inserted in symbol table").c_str());
		}
		else 
		{
			sym->fieldsize= field_size;
			//cout<<"FIelddejnb2 "<<field_size<<" "<<sym->type<<endl;
		}
		// field_size=0;
		// $$->type= $1->type;
		// $$->size= $1->size;
;}
    break;

  case 87:
#line 870 "parser.y"
    {
											(yyval.ptr) = (yyvsp[(1) - (1)].ptr);
											varlist.push_back((yyvsp[(1) - (1)].ptr)->temp_name);
					;}
    break;

  case 88:
#line 874 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(4) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("VariableDecltrs", v);
		varlist.push_back((yyvsp[(4) - (4)].ptr)->temp_name);

		if(!(yyvsp[(1) - (4)].ptr)->is_error && !(yyvsp[(4) - (4)].ptr)->is_error){
			// 3AC
			backpatch((yyvsp[(1) - (4)].ptr)->nextlist, (yyvsp[(3) - (4)].number));
			(yyval.ptr)->nextlist = (yyvsp[(4) - (4)].ptr)->nextlist;
		}
		else (yyval.ptr)->is_error = 1;

;}
    break;

  case 89:
#line 891 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);

										// Semantics
										if(!(yyvsp[(1) - (1)].ptr)->is_error){
											if(CurLookup((yyvsp[(1) - (1)].ptr)->temp_name) ){
												string errstr = (yyvsp[(1) - (1)].ptr)->temp_name + " is already declared";
												yyerror(errstr.c_str());
												(yyval.ptr)->is_error = 1;
											}
											else if((yyvsp[(1) - (1)].ptr)->expType == 3){
												if(fn_decl){
													yyerror("A parameter list without types is only allowed in a function definition");
													(yyval.ptr)->is_error = 1;
													fn_decl = 0;
												}
												DeleteFunctionPrototype();
												code.pop_back();
											}
											else{
												if(storage_class != "typedef"){
													// cout<<"IN HERE YES1 "<<$1->temp_name<<" with type "<<$1->type<<"\n";
													// if($1->type=="") 
													// {
														
													// 	$1->type= className.substr(6, className.size()-6);
													// 	cout<<"IN HERE YES\n";
													// }
													insertSymbol(*curr_table, (yyvsp[(1) - (1)].ptr)->temp_name, (yyvsp[(1) - (1)].ptr)->type, (yyvsp[(1) - (1)].ptr)->size, 0, NULL);
													(yyval.ptr)->place = qid((yyvsp[(1) - (1)].ptr)->temp_name, Lookup((yyvsp[(1) - (1)].ptr)->temp_name));
													isArray = 0;
												}
												else{
													insertTypedef(*curr_table, (yyvsp[(1) - (1)].ptr)->temp_name, (yyvsp[(1) - (1)].ptr)->type, (yyvsp[(1) - (1)].ptr)->size, 0, NULL);
													(yyval.ptr)->place = qid((yyvsp[(1) - (1)].ptr)->temp_name, Lookup((yyvsp[(1) - (1)].ptr)->temp_name));
												} 
											}
										}
										else (yyval.ptr)->is_error = 1;
;}
    break;

  case 90:
#line 931 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(4) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node((yyvsp[(2) - (4)].str), v);

		// Semantics
		bool place_is_set= false;
		if(!(yyvsp[(1) - (4)].ptr)->is_error && !(yyvsp[(4) - (4)].ptr)->is_error){
			if( CurLookup((yyvsp[(1) - (4)].ptr)->temp_name) ){ // eaelier part 
				string errstr = (yyvsp[(1) - (4)].ptr)->temp_name + " is already declared";
				yyerror(errstr.c_str());
				(yyval.ptr)->is_error = 1;
			}
			else{
				if(findStruct((yyvsp[(1) - (4)].ptr)->type) && (yyvsp[(1) - (4)].ptr)->type[0] == 'u') (yyvsp[(1) - (4)].ptr)->size = GetSize((yyvsp[(1) - (4)].ptr)->type);
				else (yyvsp[(1) - (4)].ptr)->size = (yyvsp[(1) - (4)].ptr)->size> (int)initializer_list_values.size()*4 ? (yyvsp[(1) - (4)].ptr)->size: (int)initializer_list_values.size()*4 ;
				// cout<<"LVD 1\n";
				if((yyvsp[(1) - (4)].ptr)->type=="")
				{
						// cout<<"BAD\n";
						// cout<<"HI THEN "<<$4->type<<"\n";
						(yyvsp[(1) - (4)].ptr)->type= (yyvsp[(4) - (4)].ptr)->type;
				}
				// cout<<"Inserting symbol "<<$4->place.first<<endl;
				insertSymbol(*curr_table, (yyvsp[(1) - (4)].ptr)->temp_name, (yyvsp[(1) - (4)].ptr)->type, (yyvsp[(1) - (4)].ptr)->size, 1, NULL);
				// $$->place= $4->place;
				sym_entry* sym= Lookup((yyvsp[(1) - (4)].ptr)->temp_name);
				if(find(classNamelist.begin(), classNamelist.end(), (yyvsp[(1) - (4)].ptr)->type)!=classNamelist.end())
				{
					sym->place= (yyvsp[(4) - (4)].ptr)->place.first;
					place_is_set=true;
				}
				else if(sym->type.back()=='*')
				{
					// cout<<"Variable INit"<< $4->place.first<<"\n";
					sym->place= (yyvsp[(4) - (4)].ptr)->place.first;
					place_is_set=true;
				}
			}
			
			if(!checkIfVoid((yyvsp[(1) - (4)].ptr)->type)){			
				// cout<<"Temp name is "<<	$1->temp_name<<"\n";
				sym_entry* entry = Lookup((yyvsp[(1) - (4)].ptr)->temp_name);
				(yyvsp[(1) - (4)].ptr)->place = qid((yyvsp[(1) - (4)].ptr)->temp_name, entry);
				// cout<<"LVD woopp"<< entry->isArray<<" isArray\n";
				// if(entry->isArray || (findStruct($1->type) && $1->type.substr(0, 7) == "struct_" && $4->expType == 6)){
					
					if(arr_dimensions.find((yyvsp[(1) - (4)].ptr)->temp_name)!=arr_dimensions.end() || (findStruct((yyvsp[(1) - (4)].ptr)->type) && (yyvsp[(1) - (4)].ptr)->type.substr(0, 7) == "struct_" && (yyvsp[(4) - (4)].ptr)->expType == 6)){
					int i = 0;
					// isArray=0;
					if((yyvsp[(4) - (4)].ptr)->dims.size()!=0)
					{
						// cout<<"New Dim size is "<<$4->dims.size()<<" Dim size is "<<arr_dimensions[$1->temp_name].size()<<"\n";
						if((yyvsp[(4) - (4)].ptr)->dims.size()<arr_dimensions[(yyvsp[(1) - (4)].ptr)->temp_name].size())
						{
							yyerror(("Invalid creation of array " + (yyvsp[(1) - (4)].ptr)->temp_name + ": lesser parameters passed in NEW").c_str()); 
							(yyval.ptr)->is_error = 1;
						}
						else if((yyvsp[(4) - (4)].ptr)->dims.size()>arr_dimensions[(yyvsp[(1) - (4)].ptr)->temp_name].size())
						{
							yyerror(("Invalid creation of array " + (yyvsp[(1) - (4)].ptr)->temp_name + ": more parameters passed in NEW").c_str()); 
							(yyval.ptr)->is_error = 1;
						}
						else
						{
							for(int i=0;i<(yyvsp[(4) - (4)].ptr)->dims.size();i++)
							{
								if((yyvsp[(4) - (4)].ptr)->dims[i]==0) arr_dimensions[(yyvsp[(1) - (4)].ptr)->temp_name][i]= -1;
								else arr_dimensions[(yyvsp[(1) - (4)].ptr)->temp_name][i]= (yyvsp[(4) - (4)].ptr)->dims[i];
							}
							// dims.clear();
						}
					}
					else
					{
						reverse(initializer_list_values.begin(), initializer_list_values.end());
						// cout<<initializer_list_values.size()<<" initializer size \n";
						for(qid x: initializer_list_values){
							qid temp;
							temp.first = "array_init";
							temp.second = new sym_entry;
							temp.second->offset = entry->offset+i;
							temp.second->size = 4;
							i+=4;
							emit(qid("=", NULL), x, qid("", NULL), temp, -1);
						}
						global_array_init_map.insert({(yyvsp[(1) - (4)].ptr)->temp_name, initializer_list_values});
					}
				}
			
				else if(findStruct((yyvsp[(1) - (4)].ptr)->type) && (yyvsp[(4) - (4)].ptr)->expType == 6){
					if(initializer_list_values.size() > 1){
						warning("excess elements in union initializer");
					}
					int _size = GetSize((yyvsp[(1) - (4)].ptr)->type);
					for(int i = 0; i<_size; i+=4){
						qid temp;
						temp.first = "union_init";
						temp.second = new sym_entry;
						temp.second->offset = entry->offset+i;
						temp.second->size = 4;
						emit(qid("=", NULL), initializer_list_values[0], qid("", NULL), temp, -1);
					}
				}
				else{
					// cout<<"IN heredbwid"<<$1->type<<"\n";
					if(find(classNamelist.begin(), classNamelist.end(), (yyvsp[(1) - (4)].ptr)->type)==classNamelist.end())
					{
						assign_exp("=", (yyvsp[(1) - (4)].ptr)->type,(yyvsp[(1) - (4)].ptr)->type, (yyvsp[(4) - (4)].ptr)->type, (yyvsp[(1) - (4)].ptr)->place, (yyvsp[(4) - (4)].ptr)->place);
					}
					// $$->intval= $4->intval;
				}
				
				if(!place_is_set) 
				{
					(yyval.ptr)->place = (yyvsp[(1) - (4)].ptr)->place;

				}
				// cout<<"Plce is "<<$1->place.first<<endl;
				(yyval.ptr)->nextlist = (yyvsp[(4) - (4)].ptr)->nextlist;
				backpatch((yyvsp[(1) - (4)].ptr)->nextlist, (yyvsp[(3) - (4)].number));
			}
			else { 
				yyerror(("Invalid assignment to variable of type " + (yyvsp[(1) - (4)].ptr)->type).c_str()); 
				(yyval.ptr)->is_error = 1;
			}
			if(!place_is_set)  (yyval.ptr)->place = qid((yyvsp[(1) - (4)].ptr)->temp_name, Lookup((yyvsp[(1) - (4)].ptr)->temp_name));
		}
		else (yyval.ptr)->is_error = 1;
		initializer_list_values.clear();
	;}
    break;

  case 91:
#line 1065 "parser.y"
    {
								(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "IDENTIFIER");
								type_delim = 1;

								(yyval.ptr)->expType = 1; // Variable
								(yyval.ptr)->type = type;
								if(type=="")
								{
									(yyval.ptr)->type= className.substr(6, className.size()-6);
									// sym_entry* sym= Lookup(string($1));
									// $$->place= 
								}
								(yyval.ptr)->temp_name = string((yyvsp[(1) - (1)].str));
								(yyval.ptr)->size = GetSize(type);

								//3AC
								// if(type=="") $$->place= sym->sym_place;
								 (yyval.ptr)->place = qid((yyval.ptr)->temp_name, NULL);
			;}
    break;

  case 92:
#line 1084 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(v, NULL, "[ ]", 0);
		(yyval.ptr) = create_AST_node("VariableDecltrId", v);
		
		// Semantics
		if(!(yyvsp[(1) - (3)].ptr)->is_error){
			if((yyvsp[(1) - (3)].ptr)->expType <=2 ) {
				(yyval.ptr)->expType = 2;
				(yyval.ptr)->type = (yyvsp[(1) - (3)].ptr)->type + "*";
				(yyval.ptr)->temp_name = (yyvsp[(1) - (3)].ptr)->temp_name;
				(yyval.ptr)->size = 8;	 // pointer type 
				(yyval.ptr)->int_val = 8;
				// cout<<"Are we seetting 1\n";
				// isArray=1;
				//3AC
				
				(yyval.ptr)->place = qid((yyval.ptr)->temp_name, NULL);
				array_dims.push_back(0); //size of array_dims will indicate size of array
				if(arr_dimensions.find((yyvsp[(1) - (3)].ptr)->temp_name)==arr_dimensions.end())
				{
					vector<int> temp;
					temp.push_back(0);
					arr_dimensions[(yyvsp[(1) - (3)].ptr)->temp_name]= temp;
					arr_index[(yyvsp[(1) - (3)].ptr)->temp_name]= 0;
				}
				else arr_dimensions[(yyvsp[(1) - (3)].ptr)->temp_name].push_back(0);
				// cout<<"dims of array "<<$$->temp_name<<" is "<<arr_dimensions[$1->temp_name].size()<<"\n";
				isArray = 1;
			}
			else {
				yyerror(( (yyvsp[(1) - (3)].ptr)->temp_name + " declared as function returning an array").c_str());
				(yyval.ptr)->is_error = 1;
			}
		}
		else (yyval.ptr)->is_error = 1;
	;}
    break;

  case 93:
#line 1124 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr); 	
								initializer_list_values.push_back((yyvsp[(1) - (1)].ptr)->place);
								;}
    break;

  case 94:
#line 1127 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 95:
#line 1130 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("MethodDecn", v);

			// Semantics
		type = "";
		type_delim = 0;
		funcName = "";
		funcType = "";

		for(auto i: gotolablelist){
			if(gotolabel.find(i.first) == gotolabel.end()){
				yyerror(("label \'" + string(i.first) + "\' used but not defined").c_str());
			}
			else backpatch(i.second, gotolabel[i.first]);
		}

		if((yyvsp[(1) - (3)].ptr)->is_error || (yyvsp[(3) - (3)].ptr)->is_error) {
			(yyval.ptr)->is_error = 1;
		}

		if((yyvsp[(2) - (3)].ptr)->is_error) {
			(yyval.ptr)->is_error = 1;
			DeleteFunctionPrototype();
		}

		else {
			string fName = (yyvsp[(2) - (3)].ptr)->name;
			string cName= className.substr(6, className.size()-6);
			string funName= cName+ "_" +fName+ ".csv";
			string func_3AC= cName+ "."+ fName;
			printSymbolTable(curr_table ,funName);
			SymbolTableUpdation(fName,1);
			
			sym_entry* sym= Lookup(fName);

			// if(sym==nullptr) cout<<"THIS IS NULL BRODIJ "<<funcName<<"\n";
			
			sym->funcsize= sym->size;
			emit(qid("FUNC_" + func_3AC + " end :", sym), qid(to_string(sym->size), NULL), qid("", NULL), qid("", NULL), -1);
			// cout<<"IN PARSER "<<fName<<" "<<sym->type<<" "<<sym->size<<endl;
			backpatch_remaining();
			// cout<<" ended "<<fName<<endl;
			
		}
	;}
    break;

  case 96:
#line 1180 "parser.y"
    {
						(yyval.ptr) = new Node();
						clear_paramoffset();
						// param_offset = -4;
						
						if (gst.find(funcName) != gst.end()){
							yyerror(("Redefinition of function " + funcName).c_str());
							(yyval.ptr)->is_error = 1;
						}
						else{
						
							CreateSymbolTable(funcName, funcType,1, 1);
							sym_entry* sym= Lookup(funcName);
							// if(sym==nullptr) cout<<"THIS IS NULL BRO3 "<<funcName<<"\n";
							emit(qid("FUNC_size",sym),qid("",NULL),qid("",NULL),qid("",NULL),-1);
							// cout<<" whdih "<<funcName<<endl;
							if(find(classNamelist.begin(), classNamelist.end(), funcName)!=classNamelist.end())
							{
								qid tmp= newtemp("");
								emit(qid("=", NULL), qid("popparam",NULL), qid(funcName, NULL), tmp, -1);
								
								// $$->place= tmp;
								constructor_temporary= tmp.first;
							}
							pop_function_arguments((yyval.ptr)->type);
								// cout<<"F "<<funcName<<"\n";
							// cout<<"Here "<<sym->type<<endl;
							// cout<<"Param size is "<<param_size<<endl;
							// cout<<funcType<<" TYPE "<<funcName<<"\n";
							if(funcType=="") sym->paramsize= param_size;
							else sym->paramsize= param_size+ GetSize(funcType);// To accomodate space for return value. 
							// cout<<"INSIDE F my func size is "<<sym->size<<endl;
				
							// cout<<"Function locals and temporaries size is "<<sym->size<<endl;
							// sym->funcsize= sym->size;
							// cout<<"sehhhh is "<<param_size<<endl;
							param_size=0;
							(yyval.ptr)->name = (funcName);
							block_count = 1; 
							type = "";
							type_delim = 0;
						}

		;}
    break;

  case 97:
#line 1225 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(4) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("MethodHead1", v);

	;}
    break;

  case 98:
#line 1235 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("MethodHead2", v);
	;}
    break;

  case 99:
#line 1242 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (2)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("MethodHead4", v);

	;}
    break;

  case 100:
#line 1249 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(4) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("MethodHead5", v);
	;}
    break;

  case 101:
#line 1256 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(2) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("MethodHead6", v);

	;}
    break;

  case 102:
#line 1263 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("MethodHead7", v);
	;}
    break;

  case 103:
#line 1269 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("MethodHead8", v);

	;}
    break;

  case 104:
#line 1275 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (3)].ptr), "", 1);

		(yyval.ptr) = create_AST_node("MethodHead3", v);
		// if($1 == "static")is_static.insert($3);
	;}
    break;

  case 105:
#line 1287 "parser.y"
    { (yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "IDENTIFIER");
		// cout<<"Method Identifier "<<"\n";
		// Semantics
		(yyval.ptr)->expType = 1; // Variable
		if(type != "") (yyval.ptr)->type = type;
		else (yyval.ptr)->type = "int";
		(yyval.ptr)->temp_name = string((yyvsp[(1) - (1)].str));
		(yyval.ptr)->size = GetSize(type);

		//3AC
		(yyval.ptr)->place = qid((yyval.ptr)->temp_name, NULL);


;}
    break;

  case 106:
#line 1302 "parser.y"
    {
		vector<treeNode> attr;
		add_attribute(attr, (yyvsp[(1) - (6)].ptr), "", 1);
		add_attribute(attr, (yyvsp[(4) - (6)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("MethodDecltr1", attr);
		// cout<<$4->is_error<<" YES\n";
		
		// Semantics
		if(!(yyvsp[(1) - (6)].ptr)->is_error && !(yyvsp[(4) - (6)].ptr)->is_error){
			// cout<<"Type heere is "<<$1->expType<<"\n";
			if((yyvsp[(1) - (6)].ptr)->expType == 1) {
				(yyval.ptr)->temp_name = (yyvsp[(1) - (6)].ptr)->temp_name;
				(yyval.ptr)->expType = 3; // function declaration
				(yyval.ptr)->type = (yyvsp[(1) - (6)].ptr)->type;
				(yyval.ptr)->size = GetSize((yyval.ptr)->type);
				string fName= (yyvsp[(1) - (6)].ptr)->temp_name;
				string cName= className.substr(6, className.size()-6);
				string funName= cName+ "_" +fName+ ".csv";
				string func_3AC= cName+ "."+ fName;

				vector<string> temp = getFuncArgs((yyvsp[(1) - (6)].ptr)->temp_name);
				// for(int i=0;i<temp.size();i++)
				// {
				// 	cout<<temp[i]<<" ";
				// }
				// cout<<endl;
				
				if(temp.size() == 1 && temp[0] == "#NO_FUNC"){
					insertFuncArg((yyval.ptr)->temp_name, funcArgs, (yyval.ptr)->type);
					funcArgs.clear();
					funcName = string((yyvsp[(1) - (6)].ptr)->temp_name);
					funcType = (yyvsp[(1) - (6)].ptr)->type;
					
					//3AC
					(yyval.ptr)->place = qid((yyval.ptr)->temp_name, NULL);
					backpatch((yyvsp[(4) - (6)].ptr)->nextlist,(yyvsp[(6) - (6)].number));
					
					// sym_entry* sym= Lookup(funcName);
					// if(sym==nullptr) cout<<"THIS IS NULL BRO1 "<<funcName<<"\n";
					emit(pair<string,sym_entry*>("FUNC_" + func_3AC + " start :",NULL),pair<string,sym_entry*>("",NULL),pair<string,sym_entry*>("",NULL),pair<string,sym_entry*>("",NULL),-2);
					
					
					// qid tmp = newtemp($$->type);
					// emit(qid("",NULL),qid("",NULL),qid("",NULL),tmp, -1 );
					// cout<<"CRASH\n";
				}
				else{
					// Check if temp is correct
					if(temp == funcArgs){
						funcArgs.clear();
						funcName = string((yyvsp[(1) - (6)].ptr)->temp_name);
						funcType = (yyvsp[(1) - (6)].ptr)->type;

						//3AC
						(yyval.ptr)->place = qid((yyval.ptr)->temp_name, NULL);
						backpatch((yyvsp[(4) - (6)].ptr)->nextlist,(yyvsp[(6) - (6)].number));
						sym_entry* sym= Lookup((yyvsp[(1) - (6)].ptr)->temp_name);
						
						emit(pair<string,sym_entry*>("FUNC_" + func_3AC + " start :",sym),pair<string,sym_entry*>("",NULL),pair<string,sym_entry*>("",NULL),pair<string,sym_entry*>("",NULL),-2);
						
					}
					else {
						yyerror(("Conflicting types for function " + (yyvsp[(1) - (6)].ptr)->temp_name).c_str());
						(yyval.ptr)->is_error = 1;
					}
				}
			}
			else {
				if((yyvsp[(1) - (6)].ptr)->expType == 2){
					yyerror( ((yyvsp[(1) - (6)].ptr)->temp_name + "declared as array of function").c_str());
				}
				else{
					yyerror( ((yyvsp[(1) - (6)].ptr)->temp_name + "declared as function of function").c_str());
				}
				(yyval.ptr)->is_error = 1;
			}
		}
		else (yyval.ptr)->is_error =1;
		
	;}
    break;

  case 107:
#line 1382 "parser.y"
    {
			(yyval.ptr) =(yyvsp[(1) - (4)].ptr);

			// $$->temp_name= $1->temp_name;
			// Semantics
				if(!(yyvsp[(1) - (4)].ptr)->is_error){
				if((yyvsp[(1) - (4)].ptr)->expType == 1) {
				(yyval.ptr)->temp_name = (yyvsp[(1) - (4)].ptr)->temp_name;
				(yyval.ptr)->expType = 3;
				(yyval.ptr)->type = (yyvsp[(1) - (4)].ptr)->type;
				(yyval.ptr)->size = GetSize((yyval.ptr)->type);
				string fName= (yyvsp[(1) - (4)].ptr)->temp_name;
				string cName= className.substr(6, className.size()-6);
				string funName= cName+ "_" +fName+ ".csv";
				string func_3AC= cName+ "."+ fName;
				// cout<<"Start\n";
				vector<string> temp = getFuncArgs((yyvsp[(1) - (4)].ptr)->temp_name);
				if((temp.size() == 1 && temp[0] == "#NO_FUNC") || funcArgs == temp){
					insertFuncArg((yyval.ptr)->temp_name, funcArgs, (yyval.ptr)->type);
					funcArgs.clear();
					funcName = string((yyvsp[(1) - (4)].ptr)->temp_name);
					funcType = (yyvsp[(1) - (4)].ptr)->type;
				}
				else {
					yyerror(("Conflicting types for function " + (yyvsp[(1) - (4)].ptr)->temp_name).c_str());
					(yyval.ptr)->is_error = 1;
				}
				//3AC
				(yyval.ptr)->place = qid((yyval.ptr)->temp_name, NULL);
				sym_entry* sym= Lookup((yyvsp[(1) - (4)].ptr)->temp_name);
				emit(pair<string,sym_entry*>("FUNC_" + func_3AC + " start :",sym),pair<string,sym_entry*>("",NULL),pair<string,sym_entry*>("",NULL),pair<string,sym_entry*>("",NULL),-2);
			}
			else {
				if((yyvsp[(1) - (4)].ptr)->expType == 2){
					yyerror( ((yyvsp[(1) - (4)].ptr)->temp_name + "declared as array of function").c_str());
				}
				else{
					yyerror( ((yyvsp[(1) - (4)].ptr)->temp_name + "declared as function of function").c_str());
				}
				(yyval.ptr)->is_error = 1;
			}
		}
		else (yyval.ptr)->is_error = 1;
		;}
    break;

  case 108:
#line 1426 "parser.y"
    { 
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(v, NULL, "[ [", 0);
		(yyval.ptr) = create_AST_node("MethodDecltr2", v);

		// Semantics
		if((yyvsp[(1) - (3)].ptr)->expType == 1) {
			(yyval.ptr)->temp_name = (yyvsp[(1) - (3)].ptr)->temp_name;
			(yyval.ptr)->expType = 3;
			(yyval.ptr)->type = (yyvsp[(1) - (3)].ptr)->type;
			(yyval.ptr)->size = GetSize((yyval.ptr)->type);
			vector<string> temp = getFuncArgs((yyvsp[(1) - (3)].ptr)->temp_name);
			if(temp.size() == 1 && temp[0] == "#NO_FUNC"){
				insertFuncArg((yyval.ptr)->temp_name, funcArgs, (yyval.ptr)->type);
				funcArgs.clear();
				funcName = string((yyvsp[(1) - (3)].ptr)->temp_name);
				funcType = (yyvsp[(1) - (3)].ptr)->type;
			}
			else{
				yyerror(("Conflicting types for function " + (yyvsp[(1) - (3)].ptr)->temp_name).c_str());
			}
		}
		else {
			if((yyvsp[(1) - (3)].ptr)->expType == 2){
				yyerror( ((yyvsp[(1) - (3)].ptr)->temp_name + "declared as array of function").c_str());
			}
			else{
				yyerror( ((yyvsp[(1) - (3)].ptr)->temp_name + "declared as function of function").c_str());
			}
		}
	;}
    break;

  case 109:
#line 1460 "parser.y"
    {
	type ="";
	// cout<<"Function flag set to zero in func declaration\n";
		func_flag = 0;
		funcArgs.clear();
		CreateParameterList();
		gotolablelist.clear();
		gotolabel.clear();
;}
    break;

  case 110:
#line 1471 "parser.y"
    {
				(yyval.ptr) = (yyvsp[(1) - (1)].ptr);
			;}
    break;

  case 111:
#line 1474 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(4) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("FormalParamList", v);

		if(!(yyvsp[(1) - (4)].ptr)->is_error && !(yyvsp[(4) - (4)].ptr)->is_error){
			// 3AC
			backpatch((yyvsp[(1) - (4)].ptr)->nextlist, (yyvsp[(3) - (4)].number));
			(yyval.ptr)->nextlist = (yyvsp[(4) - (4)].ptr)->nextlist;
		}
		else (yyval.ptr)->is_error = 1;
;}
    break;

  case 112:
#line 1489 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (2)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("FormalParam", v);

		// Semantics
		if(!(yyvsp[(1) - (2)].ptr)->is_error && !(yyvsp[(2) - (2)].ptr)->is_error){
			type_delim = 0;
			type = "";
			if((yyvsp[(2) - (2)].ptr)->expType == 1 || (yyvsp[(2) - (2)].ptr)->expType == 2) {
				if(CurLookup((yyvsp[(2) - (2)].ptr)->temp_name)) {
					yyerror(("Redeclaration of Parameter " + (yyvsp[(2) - (2)].ptr)->temp_name).c_str());
					(yyval.ptr)->is_error = 1;
				}
				else {
					paramInsert(*curr_table, (yyvsp[(2) - (2)].ptr)->temp_name, (yyvsp[(2) - (2)].ptr)->type, (yyvsp[(2) - (2)].ptr)->size, true, NULL);
					param_size+=(yyvsp[(2) - (2)].ptr)->size;
					sym_entry* sym= Lookup((yyvsp[(2) - (2)].ptr)->temp_name);
					// if(sym==nullptr) {
					// 	yyerror(($2->temp_name+" not found").c_str());
					// }
					// cout<<sym->offset<<" Ujwal\n";
					// qid temp= newtemp($$->type);
					// emit(qid("=", NULL), qid("popparam",NULL), qid($2->temp_name, NULL), temp, -1);
					// sym->place= 
					// insertSymbol(*curr_table, $2->temp_name, $2->type, $2->size, 1, NULL);
				}
				funcArgs.push_back((yyvsp[(2) - (2)].ptr)->type);
			}
		}
		else (yyval.ptr)->is_error = 1;
;}
    break;

  case 113:
#line 1524 "parser.y"
    {
		vector<treeNode> v;
		// add_attribute(v, create_AST_leaf($1, "THROWS"), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("Throws", v);
	;}
    break;

  case 114:
#line 1533 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 115:
#line 1534 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ClassTypeList", v);
;}
    break;

  case 116:
#line 1549 "parser.y"
    {(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "SCLN");;}
    break;

  case 117:
#line 1550 "parser.y"
    {
								// cout<<"Block called for method body\n";
								(yyval.ptr) = (yyvsp[(1) - (1)].ptr);
						;}
    break;

  case 118:
#line 1557 "parser.y"
    {
		vector<treeNode> v;
		// add_attribute(v, create_AST_leaf($1, "STATIC"), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("StaticInit", v);
	;}
    break;

  case 119:
#line 1565 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (5)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (5)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (5)].ptr), "", 1);
		add_attribute(v, (yyvsp[(5) - (5)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ConstructorDecn1", v);

		// Semantics
		// Semantics
		type = "";
		type_delim = 0;
		funcName = "";
		funcType = "";

		for(auto i: gotolablelist){
			if(gotolabel.find(i.first) == gotolabel.end()){
				yyerror(("label \'" + string(i.first) + "\' used but not defined").c_str());
			}
			else backpatch(i.second, gotolabel[i.first]);
		}

		if((yyvsp[(1) - (5)].ptr)->is_error || (yyvsp[(2) - (5)].ptr)->is_error || (yyvsp[(3) - (5)].ptr)->is_error|| (yyvsp[(5) - (5)].ptr)->is_error) {
			(yyval.ptr)->is_error = 1;
		}

		if((yyvsp[(4) - (5)].ptr)->is_error) {
			(yyval.ptr)->is_error = 1;
			DeleteFunctionPrototype();
		}

		else {
			string fName = (yyvsp[(4) - (5)].ptr)->name;
			// printSymbolTable(curr_table ,fName + ".csv");
			string cName= className.substr(6, className.size()-6);
			string constName= cName+ "_ctor"+ to_string(constructor_num)+ ".csv";
			string constr_3AC=  cName+ ".ctor"+ to_string(constructor_num);
			printSymbolTable(curr_table ,constName);
			constructor_num++;
			SymbolTableUpdation(fName,1);
			sym_entry* sym= Lookup(fName);
			
			sym->funcsize= sym->size;
			// if(sym==nullptr) cout<<"THIS IS NULL BRODIJ "<<funcName<<"\n";
			// emit(qid("FUNC_" + func_3AC + " end :", sym), qid(to_string(sym->size), NULL), qid("", NULL), qid("", NULL), -1);
			emit(qid("FUNC_" +  constr_3AC + " end :", sym), qid(to_string(sym->size), NULL), qid("", NULL), qid("", NULL), -1);
			backpatch_remaining();
			constructor_temporary="";
		}
	;}
    break;

  case 120:
#line 1615 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(4) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ConstructorDecn3", v);

		// Semantics
			// Semantics
		type = "";
		type_delim = 0;
		funcName = "";
		funcType = "";

		for(auto i: gotolablelist){
			if(gotolabel.find(i.first) == gotolabel.end()){
				yyerror(("label \'" + string(i.first) + "\' used but not defined").c_str());
			}
			else backpatch(i.second, gotolabel[i.first]);
		}

		if((yyvsp[(1) - (4)].ptr)->is_error || (yyvsp[(2) - (4)].ptr)->is_error || (yyvsp[(4) - (4)].ptr)->is_error) {
			(yyval.ptr)->is_error = 1;
		}

		if((yyvsp[(3) - (4)].ptr)->is_error) {
			(yyval.ptr)->is_error = 1;
			DeleteFunctionPrototype();
		}

		else {
			// cout<<className<<"in constructor\n";
			string fName = (yyvsp[(3) - (4)].ptr)->name;
			string cName= className.substr(6, className.size()-6);
			string constName= cName+ "_ctor"+ to_string(constructor_num)+ ".csv";
			string constr_3AC=  cName+ ".ctor"+ to_string(constructor_num);
			printSymbolTable(curr_table ,constName);
			constructor_num++;
			// printSymbolTable(curr_table ,fName + ".csv");
			sym_entry* sym= Lookup(fName);
			// cout<<"hijk1 "<<sym->size<<endl;
			sym->funcsize= sym->size;
			// if(sym==nullptr) cout<<"THIS IS NULL BRODIJ "<<funcName<<"\n";
			SymbolTableUpdation(fName,1);
			emit(qid("FUNC_" +  constr_3AC  + " end :", sym), qid(to_string(sym->size), NULL), qid("", NULL), qid("", NULL), -1);
			backpatch_remaining();
			constructor_temporary="";
		}
	;}
    break;

  case 121:
#line 1664 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ConstructorDecn4", v);

		// Semantics
			// Semantics
		type = "";
		type_delim = 0;
		funcName = "";
		funcType = "";

		for(auto i: gotolablelist){
			if(gotolabel.find(i.first) == gotolabel.end()){
				yyerror(("label \'" + string(i.first) + "\' used but not defined").c_str());
			}
			else backpatch(i.second, gotolabel[i.first]);
		}

		if((yyvsp[(1) - (3)].ptr)->is_error || (yyvsp[(3) - (3)].ptr)->is_error) {
			(yyval.ptr)->is_error = 1;
		}

		if((yyvsp[(2) - (3)].ptr)->is_error) {
			(yyval.ptr)->is_error = 1;
			DeleteFunctionPrototype();
		}

		else {
			string fName = (yyvsp[(2) - (3)].ptr)->name;
			string cName= className.substr(6, className.size()-6);
			string constName= cName+ "_ctor"+ to_string(constructor_num)+ ".csv";
			string constr_3AC=  cName+ ".ctor"+ to_string(constructor_num);
			printSymbolTable(curr_table ,constName);
			// printSymbolTable(curr_table ,"_ctor" +to_string(constructor_num)+ ".csv");
			constructor_num++;
			// printSymbolTable(curr_table ,fName + ".csv");
			SymbolTableUpdation(fName,1);
			sym_entry* sym= Lookup(fName);
			// cout<<"hijk1 "<<sym->size<<endl;
			sym->funcsize= sym->size;
			// if(sym==nullptr) cout<<"THIS IS NULL BRODIJ "<<funcName<<"\n";
			emit(qid("FUNC_" +  constr_3AC + " end :", sym), qid(to_string(sym->size), NULL), qid("", NULL), qid("", NULL), -1);
			backpatch_remaining();
			constructor_temporary="";
		}
	;}
    break;

  case 122:
#line 1712 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(4) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ConstructorDecn2", v);

			// Semantics
		type = "";
		type_delim = 0;
		funcName = "";
		funcType = "";

		for(auto i: gotolablelist){
			if(gotolabel.find(i.first) == gotolabel.end()){
				yyerror(("label \'" + string(i.first) + "\' used but not defined").c_str());
			}
			else backpatch(i.second, gotolabel[i.first]);
		}

		if((yyvsp[(1) - (4)].ptr)->is_error || (yyvsp[(2) - (4)].ptr)->is_error || (yyvsp[(3) - (4)].ptr)->is_error) {
			(yyval.ptr)->is_error = 1;
		}

		if((yyvsp[(3) - (4)].ptr)->is_error) {
			(yyval.ptr)->is_error = 1;
			DeleteFunctionPrototype();
		}

		else {
			string fName = (yyvsp[(3) - (4)].ptr)->name;
			string cName= className.substr(6, className.size()-6);
			string constName= cName+ "_ctor"+ to_string(constructor_num)+ ".csv";
			string constr_3AC=  cName+ ".ctor"+ to_string(constructor_num);
			printSymbolTable(curr_table ,constName);
			// printSymbolTable(curr_table ,"ctor" +to_string(constructor_num)+ ".csv");
			constructor_num++;
			// printSymbolTable(curr_table ,fName + ".csv");
			SymbolTableUpdation(fName,1);
			emit(qid("FUNC_" +  constr_3AC + " end :", NULL), qid("", NULL), qid("", NULL), qid("", NULL), -1);
			backpatch_remaining();
			constructor_temporary="";
		}
	;}
    break;

  case 123:
#line 1759 "parser.y"
    {
									(yyval.ptr)=create_AST_leaf((yyvsp[(1) - (1)].str), "IDENTIFIER");

									(yyval.ptr)->expType = 1; // Variable
									(yyval.ptr)->temp_name = string((yyvsp[(1) - (1)].str));
									(yyval.ptr)->size = GetSize(type);

									//3AC
									(yyval.ptr)->place = qid((yyval.ptr)->temp_name, NULL);
									// $$->temp_name= string($1);
									// $$->expType=1;
;}
    break;

  case 124:
#line 1772 "parser.y"
    {
		vector<treeNode> v, v2;
		add_attribute(v2, (yyvsp[(4) - (6)].ptr), "", 1);
		Node* node = create_AST_node("( )", v2);
		add_attribute(v, (yyvsp[(1) - (6)].ptr), "", 1);
		add_attribute(v, node, "", 1);
		(yyval.ptr) = create_AST_node("ConstructorDecltr1", v);

		// Semantics
		if(!(yyvsp[(1) - (6)].ptr)->is_error && !(yyvsp[(4) - (6)].ptr)->is_error){
			if((yyvsp[(1) - (6)].ptr)->expType == 1) {
				(yyval.ptr)->temp_name = (yyvsp[(1) - (6)].ptr)->temp_name;
				(yyval.ptr)->expType = 3;
				(yyval.ptr)->type = (yyvsp[(1) - (6)].ptr)->type;
				(yyval.ptr)->size = GetSize((yyval.ptr)->type);
				string cName= className.substr(6, className.size()-6);
				string constr_3AC=  cName+ ".ctor"+ to_string(constructor_num);
				// constructor_num++;
				vector<string> temp = getFuncArgs((yyvsp[(1) - (6)].ptr)->temp_name);
				if(temp.size() == 1 && temp[0] == "#NO_FUNC"){
					insertFuncArg((yyval.ptr)->temp_name, funcArgs, (yyval.ptr)->type);
					funcArgs.clear();
					funcName = string((yyvsp[(1) - (6)].ptr)->temp_name);
					funcType = (yyvsp[(1) - (6)].ptr)->type;
					
					// string constName= cName+ "_ctor"+ to_string(constructor_num)+ ".csv";
					//3AC
					(yyval.ptr)->place = qid((yyval.ptr)->temp_name, NULL);
					backpatch((yyvsp[(4) - (6)].ptr)->nextlist,(yyvsp[(6) - (6)].number));
					emit(pair<string,sym_entry*>("FUNC_" + constr_3AC + " start :",NULL),pair<string,sym_entry*>("",NULL),pair<string,sym_entry*>("",NULL),pair<string,sym_entry*>("",NULL),-2);
				}
				else{
					// Check if temp is correct
					if(temp == funcArgs){
						funcArgs.clear();
						funcName = string((yyvsp[(1) - (6)].ptr)->temp_name);
						funcType = (yyvsp[(1) - (6)].ptr)->type;

						//3AC
						(yyval.ptr)->place = qid((yyval.ptr)->temp_name, NULL);
						backpatch((yyvsp[(4) - (6)].ptr)->nextlist,(yyvsp[(6) - (6)].number));
						emit(pair<string,sym_entry*>("FUNC_" + constr_3AC + " start :",NULL),pair<string,sym_entry*>("",NULL),pair<string,sym_entry*>("",NULL),pair<string,sym_entry*>("",NULL),-2);
					}
					else {
						yyerror(("Conflicting types for function " + (yyvsp[(1) - (6)].ptr)->temp_name).c_str());
						(yyval.ptr)->is_error = 1;
					}
				}
			}
			else {
				if((yyvsp[(1) - (6)].ptr)->expType == 2){
					yyerror( ((yyvsp[(1) - (6)].ptr)->temp_name + "declared as array of function").c_str());
				}
				else{
					yyerror( ((yyvsp[(1) - (6)].ptr)->temp_name + "declared as function of function").c_str());
				}
				(yyval.ptr)->is_error = 1;
			}
		}
		else (yyval.ptr)->is_error =1;
	;}
    break;

  case 125:
#line 1833 "parser.y"
    {	
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (4)].ptr), "", 1);
		add_attribute(v, NULL, "( )", 0);
		(yyval.ptr) = create_AST_node("ConstructorDecltr2", v);

			// Semantics
		if(!(yyvsp[(1) - (4)].ptr)->is_error){
			if((yyvsp[(1) - (4)].ptr)->expType == 1) {
				(yyval.ptr)->temp_name = (yyvsp[(1) - (4)].ptr)->temp_name;
				(yyval.ptr)->expType = 3;
				(yyval.ptr)->type = (yyvsp[(1) - (4)].ptr)->type;
				(yyval.ptr)->size = GetSize((yyval.ptr)->type);
				string cName= className.substr(6, className.size()-6);
				string constr_3AC=  cName+ ".ctor"+ to_string(constructor_num);
				// constructor_num++;
				vector<string> temp = getFuncArgs((yyvsp[(1) - (4)].ptr)->temp_name);
				if((temp.size() == 1 && temp[0] == "#NO_FUNC") || funcArgs == temp){
					insertFuncArg((yyval.ptr)->temp_name, funcArgs, (yyval.ptr)->type);
					funcArgs.clear();
					funcName = string((yyvsp[(1) - (4)].ptr)->temp_name);
					funcType = (yyvsp[(1) - (4)].ptr)->type;
				}
				else {
					yyerror(("Conflicting types for function " + (yyvsp[(1) - (4)].ptr)->temp_name).c_str());
					(yyval.ptr)->is_error = 1;
				}
				//3AC
				(yyval.ptr)->place = qid((yyval.ptr)->temp_name, NULL);
				// emit(pair<string,sym_entry*>("FUNC_" + $$->temp_name + " start :",NULL),pair<string,sym_entry*>("",NULL),pair<string,sym_entry*>("",NULL),pair<string,sym_entry*>("",NULL),-2);
				emit(pair<string,sym_entry*>("FUNC_" + constr_3AC + " start :",NULL),pair<string,sym_entry*>("",NULL),pair<string,sym_entry*>("",NULL),pair<string,sym_entry*>("",NULL),-2);
			}
			else {
				if((yyvsp[(1) - (4)].ptr)->expType == 2){
					yyerror( ((yyvsp[(1) - (4)].ptr)->temp_name + "declared as array of function").c_str());
				}
				else{
					yyerror( ((yyvsp[(1) - (4)].ptr)->temp_name + "declared as function of function").c_str());
				}
				(yyval.ptr)->is_error = 1;
			}
		}
		else (yyval.ptr)->is_error = 1;
	;}
    break;

  case 126:
#line 1880 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(2) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ConstructorBody", v);
;}
    break;

  case 127:
#line 1886 "parser.y"
    {(yyval.ptr) = create_AST_leaf("{}", "LITERAL");;}
    break;

  case 128:
#line 1887 "parser.y"
    {(yyval.ptr) = (yyvsp[(2) - (3)].ptr);;}
    break;

  case 129:
#line 1888 "parser.y"
    {(yyval.ptr) = (yyvsp[(2) - (3)].ptr);;}
    break;

  case 130:
#line 1891 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(3) - (5)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ConstructorBody1", v);
;}
    break;

  case 131:
#line 1897 "parser.y"
    {
		vector<treeNode> v;
		(yyval.ptr) = create_AST_node("ConstructorBody2", v);
;}
    break;

  case 132:
#line 1901 "parser.y"
    {
		vector<treeNode> v;
		(yyval.ptr) = create_AST_node("ConstructorBody3", v);
;}
    break;

  case 133:
#line 1905 "parser.y"
    {
		vector<treeNode> v;
		(yyval.ptr) = create_AST_node("ConstructorBody4", v);
;}
    break;

  case 134:
#line 1912 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (6)].ptr), "", 1);
		add_attribute(v, create_AST_leaf((yyvsp[(3) - (6)].str),"IDENTIFIER"), "", 1);
		add_attribute(v, (yyvsp[(4) - (6)].ptr), "", 1);
		add_attribute(v, (yyvsp[(6) - (6)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("IntfaceDecn1", v);

		if(ShowStructTable("STRUCT_" + structName) == 1){
			if(type == "")type = "STRUCT_" + structName;
			else type += " STRUCT_" + structName;
		}
		else {
			yyerror(("Struct " + structName + " is already defined").c_str());
		}

		varlist.clear();
;}
    break;

  case 135:
#line 1930 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (5)].ptr), "", 1);
		add_attribute(v, create_AST_leaf((yyvsp[(3) - (5)].str),"IDENTIFIER"), "", 1);
		add_attribute(v, (yyvsp[(5) - (5)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("IntfaceDecn3", v);

		if(ShowStructTable("STRUCT_" + structName) == 1){
			if(type == "")type = "STRUCT_" + structName;
			else type += " STRUCT_" + structName;
		}
		else {
			yyerror(("Struct " + structName + " is already defined").c_str());
		}
		varlist.clear();
;}
    break;

  case 136:
#line 1946 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, create_AST_leaf((yyvsp[(3) - (4)].str),"IDENTIFIER"), "", 1);
		add_attribute(v, (yyvsp[(4) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("IntfaceDecn4", v);

		if(ShowStructTable("STRUCT_" + structName) == 1){
			if(type == "")type = "STRUCT_" + structName;
			else type += " STRUCT_" + structName;
		}
		else {
			yyerror(("Struct " + structName + " is already defined").c_str());
		}
		varlist.clear();
;}
    break;

  case 137:
#line 1961 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, create_AST_leaf((yyvsp[(2) - (5)].str),"IDENTIFIER"), "", 1);
		add_attribute(v, (yyvsp[(3) - (5)].ptr), "", 1);
		add_attribute(v, (yyvsp[(5) - (5)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("IntfaceDecn2", v);

		if(ShowStructTable("STRUCT_" + structName) == 1){
			if(type == "")type = "STRUCT_" + structName;
			else type += " STRUCT_" + structName;
		}
		else {
			yyerror(("Struct " + structName + " is already defined").c_str());
		}
		varlist.clear();
;}
    break;

  case 138:
#line 1981 "parser.y"
    {
					(yyval.str)= (yyvsp[(1) - (1)].str);
					structName= (yyvsp[(1) - (1)].str);
;}
    break;

  case 139:
#line 1987 "parser.y"
    {
	CreateStructTable();
;}
    break;

  case 140:
#line 1993 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ExtendsIntfaces1", v);
	;}
    break;

  case 141:
#line 1998 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ExtendsIntfaces2", v);
;}
    break;

  case 142:
#line 2006 "parser.y"
    {(yyval.ptr) = create_AST_leaf("{ }", "EMPTY");;}
    break;

  case 143:
#line 2007 "parser.y"
    {
				//    $$ = $2;
				vector<treeNode> v;
			add_attribute(v, (yyvsp[(3) - (4)].ptr), "", 1);
			(yyval.ptr) = create_AST_node("Interface", v);

			   if(func_flag>=2){
					int bc = block_stack.top();
					block_stack.pop();
					string str = "Block" + to_string(bc);
					string name = funcName+str+".csv";
					printSymbolTable(curr_table, name);
					SymbolTableUpdation(str, 0);
					func_flag--;
				}
				   ;}
    break;

  case 144:
#line 2025 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 145:
#line 2026 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (2)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("IntfaceMemberDecnRec", v);
;}
    break;

  case 146:
#line 2034 "parser.y"
    {
										(yyval.ptr) = (yyvsp[(1) - (1)].ptr);
										for(auto it: varlist)
										{
											if (AddStructAttr(it, (yyvsp[(1) - (1)].ptr)->type, (yyvsp[(1) - (1)].ptr)->size, 0) != 1){
											yyerror(("The Attribute " + string(it) + " is already declared in the same struct").c_str());
											} 
										}
										;}
    break;

  case 147:
#line 2043 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 148:
#line 2046 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 149:
#line 2049 "parser.y"
    {
											(yyval.ptr) = (yyvsp[(1) - (2)].ptr);
											// what size to I use here? 
											if (AddStructAttr((yyvsp[(1) - (2)].ptr)->temp_name, (yyvsp[(1) - (2)].ptr)->type, 4, 0) != 1){
											yyerror(("The abstract method " + (yyvsp[(1) - (2)].ptr)->temp_name + " is already declared in the same struct").c_str());
											}				
						;}
    break;

  case 150:
#line 2058 "parser.y"
    {

		(yyval.ptr) = (yyvsp[(2) - (4)].ptr);
		(yyval.ptr)->expType = 6;
		if(!(yyvsp[(2) - (4)].ptr)->is_error){
			//3AC
			(yyval.ptr)->place = (yyvsp[(2) - (4)].ptr)->place;
			(yyval.ptr)->nextlist = (yyvsp[(2) - (4)].ptr)->nextlist;
		}
;}
    break;

  case 151:
#line 2068 "parser.y"
    {
		// vector<treeNode> v;
		// add_attribute(v, $2, "", 1);
		// $$ = create_AST_node("ArrInit3", v);
			(yyval.ptr) = (yyvsp[(2) - (3)].ptr) ;
		(yyval.ptr)->expType = 6;
;}
    break;

  case 152:
#line 2075 "parser.y"
    {
					 (yyval.ptr) = create_AST_leaf((yyvsp[(1) - (2)].str), "EMPTY");
					 (yyval.ptr)->expType= 6;
				 ;}
    break;

  case 153:
#line 2079 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, create_AST_leaf((yyvsp[(2) - (3)].str), ""), "", 1);
		(yyval.ptr) = create_AST_node("ArrInit2", v);
		 (yyval.ptr)->expType= 6;
;}
    break;

  case 154:
#line 2088 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(4) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("VariableInitList", v);

		if(!(yyvsp[(1) - (4)].ptr)->is_error && !(yyvsp[(4) - (4)].ptr)->is_error){
			//3AC
			backpatch((yyvsp[(1) - (4)].ptr)->nextlist, (yyvsp[(3) - (4)].number));
			(yyval.ptr)->nextlist = (yyvsp[(4) - (4)].ptr)->nextlist;
		}
		else (yyval.ptr)->is_error = 1;
;}
    break;

  case 155:
#line 2101 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 156:
#line 2105 "parser.y"
    {
					// $$ = $2;
					vector<treeNode> v;
					add_attribute(v, (yyvsp[(3) - (4)].ptr), "", 1);
					(yyval.ptr) = create_AST_node("Block", v);
					// cout<<"Block stmt "<<func_flag<<" \n";
					// varlist.clear();

					if(func_flag>=2){
					int bc = block_stack.top();
					block_stack.pop();
					string str = "Block" + to_string(bc);
					string name = funcName+str+".csv";
					printSymbolTable(curr_table, name);
					SymbolTableUpdation(str, 0);
					func_flag--;
				}
				// cout<<"BLock reduced "<<func_flag<<"\n";

// 
	;}
    break;

  case 157:
#line 2126 "parser.y"
    {(yyval.ptr) = create_AST_leaf("{}", "EMPTY");;}
    break;

  case 158:
#line 2130 "parser.y"
    {
				// cout<<"CT "<<func_flag<<" \n";
				varlist.clear(); // not using 
				if(func_flag){
					
					string str = "Block" +to_string(block_count);
					// cout<<"Symbol table "<<str<< " created \n";
					// pushes to block_stack. Popped later after block finishes. 
					block_stack.push(block_count);
					block_count++;
					func_flag++;
					CreateSymbolTable(str, "", 0, 1);
				}
				else func_flag++;
;}
    break;

  case 159:
#line 2146 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (2)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("BlockStmts", v);
;}
    break;

  case 160:
#line 2152 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 161:
#line 2155 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 162:
#line 2156 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 163:
#line 2159 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (2)].ptr);;}
    break;

  case 164:
#line 2162 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (2)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("LocalVariableDecn", v);
		// cout<<"LVD\n";
		type=""; // resetting type 
		type_delim = 0;
		storage_class = "";
		
		if(!(yyvsp[(1) - (2)].ptr)->is_error && !(yyvsp[(2) - (2)].ptr)->is_error){
			// 3AC
			(yyval.ptr)->nextlist = (yyvsp[(2) - (2)].ptr)->nextlist;
		}
		else (yyval.ptr)->is_error = 1;
;}
    break;

  case 165:
#line 2180 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 166:
#line 2181 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 167:
#line 2182 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 168:
#line 2183 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 169:
#line 2184 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 170:
#line 2185 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 171:
#line 2188 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 172:
#line 2189 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 173:
#line 2190 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 174:
#line 2191 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 175:
#line 2192 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 176:
#line 2195 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 177:
#line 2196 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 178:
#line 2197 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 179:
#line 2198 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 180:
#line 2199 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 181:
#line 2200 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 182:
#line 2201 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 183:
#line 2202 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 184:
#line 2203 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 185:
#line 2204 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 186:
#line 2205 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 187:
#line 2207 "parser.y"
    {(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "SCLN");;}
    break;

  case 188:
#line 2210 "parser.y"
    {(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (3)].str), "IDENTIFIER");;}
    break;

  case 189:
#line 2213 "parser.y"
    {(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (3)].str), "IDENTIFIER");;}
    break;

  case 190:
#line 2216 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (2)].ptr);;}
    break;

  case 191:
#line 2219 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 192:
#line 2220 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 193:
#line 2221 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 194:
#line 2222 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 195:
#line 2223 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 196:
#line 2224 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 197:
#line 2225 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 198:
#line 2229 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("IfThenStmt", v);

		if((yyvsp[(1) - (3)].ptr)->is_error || (yyvsp[(3) - (3)].ptr)->is_error)	{
			(yyval.ptr)->is_error = 1;
		}

        backpatch((yyvsp[(1) - (3)].ptr)->truelist, (yyvsp[(2) - (3)].number));
		(yyvsp[(3) - (3)].ptr)->nextlist.insert((yyvsp[(3) - (3)].ptr)->nextlist.end(), (yyvsp[(1) - (3)].ptr)->falselist.begin(), (yyvsp[(1) - (3)].ptr)->falselist.end());// merges 
        (yyval.ptr)->nextlist= (yyvsp[(3) - (3)].ptr)->nextlist;
        (yyval.ptr)->continuelist = (yyvsp[(3) - (3)].ptr)->continuelist;
        (yyval.ptr)->breaklist = (yyvsp[(3) - (3)].ptr)->breaklist;
	;}
    break;

  case 199:
#line 2247 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (7)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (7)].ptr), "", 1);
		add_attribute(v, (yyvsp[(7) - (7)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("IfThenElseStmt", v);

		if((yyvsp[(1) - (7)].ptr)->is_error || (yyvsp[(3) - (7)].ptr)->is_error || (yyvsp[(7) - (7)].ptr)->is_error)	{
			(yyval.ptr)->is_error = 1;
		}

        backpatch((yyvsp[(1) - (7)].ptr)->truelist, (yyvsp[(2) - (7)].number));
        backpatch((yyvsp[(1) - (7)].ptr)->falselist, (yyvsp[(6) - (7)].number));
		(yyvsp[(3) - (7)].ptr)->nextlist.insert((yyvsp[(3) - (7)].ptr)->nextlist.end(), (yyvsp[(4) - (7)].ptr)->nextlist.begin(), (yyvsp[(4) - (7)].ptr)->nextlist.end());
		(yyvsp[(3) - (7)].ptr)->nextlist.insert((yyvsp[(3) - (7)].ptr)->nextlist.end(), (yyvsp[(7) - (7)].ptr)->nextlist.begin(), (yyvsp[(7) - (7)].ptr)->nextlist.end());
        (yyval.ptr)->nextlist = (yyvsp[(3) - (7)].ptr)->nextlist;
		(yyvsp[(3) - (7)].ptr)->breaklist.insert((yyvsp[(3) - (7)].ptr)->breaklist.end(), (yyvsp[(7) - (7)].ptr)->breaklist.begin(), (yyvsp[(7) - (7)].ptr)->breaklist.end());
		(yyval.ptr)->breaklist = (yyvsp[(3) - (7)].ptr)->breaklist;
		(yyvsp[(3) - (7)].ptr)->continuelist.insert((yyvsp[(3) - (7)].ptr)->continuelist.end(), (yyvsp[(7) - (7)].ptr)->continuelist.begin(), (yyvsp[(7) - (7)].ptr)->continuelist.end());
		(yyval.ptr)->continuelist = (yyvsp[(3) - (7)].ptr)->continuelist;
	;}
    break;

  case 200:
#line 2269 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (7)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (7)].ptr), "", 1);
		add_attribute(v, (yyvsp[(7) - (7)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("IfThenElseStmtKind", v);
		if((yyvsp[(1) - (7)].ptr)->is_error || (yyvsp[(3) - (7)].ptr)->is_error || (yyvsp[(7) - (7)].ptr)->is_error)	{
			(yyval.ptr)->is_error = 1;
		}

        backpatch((yyvsp[(1) - (7)].ptr)->truelist, (yyvsp[(2) - (7)].number));
        backpatch((yyvsp[(1) - (7)].ptr)->falselist, (yyvsp[(6) - (7)].number));
		(yyvsp[(3) - (7)].ptr)->nextlist.insert((yyvsp[(3) - (7)].ptr)->nextlist.end(), (yyvsp[(4) - (7)].ptr)->nextlist.begin(), (yyvsp[(4) - (7)].ptr)->nextlist.end());
		(yyvsp[(3) - (7)].ptr)->nextlist.insert((yyvsp[(3) - (7)].ptr)->nextlist.end(), (yyvsp[(7) - (7)].ptr)->nextlist.begin(), (yyvsp[(7) - (7)].ptr)->nextlist.end());
        (yyval.ptr)->nextlist = (yyvsp[(3) - (7)].ptr)->nextlist;
		(yyvsp[(3) - (7)].ptr)->breaklist.insert((yyvsp[(3) - (7)].ptr)->breaklist.end(), (yyvsp[(7) - (7)].ptr)->breaklist.begin(), (yyvsp[(7) - (7)].ptr)->breaklist.end());
		(yyval.ptr)->breaklist = (yyvsp[(3) - (7)].ptr)->breaklist;
		(yyvsp[(3) - (7)].ptr)->continuelist.insert((yyvsp[(3) - (7)].ptr)->continuelist.end(), (yyvsp[(7) - (7)].ptr)->continuelist.begin(), (yyvsp[(7) - (7)].ptr)->continuelist.end());
		(yyval.ptr)->continuelist = (yyvsp[(3) - (7)].ptr)->continuelist;
	;}
    break;

  case 201:
#line 2293 "parser.y"
    {if_found=1;;}
    break;

  case 202:
#line 2293 "parser.y"
    {
            if((yyvsp[(4) - (5)].ptr)->truelist.empty() && (yyvsp[(4) - (5)].ptr)->falselist.empty()) {
            int a = code.size();
			backpatch((yyvsp[(4) - (5)].ptr)->nextlist, a);
            emit(qid("GOTO", NULL),qid("IF", Lookup("if")), (yyvsp[(4) - (5)].ptr)->place, qid("", NULL ),0);
            int b = code.size();
            emit(qid("GOTO", NULL),qid("", NULL), qid("", NULL), qid("", NULL ),0);
            (yyvsp[(4) - (5)].ptr)->truelist.push_back(a);
            (yyvsp[(4) - (5)].ptr)->falselist.push_back(b);
        }
        (yyval.ptr) = (yyvsp[(4) - (5)].ptr);
		if_found = 0;
		;}
    break;

  case 203:
#line 2308 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(3) - (5)].ptr), "", 1);
		add_attribute(v, (yyvsp[(5) - (5)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("SwitchStmt", v);
       if((yyvsp[(3) - (5)].ptr)->is_error || (yyvsp[(5) - (5)].ptr)->is_error)	{
			(yyval.ptr)->is_error = 1;
		}

        casepatch((yyvsp[(5) - (5)].ptr)->caselist, (yyvsp[(3) - (5)].ptr)->place);
        (yyvsp[(5) - (5)].ptr)->nextlist.insert((yyvsp[(5) - (5)].ptr)->nextlist.end(), (yyvsp[(5) - (5)].ptr)->breaklist.begin(), (yyvsp[(5) - (5)].ptr)->breaklist.end());
		(yyval.ptr)->nextlist= (yyvsp[(5) - (5)].ptr)->nextlist;
        (yyval.ptr)->continuelist= (yyvsp[(5) - (5)].ptr)->continuelist;
		
	;}
    break;

  case 204:
#line 2325 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(2) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("SwitchBlock", v);
	;}
    break;

  case 205:
#line 2331 "parser.y"
    {(yyval.ptr) = create_AST_leaf("{ }", "EMPTY");;}
    break;

  case 206:
#line 2332 "parser.y"
    {(yyval.ptr) = (yyvsp[(2) - (3)].ptr);;}
    break;

  case 207:
#line 2333 "parser.y"
    {(yyval.ptr) = (yyvsp[(2) - (3)].ptr);;}
    break;

  case 208:
#line 2336 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 209:
#line 2337 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (2)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("SwitchBlockStmtGroups", v);
	;}
    break;

  case 210:
#line 2345 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 211:
#line 2346 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (2)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("SwitchLabels", v);
	;}
    break;

  case 212:
#line 2354 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (2)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("SwitchBlockStmtGroup", v);
	;}
    break;

  case 213:
#line 2363 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(2) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("SwitchLabel1", v);
	;}
    break;

  case 214:
#line 2368 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, NULL, "default", 0);
		(yyval.ptr) = create_AST_node("SwitchLabel2", v); // empty?
	;}
    break;

  case 215:
#line 2375 "parser.y"
    {
		vector<treeNode> v;
		// add_attribute(v, $3, "", 1);
		// add_attribute(v, $5, "", 1);
		add_attribute(v, (yyvsp[(4) - (7)].ptr), "", 1);
		add_attribute(v, (yyvsp[(7) - (7)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("WhileStmt", v);

		if((yyvsp[(4) - (7)].ptr)->is_error || (yyvsp[(7) - (7)].ptr)->is_error)	{
			(yyval.ptr)->is_error = 1;
		}
	
        backpatch((yyvsp[(4) - (7)].ptr)->truelist, (yyvsp[(6) - (7)].number));
		(yyvsp[(7) - (7)].ptr)->nextlist.insert((yyvsp[(7) - (7)].ptr)->nextlist.end(), (yyvsp[(7) - (7)].ptr)->continuelist.begin(), (yyvsp[(7) - (7)].ptr)->continuelist.end());
        backpatch((yyvsp[(7) - (7)].ptr)->nextlist, (yyvsp[(3) - (7)].number));
        (yyval.ptr)->nextlist = (yyvsp[(4) - (7)].ptr)->falselist;
        (yyval.ptr)->nextlist.insert((yyval.ptr)->nextlist.end(), (yyvsp[(7) - (7)].ptr)->breaklist.begin(), (yyvsp[(7) - (7)].ptr)->breaklist.end());
        emit(qid("GOTO", NULL), qid("", NULL), qid("", NULL), qid("", NULL), (yyvsp[(3) - (7)].number));
    ;}
    break;

  case 216:
#line 2398 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(3) - (5)].ptr), "", 1);
		add_attribute(v, (yyvsp[(5) - (5)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("WhileStmtKind", v);
	;}
    break;

  case 217:
#line 2407 "parser.y"
    {
		vector<treeNode> v;
		// add_attribute(v, $2, "", 1);
		// add_attribute(v, $5, "", 1);
		add_attribute(v, (yyvsp[(3) - (9)].ptr), "", 1);
		add_attribute(v, (yyvsp[(7) - (9)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("DoStmt", v);
				if((yyvsp[(3) - (9)].ptr)->is_error || (yyvsp[(7) - (9)].ptr)->is_error)	{
			(yyval.ptr)->is_error = 1;
		}

        backpatch((yyvsp[(7) - (9)].ptr)->truelist, (yyvsp[(2) - (9)].number));
        (yyvsp[(3) - (9)].ptr)->nextlist.insert((yyvsp[(3) - (9)].ptr)->nextlist.end(), (yyvsp[(3) - (9)].ptr)->continuelist.begin(), (yyvsp[(3) - (9)].ptr)->continuelist.end());
		backpatch((yyvsp[(3) - (9)].ptr)->nextlist, (yyvsp[(6) - (9)].number));
        (yyval.ptr)->nextlist = (yyvsp[(7) - (9)].ptr)->falselist;
		(yyval.ptr)->nextlist.insert((yyval.ptr)->nextlist.end(), (yyvsp[(3) - (9)].ptr)->breaklist.begin(), (yyvsp[(3) - (9)].ptr)->breaklist.end());
	;}
    break;

  case 218:
#line 2426 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 219:
#line 2429 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 220:
#line 2432 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(3) - (13)].ptr), "", 1);
		add_attribute(v, (yyvsp[(6) - (13)].ptr), "", 1);
		add_attribute(v, (yyvsp[(9) - (13)].ptr), "", 1);
		add_attribute(v, (yyvsp[(13) - (13)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("BasicForStmt1", v);

		if((yyvsp[(3) - (13)].ptr)->is_error || (yyvsp[(6) - (13)].ptr)->is_error || (yyvsp[(9) - (13)].ptr)->is_error || (yyvsp[(13) - (13)].ptr)->is_error)	{
			(yyval.ptr)->is_error = 1;
		}
	
        backpatch((yyvsp[(3) - (13)].ptr)->nextlist, (yyvsp[(5) - (13)].number));
        backpatch((yyvsp[(6) - (13)].ptr)->truelist, (yyvsp[(12) - (13)].number));
        (yyval.ptr)->nextlist = (yyvsp[(6) - (13)].ptr)->falselist;
		(yyval.ptr)->nextlist.insert((yyval.ptr)->nextlist.end(), (yyvsp[(13) - (13)].ptr)->breaklist.begin(), (yyvsp[(13) - (13)].ptr)->breaklist.end());
		(yyvsp[(13) - (13)].ptr)->nextlist.insert((yyvsp[(13) - (13)].ptr)->nextlist.end(), (yyvsp[(13) - (13)].ptr)->continuelist.begin(), (yyvsp[(13) - (13)].ptr)->continuelist.end());
        backpatch((yyvsp[(13) - (13)].ptr)->nextlist, (yyvsp[(8) - (13)].number));
		(yyvsp[(9) - (13)].ptr)->nextlist.insert((yyvsp[(9) - (13)].ptr)->nextlist.end(), (yyvsp[(10) - (13)].ptr)->nextlist.begin(), (yyvsp[(10) - (13)].ptr)->nextlist.end());
        backpatch((yyvsp[(9) - (13)].ptr)->nextlist, (yyvsp[(5) - (13)].number));
        emit(qid("GOTO", NULL), qid("", NULL), qid("", NULL), qid("", NULL), (yyvsp[(8) - (13)].number));
    ;}
    break;

  case 221:
#line 2454 "parser.y"
    {
		vector<treeNode> v;
		// 3->3, 4->4, 5->6 , 7->9, 8->10 
		add_attribute(v, (yyvsp[(3) - (10)].ptr), "", 1);
		add_attribute(v, (yyvsp[(6) - (10)].ptr), "", 1);
		add_attribute(v, (yyvsp[(10) - (10)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("BasicForStmt5", v);

		if((yyvsp[(3) - (10)].ptr)->is_error || (yyvsp[(6) - (10)].ptr)->is_error || (yyvsp[(10) - (10)].ptr)->is_error)	{
			(yyval.ptr)->is_error = 1;
		}
        backpatch((yyvsp[(3) - (10)].ptr)->nextlist, (yyvsp[(4) - (10)].number));
        backpatch((yyvsp[(6) - (10)].ptr)->truelist, (yyvsp[(9) - (10)].number));
        (yyval.ptr)->nextlist = (yyvsp[(6) - (10)].ptr)->falselist;
		(yyval.ptr)->nextlist.insert((yyval.ptr)->nextlist.end(), (yyvsp[(10) - (10)].ptr)->breaklist.begin(), (yyvsp[(10) - (10)].ptr)->breaklist.end());
        (yyvsp[(10) - (10)].ptr)->nextlist.insert((yyvsp[(10) - (10)].ptr)->nextlist.end(), (yyvsp[(10) - (10)].ptr)->continuelist.begin(), (yyvsp[(10) - (10)].ptr)->continuelist.end());
        backpatch((yyvsp[(10) - (10)].ptr)->nextlist, (yyvsp[(4) - (10)].number));
        emit(qid("GOTO", NULL), qid("", NULL), qid("", NULL), qid("", NULL), (yyvsp[(4) - (10)].number));
	;}
    break;

  case 222:
#line 2473 "parser.y"
    {
		vector<treeNode> v;
		// add_attribute(v, $3, "", 1);
		add_attribute(v, (yyvsp[(4) - (7)].ptr), "", 1);
		add_attribute(v, (yyvsp[(7) - (7)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("BasicForStmt6", v);
	;}
    break;

  case 223:
#line 2480 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(3) - (7)].ptr), "", 1);
		// add_attribute(v, $4, "", 1);
		add_attribute(v, (yyvsp[(7) - (7)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("BasicForStmt7", v);
	;}
    break;

  case 224:
#line 2487 "parser.y"
    {
		vector<treeNode> v;
		// add_attribute(v, $3, "", 1);
		// add_attribute(v, $4, "", 1);
		add_attribute(v, (yyvsp[(6) - (6)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("BasicForStmt8", v);
	;}
    break;

  case 225:
#line 2494 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(4) - (8)].ptr), "", 1);
		add_attribute(v, (yyvsp[(6) - (8)].ptr), "", 1);
		add_attribute(v, (yyvsp[(8) - (8)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("BasicForStmt2", v);
	;}
    break;

  case 226:
#line 2501 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(3) - (8)].ptr), "", 1);
		add_attribute(v, (yyvsp[(6) - (8)].ptr), "", 1);
		add_attribute(v, (yyvsp[(8) - (8)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("BasicForStmt3", v);
	;}
    break;

  case 227:
#line 2508 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(5) - (7)].ptr), "", 1);
		add_attribute(v, (yyvsp[(7) - (7)].ptr), "", 1);
		// add_attribute(v, $6, "", 1);
		(yyval.ptr) = create_AST_node("BasicForStmt4", v);
	;}
    break;

  case 228:
#line 2518 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(3) - (13)].ptr), "", 1);
		add_attribute(v, (yyvsp[(6) - (13)].ptr), "", 1);
		add_attribute(v, (yyvsp[(9) - (13)].ptr), "", 1);
		add_attribute(v, (yyvsp[(13) - (13)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("BasicForStmtNoShortIf1", v);

		if((yyvsp[(3) - (13)].ptr)->is_error || (yyvsp[(6) - (13)].ptr)->is_error || (yyvsp[(9) - (13)].ptr)->is_error || (yyvsp[(13) - (13)].ptr)->is_error)	{
			(yyval.ptr)->is_error = 1;
		}
	
        backpatch((yyvsp[(3) - (13)].ptr)->nextlist, (yyvsp[(5) - (13)].number));
        backpatch((yyvsp[(6) - (13)].ptr)->truelist, (yyvsp[(12) - (13)].number));
        (yyval.ptr)->nextlist = (yyvsp[(6) - (13)].ptr)->falselist;
		(yyval.ptr)->nextlist.insert((yyval.ptr)->nextlist.end(), (yyvsp[(13) - (13)].ptr)->breaklist.begin(), (yyvsp[(13) - (13)].ptr)->breaklist.end());
		(yyvsp[(13) - (13)].ptr)->nextlist.insert((yyvsp[(13) - (13)].ptr)->nextlist.end(), (yyvsp[(13) - (13)].ptr)->continuelist.begin(), (yyvsp[(13) - (13)].ptr)->continuelist.end());
        backpatch((yyvsp[(13) - (13)].ptr)->nextlist, (yyvsp[(8) - (13)].number));
		(yyvsp[(9) - (13)].ptr)->nextlist.insert((yyvsp[(9) - (13)].ptr)->nextlist.end(), (yyvsp[(10) - (13)].ptr)->nextlist.begin(), (yyvsp[(10) - (13)].ptr)->nextlist.end());
        backpatch((yyvsp[(9) - (13)].ptr)->nextlist, (yyvsp[(5) - (13)].number));
        emit(qid("GOTO", NULL), qid("", NULL), qid("", NULL), qid("", NULL), (yyvsp[(8) - (13)].number));
    // }
	;}
    break;

  case 229:
#line 2541 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(4) - (8)].ptr), "", 1);
		add_attribute(v, (yyvsp[(6) - (8)].ptr), "", 1);
		add_attribute(v, (yyvsp[(8) - (8)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("BasicForStmtNoShortIf2", v);
	;}
    break;

  case 230:
#line 2548 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(3) - (8)].ptr), "", 1);
		add_attribute(v, (yyvsp[(6) - (8)].ptr), "", 1);
		add_attribute(v, (yyvsp[(8) - (8)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("BasicForStmtNoShortIf3", v);
	;}
    break;

  case 231:
#line 2555 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(5) - (7)].ptr), "", 1);
		add_attribute(v, (yyvsp[(7) - (7)].ptr), "", 1);
		// add_attribute(v, $6, "", 1);
		(yyval.ptr) = create_AST_node("BasicForStmtNoShortIf4", v);
	;}
    break;

  case 232:
#line 2562 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(3) - (10)].ptr), "", 1);
		add_attribute(v, (yyvsp[(6) - (10)].ptr), "", 1);
		add_attribute(v, (yyvsp[(10) - (10)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("BasicForStmtNoShortIf5", v);

		if((yyvsp[(3) - (10)].ptr)->is_error || (yyvsp[(6) - (10)].ptr)->is_error || (yyvsp[(10) - (10)].ptr)->is_error)	{
			(yyval.ptr)->is_error = 1;
		}

        backpatch((yyvsp[(3) - (10)].ptr)->nextlist, (yyvsp[(5) - (10)].number));
        backpatch((yyvsp[(6) - (10)].ptr)->truelist, (yyvsp[(9) - (10)].number));
        (yyval.ptr)->nextlist = (yyvsp[(6) - (10)].ptr)->falselist;
		(yyval.ptr)->nextlist.insert((yyval.ptr)->nextlist.end(), (yyvsp[(10) - (10)].ptr)->breaklist.begin(), (yyvsp[(10) - (10)].ptr)->breaklist.end());
        (yyvsp[(10) - (10)].ptr)->nextlist.insert((yyvsp[(10) - (10)].ptr)->nextlist.end(), (yyvsp[(10) - (10)].ptr)->continuelist.begin(), (yyvsp[(10) - (10)].ptr)->continuelist.end());
        backpatch((yyvsp[(10) - (10)].ptr)->nextlist, (yyvsp[(5) - (10)].number));
        emit(qid("GOTO", NULL), qid("", NULL), qid("", NULL), qid("", NULL), (yyvsp[(5) - (10)].number));
	;}
    break;

  case 233:
#line 2581 "parser.y"
    {
		vector<treeNode> v;
		// add_attribute(v, $3, "", 1);
		add_attribute(v, (yyvsp[(4) - (7)].ptr), "", 1);
		add_attribute(v, (yyvsp[(7) - (7)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("BasicForStmtNoShortIf6", v);
	;}
    break;

  case 234:
#line 2588 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(3) - (7)].ptr), "", 1);
		// add_attribute(v, $4, "", 1);
		add_attribute(v, (yyvsp[(7) - (7)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("BasicForStmtNoShortIf7", v);
	;}
    break;

  case 235:
#line 2595 "parser.y"
    {
		vector<treeNode> v;
		// add_attribute(v, $3, "", 1);
		// add_attribute(v, $4, "", 1);
		add_attribute(v, (yyvsp[(6) - (6)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("BasicForStmtNoShortIf8", v);
	;}
    break;

  case 236:
#line 2606 "parser.y"
    {if_found = 1;;}
    break;

  case 237:
#line 2606 "parser.y"
    { 
		if((yyvsp[(2) - (2)].ptr)->truelist.empty() && (yyvsp[(2) - (2)].ptr)->falselist.empty()) {
            int a = code.size();
			backpatch((yyvsp[(2) - (2)].ptr)->nextlist, a);
            emit(qid("GOTO", NULL),qid("IF", Lookup("if")), (yyvsp[(2) - (2)].ptr)->place, qid("", NULL ),0);
            int b = code.size();
            emit(qid("GOTO", NULL),qid("", NULL), qid("", NULL), qid("", NULL ),0);
            (yyvsp[(2) - (2)].ptr)->truelist.push_back(a);
            (yyvsp[(2) - (2)].ptr)->falselist.push_back(b);
        }
        (yyval.ptr) = (yyvsp[(2) - (2)].ptr);
		if_found = 0;
	;}
    break;

  case 238:
#line 2622 "parser.y"
    {
	int a = code.size();
	(yyval.ptr) = new Node;
	emit(qid("GOTO", NULL), qid("", NULL), qid("", NULL), qid("", NULL), 0);
	(yyval.ptr)->nextlist.push_back(a);
;}
    break;

  case 239:
#line 2630 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 240:
#line 2631 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 241:
#line 2634 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 242:
#line 2637 "parser.y"
    {
		vector<treeNode> attr;
		add_attribute(attr, (yyvsp[(1) - (4)].ptr), "", 1);
		add_attribute(attr, (yyvsp[(4) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("StmtExprList", attr);

		if(!(yyvsp[(1) - (4)].ptr)->is_error && !(yyvsp[(4) - (4)].ptr)->is_error){
			(yyval.ptr)->type = (yyvsp[(1) - (4)].ptr)->type;
			// 3AC 
			backpatch((yyvsp[(1) - (4)].ptr)->nextlist,(yyvsp[(3) - (4)].number));
			backpatch((yyvsp[(1) - (4)].ptr)->truelist,(yyvsp[(3) - (4)].number));
			backpatch((yyvsp[(1) - (4)].ptr)->falselist,(yyvsp[(3) - (4)].number));
			(yyval.ptr)->nextlist = (yyvsp[(4) - (4)].ptr)->nextlist;
			(yyval.ptr)->place = (yyvsp[(4) - (4)].ptr)->place;
		}
		else {
			(yyval.ptr)->is_error = 1;
		}

	;}
    break;

  case 243:
#line 2657 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 244:
#line 2660 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, create_AST_leaf((yyvsp[(1) - (3)].str), ""), "", 1);
		add_attribute(v, create_AST_leaf((yyvsp[(2) - (3)].str), ""), "", 1);
		// add_attribute(v, $2, "", 1);
		(yyval.ptr) = create_AST_node("CBreakStmt", v);
		//have not implemented labeled break
	;}
    break;

  case 245:
#line 2668 "parser.y"
    {
				   	(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (2)].str), "BREAK");
					      
					int a = code.size();
					emit(qid("GOTO", NULL), qid("", NULL), qid("", NULL), qid("", NULL), 0);
					(yyval.ptr)->breaklist.push_back(a);
				;}
    break;

  case 246:
#line 2677 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, create_AST_leaf((yyvsp[(1) - (3)].str), ""), "", 1);
		add_attribute(v, create_AST_leaf((yyvsp[(2) - (3)].str), ""), "", 1);
		// add_attribute(v, $2, "", 1);
		(yyval.ptr) = create_AST_node("ContinueStmt", v);
		///modify
		int a = code.size();
		emit(qid("GOTO", NULL), qid("", NULL), qid("", NULL), qid("", NULL), 0);
		(yyval.ptr)->continuelist.push_back(a);

		
	;}
    break;

  case 247:
#line 2690 "parser.y"
    {
					  	(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (2)].str), "CONTINUE");
						int a = code.size();
						emit(qid("GOTO", NULL), qid("", NULL), qid("", NULL), qid("", NULL), 0);
						(yyval.ptr)->continuelist.push_back(a);
				;}
    break;

  case 248:
#line 2698 "parser.y"
    {
		(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (2)].str), "RETURN");
	 	emit(qid("RETURN", NULL), qid("", NULL), qid("", NULL), qid("", NULL), -1);
	;}
    break;

  case 249:
#line 2702 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, create_AST_leaf((yyvsp[(1) - (3)].str), ""), "", 1);
		add_attribute(v, (yyvsp[(2) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ReturnStmt", v);

			if((yyvsp[(2) - (3)].ptr)->is_error)	{
			(yyval.ptr)->is_error = 1;
		}
		backpatch((yyvsp[(2) - (3)].ptr)->nextlist,code.size());
        emit(qid("RETURN", NULL), (yyvsp[(2) - (3)].ptr)->place, qid("", NULL), qid("", NULL), -1);
	;}
    break;

  case 250:
#line 2716 "parser.y"
    {
		vector<treeNode> v;
		// add_attribute(v, create_AST_leaf($1, ""), "", 1);
		add_attribute(v, (yyvsp[(2) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ThrowStmt", v);
	;}
    break;

  case 251:
#line 2724 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(3) - (5)].ptr), "", 1);
		add_attribute(v, (yyvsp[(5) - (5)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("SynchronizedStmt", v);
	;}
    break;

  case 252:
#line 2731 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(2) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("TryStmt1", v);
	;}
    break;

  case 253:
#line 2737 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(2) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("TryStmt2", v);
	;}
    break;

  case 254:
#line 2743 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(2) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(4) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("TryStmt3", v);
	;}
    break;

  case 255:
#line 2752 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(1) - (2)].ptr), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("Catches", v);
	;}
    break;

  case 256:
#line 2758 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 257:
#line 2761 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, (yyvsp[(3) - (5)].ptr), "", 1);
		add_attribute(v, (yyvsp[(5) - (5)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("CatchClause", v);
	;}
    break;

  case 258:
#line 2770 "parser.y"
    {
		vector<treeNode> v;
		// add_attribute(v, create_AST_leaf($1, ""), "", 1);
		add_attribute(v, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ResEnd:Finally", v);
	;}
    break;

  case 259:
#line 2778 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 260:
#line 2779 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 261:
#line 2782 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 262:
#line 2783 "parser.y"
    {(yyval.ptr) = (yyvsp[(2) - (3)].ptr);;}
    break;

  case 263:
#line 2784 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 264:
#line 2785 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 265:
#line 2786 "parser.y"
    { 

					  		(yyval.ptr) = create_AST_leaf((yyvsp[(1) - (1)].str), "THIS");
							(yyval.ptr)->place= qid(constructor_temporary,NULL);
				;}
    break;

  case 266:
#line 2791 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 267:
#line 2792 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 268:
#line 2795 "parser.y"
    {  // TYPECHECK
		vector<treeNode> attr;
		add_attribute(attr, create_AST_leaf((yyvsp[(1) - (5)].str), ""), "", 1);
		add_attribute(attr, (yyvsp[(2) - (5)].ptr), "", 1);
		add_attribute(attr, (yyvsp[(4) - (5)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ClassInstCreationExpr1", attr);
// cout<<"NISH3\n";
		if(type == "") type =  (yyvsp[(2) - (5)].ptr)->type;
		else type += " " + string((yyvsp[(1) - (5)].str));
		(yyval.ptr)->size= 1;
		string temp= (yyvsp[(2) - (5)].ptr)->type;
		
			// $$->isInit = $3->isInit; // { currArgs.push_back(vector<string>()); }  used in theirs 
			// cout<<"p2 "<<$2->type<<endl;
		// string temp = postfixExpr("FUNC_"+$2->type,3);
			// cout<<"p1 "<<temp<<endl;
		// if(temp.empty()){
		// 	temp = getFuncType($2->temp_name);
		// }
		int fl=0;
		if(!((yyvsp[(2) - (5)].ptr)->is_error || (yyvsp[(4) - (5)].ptr)->is_error) && (yyvsp[(2) - (5)].ptr)->expType!=4 && fl==0){
			// cout<<"ABIHSIHEIH "<<temp<<endl;
			if(!temp.empty()){	
				// cout<<"NISH2\n";
				(yyval.ptr)->type = temp;
				if((yyvsp[(2) - (5)].ptr)->expType ==3){
					// cout<<"NISH2\n";
					vector<string> funcArgs = getFuncArgs((yyvsp[(2) - (5)].ptr)->temp_name);
					vector<string> tempArgs =currArgs;
					for(int i=0;i<tempArgs.size();i++){
						// cout<<tempArgs[i]<<"F\n";

					}	
					for(int i=0;i<funcArgs.size();i++){
						if(funcArgs[i]=="...")break;
						if(tempArgs.size()==i){
							yyerror(("Too few Arguments to constructor " + (yyvsp[(2) - (5)].ptr)->temp_name).c_str());
							break;
						}
						string msg = chkType(funcArgs[i],tempArgs[i]);

						if(msg =="warning"){
							warning(("Incompatible conversion of " +  tempArgs[i] + " to parameter of type " + funcArgs[i]).c_str());
						}
						else if(msg.empty()){
							yyerror(("Incompatible Argument to the constructor " + (yyvsp[(2) - (5)].ptr)->temp_name).c_str());
							(yyval.ptr)->is_error = 1;
							break;
						}
						if(i==funcArgs.size()-1 && i<tempArgs.size()-1){
							yyerror(("Too many Arguments to constructor " + (yyvsp[(2) - (5)].ptr)->temp_name).c_str());
							(yyval.ptr)->is_error = 1;
							break;
						}

					}	
					//--3AC
					if(!(yyval.ptr)->is_error){
						int _idx = -1;
						// here, emitting a -1: index is set to code.size() here. 
						if((yyval.ptr)->type == "char*" && (yyval.ptr)->place.second == NULL) _idx = -4;
						emit(qid("param", NULL), (yyvsp[(2) - (5)].ptr)->place, qid("", NULL), qid("", NULL), _idx);
						qid q = newtemp((yyval.ptr)->type);
						// $$->place = q;
						(yyval.ptr)->place= (yyvsp[(2) - (5)].ptr)->place;
						(yyval.ptr)->nextlist.clear();
						// cout<<"name is "<<$2->temp_name<<"\n";
						sym_entry* sym= Lookup((yyvsp[(2) - (5)].ptr)->temp_name);
						// cout<<"CHECK "<<sym->paramsize<<"\n";
						emit(qid("CALL", NULL), qid((yyvsp[(2) - (5)].ptr)->temp_name,sym), qid(to_string(currArgs.size()), NULL), q, -1);
						// currArgs.pop_back();
						
						if(func_usage_map.find((yyvsp[(2) - (5)].ptr)->temp_name) != func_usage_map.end()){
							func_usage_map[(yyvsp[(2) - (5)].ptr)->temp_name] = 1;
						}
					}

				}
			}
			else{
				// cout<<"NISH4\n";
				yyerror("Invalid function call");
				(yyval.ptr)->is_error=1;
			}
		}
		else{
			// cout<<"NISH5\n";
			if((yyvsp[(2) - (5)].ptr)->expType==4){
				yyerror("constant expression cannot be used as lvalue");
			}
			(yyval.ptr)->is_error=1;
			// cout<<"NISH1\n";
		}
			
	;}
    break;

  case 269:
#line 2890 "parser.y"
    {
		vector<treeNode> attr;
		add_attribute(attr, create_AST_leaf((yyvsp[(1) - (4)].str), ""), "", 1);
		add_attribute(attr, (yyvsp[(2) - (4)].ptr), "", 1);
		// add_attribute(attr, $4, "", 1);
		(yyval.ptr) = create_AST_node("ClassInstCreationExpr2", attr);
		if(type == "") type = (yyvsp[(2) - (4)].ptr)->type;
		else type += " " + (yyvsp[(2) - (4)].ptr)->type;
		(yyval.ptr)->size= 1;

		(yyval.ptr)->isInit = 1;
		string temp = postfixExpr((yyvsp[(2) - (4)].ptr)->type,2);
		string blank_s = "";
		currArgs.push_back(blank_s ); 

		if(temp.empty()){
			temp = getFuncType((yyvsp[(2) - (4)].ptr)->temp_name);
		}

		if(!((yyvsp[(2) - (4)].ptr)->is_error) && (yyvsp[(2) - (4)].ptr)->expType!=4){
			if(!temp.empty()){	
				(yyval.ptr)->type = temp;
				if((yyvsp[(2) - (4)].ptr)->expType == 3){
					vector<string> funcArg = getFuncArgs((yyvsp[(2) - (4)].ptr)->temp_name);
					if(!funcArg.empty()){
						yyerror(("Too few Arguments to constructor " + (yyvsp[(2) - (4)].ptr)->temp_name).c_str());
					}
					else{

					//--3AC
						qid q = newtemp(temp);
						(yyval.ptr)->nextlist.clear();
						sym_entry* sym=	 Lookup((yyvsp[(2) - (4)].ptr)->temp_name);
						// cout<<"CHECK "<<sym->paramsize<<"\n";
						emit(qid("CALL", NULL), qid((yyvsp[(2) - (4)].ptr)->temp_name,sym), qid(to_string(currArgs.size()), NULL), q, -1);
						// emit(qid("CALL", NULL),qid($$->temp_name,NULL), qid("0", NULL), q, -1);
						currArgs.pop_back();
						//if(currArgs.size()>1)currArgs.push_back($$->type) ;
						// $$->place = q;
						(yyval.ptr)->place= (yyvsp[(2) - (4)].ptr)->place;

						if(func_usage_map.find((yyvsp[(2) - (4)].ptr)->temp_name) != func_usage_map.end()){
							func_usage_map[(yyvsp[(2) - (4)].ptr)->temp_name] = 1;
						}
					}
				}
			}
			else{
				
				yyerror(("Constructor " + (yyvsp[(2) - (4)].ptr)->temp_name + " not declared in this scope").c_str());
				(yyval.ptr)->is_error=1;
			}
		}
		else{
			if((yyvsp[(2) - (4)].ptr)->expType==4){
				yyerror("constant expression cannot be used as lvalue");
			}
			(yyval.ptr)->is_error=1;
		}
	;}
    break;

  case 270:
#line 2972 "parser.y"
    {
							(yyval.ptr) = (yyvsp[(1) - (1)].ptr);
							if(!(yyvsp[(1) - (1)].ptr)->is_error){
								//Semantic
								(yyval.ptr)->isInit = (yyvsp[(1) - (1)].ptr)->isInit;
								string temp_s;
								temp_s = (yyvsp[(1) - (1)].ptr)->type;
								// cout<<"The size of currArgs is "<<currArgs.size()<<endl;
								
								// cout<<$1->int_val<<"\n";
								currArgs.push_back((temp_s));
								// cout<<currArgs[0]<<"C\n";
								// currArgs.push_back($1->type);
								(yyval.ptr)->type = "void";

								//--3AC
								(yyval.ptr)->nextlist.clear();
								int _idx = -1;
								// here, emitting a -1: index is set to code.size() here. 
								if((yyval.ptr)->type == "char*" && (yyval.ptr)->place.second == NULL) _idx = -4;
								emit(qid("param", NULL), (yyval.ptr)->place, qid("", NULL), qid("", NULL), _idx);
							}
							else{
								(yyval.ptr)->is_error = 1;
							}
							(yyval.ptr)->nextlist.clear();
							int _idx = -1;
							if((yyval.ptr)->type == "char*" && (yyval.ptr)->place.second == NULL) _idx = -4;
							// emit(qid("param", NULL), $$->place, qid("", NULL), qid("", NULL), _idx);
						;}
    break;

  case 271:
#line 3002 "parser.y"
    {
											vector<treeNode> attr;
											add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
											add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
											(yyval.ptr) = create_AST_node("Arg_list", attr);
											//Semantic
											if(!((yyvsp[(1) - (3)].ptr)->is_error || (yyvsp[(3) - (3)].ptr)->is_error)){
												string temp = argExpr((yyvsp[(1) - (3)].ptr)->type, (yyvsp[(3) - (3)].ptr)->type, 2);

												if((yyvsp[(1) - (3)].ptr)->isInit && (yyvsp[(3) - (3)].ptr)->isInit) (yyval.ptr)->isInit=1;
												currArgs.push_back((yyvsp[(3) - (3)].ptr)->type);
												
												(yyval.ptr)->type = "void";

												//--3AC
												(yyval.ptr)->nextlist.clear();
												int _idx = -1;
												backpatch((yyvsp[(3) - (3)].ptr)->nextlist, code.size());
												if((yyvsp[(3) - (3)].ptr)->type == "char*" && (yyvsp[(3) - (3)].ptr)->place.second == NULL) _idx = -4;
												emit(qid("param", NULL), (yyvsp[(3) - (3)].ptr)->place, qid("", NULL), qid("", NULL), _idx);
											}
											else{
												(yyval.ptr)->is_error = 1;
											}
								
										;}
    break;

  case 272:
#line 3032 "parser.y"
    {
		
		vector<treeNode> attr;
		add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
		// add_attribute(attr, $3, "", 1);
		add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("Field access", attr);
		(yyval.ptr)->type = (yyvsp[(3) - (3)].ptr)->type;
		(yyval.ptr)->temp_name= (yyvsp[(3) - (3)].ptr)->temp_name;
		
		// Semantics

		// treats similar to a struct 
		if(!(yyvsp[(1) - (3)].ptr)->is_error && (yyvsp[(1) - (3)].ptr)->expType!=4){
			string temp = string((yyvsp[(3) - (3)].ptr)->temp_name);
			// cout<<"Will call find_table now"<<"\n";
			sym_table* ret = find_table(className);
			if(ret == nullptr){
				yyerror(("Class1 " + (yyvsp[(1) - (3)].ptr)->name + " not defined").c_str());
				(yyval.ptr)->is_error = 1;
			}
			// else{
			// 	cout<<"ret="<<"CLASS_"+$1->type<<endl;
			// 	for(map<string, sym_entry*>::iterator it = ret->begin(); it!=ret->end(); it++){ cout<<it->first<<endl; }
			// }
			sym_entry* r;
			r= find_in_table(temp, ret);
			if (r == nullptr){
				yyerror(("Class1 " + (yyvsp[(1) - (3)].ptr)->type + " has no field " + string((yyvsp[(3) - (3)].ptr)->temp_name)).c_str());
				(yyval.ptr)->is_error = 1;
			}
			else{
				(yyval.ptr)->type = r->type;
				(yyval.ptr)->temp_name = (yyvsp[(1) - (3)].ptr)->temp_name + "." + temp;
				qid temp_var1 = newtemp((yyval.ptr)->type);
				emit(qid("=", r), qid(to_string(r->offset),NULL), qid("",NULL), temp_var1, -1);
				qid temp_var = newtemp((yyval.ptr)->type);
				// adds a temporary variable(for 3AC) to symbol table. 
				// cout<<"In qual name "<<$1->place.first<<endl;
				sym_entry* attr_sym = retTypeAttrEntry(r);
				emit(qid("qualname", r), (yyvsp[(1) - (3)].ptr)->place, temp_var1, temp_var, -1);
				temp_var.second->array_dims = attr_sym->array_dims;
				(yyval.ptr)->place = temp_var;
			}
		}
		else{
			if((yyvsp[(1) - (3)].ptr)->expType==4){
				yyerror("constant expression cannot be used as lvalue");
			}
			(yyval.ptr)->is_error = 1;
		}
		
		// if(!$3->is_error){
		// 	if(CurLookup($3->temp_name) ){
		// 		string errstr = $3->temp_name + " is already declared";
		// 		yyerror(errstr.c_str());
		// 		$$->is_error = 1;
		// 	}
		// 	else if($3->expType == 3){
		// 		if(fn_decl){
		// 			yyerror("A parameter list without types is only allowed in a function definition");
		// 			$$->is_error = 1;

		// 			fn_decl = 0;
		// 		}
		// 		DeleteFunctionPrototype();
		// 		code.pop_back();
		// 	}
		// 	else{
		// 		if(storage_class != "typedef"){
		// 			// cout<<"GG\n";
		// 			// insertSymbol(*curr_table, $3->temp_name, $3->type, $3->size, 0, NULL);
		// 			qid temp= newtemp($3->type);
		// 			sym_entry* sym= Lookup($3->temp_name);
		// 			if(sym==nullptr)
		// 			{
		// 				yyerror(($3->temp_name+ " field access error").c_str());
		// 			}
		// 			emit(qid("=",sym),qid(to_string(sym->offset),NULL),qid("",NULL),temp,-1 );
		// 			// cout<<" RONNIE "<<className<<endl;
		// 			// $$->place = qid($3->temp_name, sym);
		// 			$$->place = qid(className, sym);
		// 			isArray = 0;
		// 		}
		// 		else{
		// 			insertTypedef(*curr_table, $3->temp_name, $3->type, $3->size, 0, NULL);
		// 			$$->place = qid($3->temp_name, Lookup($3->temp_name));
		// 		} 
		// 	}
		// }
		// else $$->is_error = 1;
	;}
    break;

  case 273:
#line 3124 "parser.y"
    {
		vector<treeNode> attr;
		add_attribute(attr, create_AST_leaf((yyvsp[(1) - (3)].str), "IDENTIFIER"), "", 1);

		add_attribute(attr, create_AST_leaf((yyvsp[(3) - (3)].str),"IDENTIFIER"), "", 1);
		(yyval.ptr) = create_AST_node("Field access", attr);
	;}
    break;

  case 274:
#line 3142 "parser.y"
    {
		vector<treeNode> v, v2;
		add_attribute(v2, (yyvsp[(3) - (4)].ptr), "", 1);
		Node* node = create_AST_node("[ ]", v2);
		add_attribute(v, (yyvsp[(1) - (4)].ptr), "", 1);
		add_attribute(v, node, "", 1);
		(yyval.ptr) = create_AST_node("ArrOp1", v);
		// cout<<"Access tp 2\n";/
		//Semantics
		if((yyvsp[(1) - (4)].ptr)->isInit && (yyvsp[(3) - (4)].ptr)->isInit){
			(yyval.ptr)->isInit = 1;
		}
		if(!checkArrExpr((yyvsp[(3) - (4)].ptr)->type)) {
			yyerror(("Array index " + (yyvsp[(3) - (4)].ptr)->temp_name +  " is not integral").c_str());
		}
		// seems like a check we need to do.
		// why is there no error thrown when both are not initialised? 
		// cout<<"Array 2718 "<<$1->type<<endl;
		string temp = postfixExpr((yyvsp[(1) - (4)].ptr)->type,1); //the type_name passed to the function is stored in postifix expr
		string base_type= find_base_type((yyvsp[(1) - (4)].ptr)->type);
		if(!((yyvsp[(1) - (4)].ptr)->is_error || (yyvsp[(3) - (4)].ptr)->is_error) && (yyvsp[(1) - (4)].ptr)->expType!=4){
			if(!temp.empty()){	
				(yyval.ptr)->type = temp;

				//--3AC
				qid temp_var1 = newtemp((yyval.ptr)->type);
				// emit(qid("*", NULL),$3->place , qid(to_string(GetSize($$->type)),NULL), temp_var1, -1);	
				int t=1;
				arr_index[(yyvsp[(1) - (4)].ptr)->temp_name]++;
				for(int i=arr_index[(yyvsp[(1) - (4)].ptr)->temp_name];i<arr_dimensions[(yyvsp[(1) - (4)].ptr)->temp_name].size();i++)
				{
					t*= arr_dimensions[(yyvsp[(1) - (4)].ptr)->temp_name][i];
				}
				// cout<<"FIRST DIM "<<$3->int_val<<"\n";
			
					if(((yyvsp[(3) - (4)].ptr)->int_val!=-1 && arr_dimensions[(yyvsp[(1) - (4)].ptr)->temp_name][0]!=-1) && (yyvsp[(3) - (4)].ptr)->int_val>=arr_dimensions[(yyvsp[(1) - (4)].ptr)->temp_name][0]) {
					yyerror(("Array index3 " + (yyvsp[(3) - (4)].ptr)->temp_name +  " is out of bound").c_str());
		
				}
					
				emit(qid("*", NULL), (yyvsp[(3) - (4)].ptr)->place , qid(to_string(t*GetSize(base_type)),NULL), temp_var1, -1);
				//returns the symbol table entry to the temporary variable 
				//array_dims is a vector<int> in sym_entry*
				// $$->place= temp_var1;

				if(arr_index[(yyvsp[(1) - (4)].ptr)->temp_name]==arr_dimensions[(yyvsp[(1) - (4)].ptr)->temp_name].size()) 
				{
					qid temp_var = newtemp((yyval.ptr)->type); 
					temp_var.second->array_dims = (yyvsp[(1) - (4)].ptr)->place.second->array_dims;
					if(temp_var.second->array_dims.size()) temp_var.second->array_dims.erase(temp_var.second->array_dims.begin());
					// $$->place = temp_var;
					// emit(qid("[ ]", NULL), $1->place, $3->place, temp_var, -1);	
					// cout<<"Name place is "<<$1->place.first<<"\n";
					sym_entry* sym= Lookup((yyvsp[(1) - (4)].ptr)->temp_name);
					if(sym==nullptr)
					{
						yyerror(((yyvsp[(1) - (4)].ptr)->temp_name + ": array not defined").c_str());
					}
					emit(qid("[ ]", sym), (yyvsp[(1) - (4)].ptr)->place, temp_var1, temp_var, -1);	
					(yyval.ptr)->nextlist.clear();
					(yyval.ptr)->place= temp_var;
					arr_index[(yyvsp[(1) - (4)].ptr)->temp_name]=0;
				}
				else
				{
					(yyval.ptr)->place= temp_var1;
					(yyval.ptr)->nextlist.clear();
					// $$->temp_name= $1->place.first;
					(yyval.ptr)->temp_name= (yyvsp[(1) - (4)].ptr)->temp_name;
				}
			}
			else{
				yyerror(((yyvsp[(1) - (4)].ptr)->temp_name +  " is not an array").c_str());
				(yyval.ptr)->is_error=1;
			}
		}
		else{
			if((yyvsp[(1) - (4)].ptr)->expType==4){
				yyerror("constant expression cannot be used as lvalue");
			}
			(yyval.ptr)->is_error=1;
		}
	;}
    break;

  case 275:
#line 3225 "parser.y"
    {
		vector<treeNode> v, v2;
		add_attribute(v2, (yyvsp[(3) - (4)].ptr), "", 1);
		Node* node = create_AST_node("[ ]", v2);
		add_attribute(v, (yyvsp[(1) - (4)].ptr), "", 1);
		add_attribute(v, node, "", 1);
		(yyval.ptr) = create_AST_node("ArrOp2", v);
		(yyval.ptr)->temp_name= (yyvsp[(1) - (4)].ptr)->temp_name;
		(yyval.ptr)->type= (yyvsp[(1) - (4)].ptr)->type;
		// cout<<"Access tp 1\n";
		//Semantics
		// cout<<$1->temp_name<<"\n";
		if((yyvsp[(1) - (4)].ptr)->isInit && (yyvsp[(3) - (4)].ptr)->isInit){
			(yyval.ptr)->isInit = 1;
		}
		if(!checkArrExpr((yyvsp[(3) - (4)].ptr)->type)) {
			yyerror(("Array index " + (yyvsp[(3) - (4)].ptr)->temp_name +  " is not integral").c_str());
		}
		string temp = postfixExpr((yyvsp[(1) - (4)].ptr)->type,1);
		string base_type= find_base_type((yyvsp[(1) - (4)].ptr)->type);
		if(!((yyvsp[(1) - (4)].ptr)->is_error || (yyvsp[(3) - (4)].ptr)->is_error) && (yyvsp[(1) - (4)].ptr)->expType!=4){
			if(!temp.empty()){	
				(yyval.ptr)->type = temp;
				qid temp_var1 = newtemp((yyval.ptr)->type);
				int t=1;
				if(((yyvsp[(3) - (4)].ptr)->int_val!=-1 && arr_dimensions[(yyvsp[(1) - (4)].ptr)->temp_name][0]!=-1) && (yyvsp[(3) - (4)].ptr)->int_val>=arr_dimensions[(yyvsp[(1) - (4)].ptr)->temp_name][arr_index[(yyvsp[(1) - (4)].ptr)->temp_name]]) {
			yyerror(("Array index1 " + (yyvsp[(3) - (4)].ptr)->temp_name +  " is out of bound").c_str());
		}
				arr_index[(yyvsp[(1) - (4)].ptr)->temp_name]++;
				for(int i=arr_index[(yyvsp[(1) - (4)].ptr)->temp_name];i<arr_dimensions[(yyvsp[(1) - (4)].ptr)->temp_name].size();i++)
				{
					t*= arr_dimensions[(yyvsp[(1) - (4)].ptr)->temp_name][i];
				}
				
				emit(qid("*", NULL), (yyvsp[(3) - (4)].ptr)->place , qid(to_string(t*GetSize(base_type)),NULL), temp_var1, -1);
				qid temp_var = newtemp((yyval.ptr)->type);
				temp_var.second->array_dims = (yyvsp[(1) - (4)].ptr)->place.second->array_dims;
				if(temp_var.second->array_dims.size()) temp_var.second->array_dims.erase(temp_var.second->array_dims.begin());
				// $$->place = temp_var;
				emit(qid("+", NULL), (yyvsp[(1) - (4)].ptr)->place, temp_var1, temp_var, -1);	
				(yyval.ptr)->nextlist.clear();
				//--3AC
				(yyval.ptr)->place= temp_var;
				// cout<<arr_index[$1->temp_name]<<" "<<arr_dimensions[$1->temp_name].size()<<"\n";
				if(arr_index[(yyvsp[(1) - (4)].ptr)->temp_name]==arr_dimensions[(yyvsp[(1) - (4)].ptr)->temp_name].size())
				{
					sym_entry* sym= Lookup((yyvsp[(1) - (4)].ptr)->temp_name);
					if(sym==nullptr)
					{
						yyerror((((yyvsp[(1) - (4)].ptr)->temp_name + ": Multidim array not defined")).c_str());
					}
					// cout<<"In\n";
					qid temp_var2 = newtemp((yyval.ptr)->type);
					temp_var2.second->array_dims = (yyvsp[(1) - (4)].ptr)->place.second->array_dims;
					if(temp_var2.second->array_dims.size()) temp_var2.second->array_dims.erase(temp_var2.second->array_dims.begin());
					(yyval.ptr)->place = temp_var2;
					emit(qid("[ ]", sym),qid(sym->place, NULL), temp_var, temp_var2, -1);	
					(yyval.ptr)->nextlist.clear();
					arr_index[(yyvsp[(1) - (4)].ptr)->temp_name]=0;
				} 
			}
			else{
				yyerror(("Array0 " + (yyvsp[(1) - (4)].ptr)->temp_name +  " Index out of bound").c_str());
				(yyval.ptr)->is_error=1;
			}
		}
		else{
			if((yyvsp[(1) - (4)].ptr)->expType==4){
				yyerror("constant expression cannot be used as lvalue");
			}
			(yyval.ptr)->is_error=1;
		}
			//Semantics
		// if($1->isInit && $3->isInit){
		// 	$$->isInit = 1;
		// }
		// // seems like a check we need to do.
		// // why is there no error thrown when both are not initialised? 
		// string temp = postfixExpr($1->type,1); //the type_name passed to the function is stored in postifix expr
		// if(!checkArrExpr($3->type)) {
		// 	yyerror(("Array index " + $3->temp_name +  " is not integral").c_str());
		// }
		// if(!temp.empty()){
		// 	$$->type = temp;
		// }
		// else{
		// 	// empty is only returned when we encounter an unknown type or some other error. 
		// 	yyerror(("Array " + $1->temp_name +  " Index out of bound1").c_str());
		// }

	;}
    break;

  case 276:
#line 3318 "parser.y"
    {   // TYPECHECK
		vector<treeNode> attr;
		add_attribute(attr, (yyvsp[(1) - (4)].ptr), "", 1);
		add_attribute(attr, (yyvsp[(3) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("MethodInvocation1", attr);

			//Semantics
		(yyval.ptr)->isInit = (yyvsp[(3) - (4)].ptr)->isInit; // { currArgs.push_back(vector<string>()); }  used in theirs 
		string temp = postfixExpr((yyvsp[(1) - (4)].ptr)->type,3);
		if(temp.empty()){
			temp = getFuncType((yyvsp[(1) - (4)].ptr)->temp_name);
		}
		int fl=0;
		if((yyvsp[(1) - (4)].ptr)->temp_name=="System.out.println")
		{
			fl=1;
			// cout<<"YEA \n";
		}
		if(!((yyvsp[(1) - (4)].ptr)->is_error || (yyvsp[(3) - (4)].ptr)->is_error) && (yyvsp[(1) - (4)].ptr)->expType!=4){
			if(!temp.empty()){	
				(yyval.ptr)->type = temp;
				if((yyvsp[(1) - (4)].ptr)->expType ==3){
					vector<string> funcArgs = getFuncArgs((yyvsp[(1) - (4)].ptr)->temp_name);
					
					// cout<<endl;
					vector<string> tempArgs =currArgs;
					if(fl==0)
					{
						for(int i=0;i<funcArgs.size();i++)
						{
							if(funcArgs[i]=="...")break;
							if(tempArgs.size()==i){
								yyerror(("Too few Arguments to Function " + (yyvsp[(1) - (4)].ptr)->temp_name).c_str());
								break;
							}
							string msg = chkType(funcArgs[i],tempArgs[i]);

							if(msg =="warning"){
								warning(("Incompatible conversion of " +  tempArgs[i] + " to parameter of type " + funcArgs[i]).c_str());
							}
							else if(msg.empty()){
								yyerror(("Incompatible Argument to the function " + (yyvsp[(1) - (4)].ptr)->temp_name).c_str());
								(yyval.ptr)->is_error = 1;
								break;
							}
							if(i==funcArgs.size()-1 && i<tempArgs.size()-1){
								yyerror(("Too many Arguments to Function " + (yyvsp[(1) - (4)].ptr)->temp_name).c_str());
								(yyval.ptr)->is_error = 1;
								break;
							}

						}	
					}
					
					//--3AC
					if(!(yyval.ptr)->is_error){
						qid q = newtemp((yyval.ptr)->type);
						(yyval.ptr)->place = q;
						
						(yyval.ptr)->nextlist.clear();
						// cout<<"name is "<<$1->temp_name<<"\n";
						sym_entry* sym= Lookup((yyvsp[(1) - (4)].ptr)->temp_name);
						//cout<<"CHECK "<<sym->paramsize<<"\n";
						if((yyvsp[(1) - (4)].ptr)->temp_name== "System.out.println") (yyvsp[(1) - (4)].ptr)->temp_name= "print";
						emit(qid("CALL", NULL), qid((yyvsp[(1) - (4)].ptr)->temp_name,sym), qid(to_string(currArgs.size()), NULL), q, -1);
						// currArgs.pop_back();
						currArgs.clear();

						if(func_usage_map.find((yyvsp[(1) - (4)].ptr)->temp_name) != func_usage_map.end()){
							func_usage_map[(yyvsp[(1) - (4)].ptr)->temp_name] = 1;
						}
					}

				}
			}
			else{
				yyerror("Invalid function call");
				(yyval.ptr)->is_error=1;
			}
		}
		else{
			if((yyvsp[(1) - (4)].ptr)->expType==4){
				yyerror("constant expression cannot be used as lvalue");
			}
			(yyval.ptr)->is_error=1;
		}
	;}
    break;

  case 277:
#line 3405 "parser.y"
    { 
					 
					 (yyval.ptr)= (yyvsp[(1) - (3)].ptr);  //done
					//Semantics
		(yyval.ptr)->isInit = 1;
		string temp = postfixExpr((yyvsp[(1) - (3)].ptr)->type,2);
		string blank_s = "";
		currArgs.push_back(blank_s ); 

		if(temp.empty()){
			temp = getFuncType((yyvsp[(1) - (3)].ptr)->temp_name);
		}

		if(!((yyvsp[(1) - (3)].ptr)->is_error) && (yyvsp[(1) - (3)].ptr)->expType!=4){
			if(!temp.empty()){	
				(yyval.ptr)->type = temp;
				if((yyvsp[(1) - (3)].ptr)->expType == 3){
					vector<string> funcArg = getFuncArgs((yyvsp[(1) - (3)].ptr)->temp_name);
					if(!funcArg.empty()){
						yyerror(("Too few Arguments to Function " + (yyvsp[(1) - (3)].ptr)->temp_name).c_str());
					}
					else{

					//--3AC
						qid q = newtemp(temp);
						(yyval.ptr)->nextlist.clear();
						sym_entry* sym= Lookup((yyvsp[(1) - (3)].ptr)->temp_name);
						//cout<<"CHECK "<<sym->paramsize<<"\n";
						if((yyvsp[(1) - (3)].ptr)->temp_name== "System.out.println") (yyvsp[(1) - (3)].ptr)->temp_name= "print";
						emit(qid("CALL", NULL), qid((yyvsp[(1) - (3)].ptr)->temp_name,sym), qid(to_string(currArgs.size()), NULL), q, -1);
						// emit(qid("CALL", NULL),qid($$->temp_name,NULL), qid("0", NULL), q, -1);
						// currArgs.pop_back();
						currArgs.clear();
						//if(currArgs.size()>1)currArgs.push_back($$->type) ;
						(yyval.ptr)->place = q;

						if(func_usage_map.find((yyvsp[(1) - (3)].ptr)->temp_name) != func_usage_map.end()){
							func_usage_map[(yyvsp[(1) - (3)].ptr)->temp_name] = 1;
						}
					}
				}
			}
			else{
				yyerror(("Function " + (yyvsp[(1) - (3)].ptr)->temp_name + " not declared in this scope").c_str());
				(yyval.ptr)->is_error=1;
			}
		}
		else{
			if((yyvsp[(1) - (3)].ptr)->expType==4){
				yyerror("constant expression cannot be used as lvalue");
			}
			(yyval.ptr)->is_error=1;
		}

				 		;}
    break;

  case 278:
#line 3461 "parser.y"
    {
		vector<treeNode> v, v2;
		add_attribute(v2, (yyvsp[(1) - (6)].ptr), "", 1);
		add_attribute(v2, create_AST_leaf((yyvsp[(3) - (6)].str),"IDENTIFIER"), "", 1);
		Node* node = create_AST_node((yyvsp[(2) - (6)].str), v2);
		add_attribute(v, node, "", 1);
		add_attribute(v, (yyvsp[(5) - (6)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("MethodInvocation2", v);
		//Semantics
		
		if(!(yyvsp[(1) - (6)].ptr)->is_error && (yyvsp[(1) - (6)].ptr)->expType!=4){
			string temp = string((yyvsp[(3) - (6)].str));
			sym_table* ret = find_table("CLASS_"+(yyvsp[(1) - (6)].ptr)->type);
			if(ret == nullptr){
				yyerror(("Class " + (yyvsp[(1) - (6)].ptr)->name + " not defined").c_str());
				(yyval.ptr)->is_error = 1;
			}
			sym_entry* r;
			r= find_in_table(temp, ret);
			if (r == nullptr){
				yyerror(("Class " + (yyvsp[(1) - (6)].ptr)->type + " has no field " + string((yyvsp[(3) - (6)].str))).c_str());
				(yyval.ptr)->is_error = 1;
			}
			else{
				(yyval.ptr)->type = r->type;
				(yyval.ptr)->temp_name = (yyvsp[(1) - (6)].ptr)->temp_name + "." + temp;
				
				qid temp_var = newtemp((yyval.ptr)->type);
				sym_entry* attr_sym = retTypeAttrEntry(r);
				emit(qid("member_access", NULL), (yyvsp[(1) - (6)].ptr)->place, qid(string((yyvsp[(3) - (6)].str)), attr_sym), temp_var, -1);
				temp_var.second->array_dims = attr_sym->array_dims;
				(yyval.ptr)->place = temp_var;
			}
		}
		else{
			if((yyvsp[(1) - (6)].ptr)->expType==4){
				yyerror("constant expression cannot be used as lvalue");
			}
			(yyval.ptr)->is_error = 1;
		}
		(yyval.ptr)->isInit = (yyvsp[(5) - (6)].ptr)->isInit;
		string temp = postfixExpr((yyvsp[(1) - (6)].ptr)->type,3);
		if(temp.empty()){
			temp = getFuncType((yyvsp[(1) - (6)].ptr)->temp_name);
		}

		if(!((yyvsp[(1) - (6)].ptr)->is_error || (yyvsp[(5) - (6)].ptr)->is_error) && (yyvsp[(1) - (6)].ptr)->expType!=4){
			if(!temp.empty()){	
				(yyval.ptr)->type = temp;
				if((yyvsp[(1) - (6)].ptr)->expType ==3){
					vector<string> funcArgs = getFuncArgs((yyvsp[(1) - (6)].ptr)->temp_name);
					vector<string> tempArgs =currArgs;
					for(int i=0;i<funcArgs.size();i++){
						if(funcArgs[i]=="...")break;
						if(tempArgs.size()==i){
							yyerror(("Too few Arguments to Function " + (yyvsp[(1) - (6)].ptr)->temp_name).c_str());
							break;
						}
						string msg = chkType(funcArgs[i],tempArgs[i]);

						if(msg =="warning"){
							warning(("Incompatible conversion of " +  tempArgs[i] + " to parameter of type " + funcArgs[i]).c_str());
						}
						else if(msg.empty()){
							yyerror(("Incompatible Argument to the function " + (yyvsp[(1) - (6)].ptr)->temp_name).c_str());
							(yyval.ptr)->is_error = 1;
							break;
						}
						if(i==funcArgs.size()-1 && i<tempArgs.size()-1){
							yyerror(("Too many Arguments to Function " + (yyvsp[(1) - (6)].ptr)->temp_name).c_str());
							(yyval.ptr)->is_error = 1;
							break;
						}

					}	

					//--3AC
					if(!(yyval.ptr)->is_error){
						qid q = newtemp((yyval.ptr)->type);
						(yyval.ptr)->place = q;
						(yyval.ptr)->nextlist.clear();

						emit(qid("CALL", NULL), qid((yyvsp[(1) - (6)].ptr)->temp_name,NULL), qid(to_string(currArgs.size()), NULL), q, -1);
						// currArgs.pop_back();

						currArgs.clear();
						if(func_usage_map.find((yyvsp[(1) - (6)].ptr)->temp_name) != func_usage_map.end()){
							func_usage_map[(yyvsp[(1) - (6)].ptr)->temp_name] = 1;
						}
					}

				}
			}
			else{
				yyerror("Invalid function call");
				(yyval.ptr)->is_error=1;
			}
		}
		else{
			if((yyvsp[(1) - (6)].ptr)->expType==4){
				yyerror("constant expression cannot be used as lvalue");
			}
			(yyval.ptr)->is_error=1;
		}

	;}
    break;

  case 279:
#line 3567 "parser.y"
    {
		
		vector<treeNode> attr;
		add_attribute(attr, (yyvsp[(1) - (5)].ptr), "", 1);
		add_attribute(attr, create_AST_leaf((yyvsp[(2) - (5)].str), ""), "", 1);
		add_attribute(attr, create_AST_leaf((yyvsp[(3) - (5)].str), "IDENTIFIER"), "", 1);
		(yyval.ptr) = create_AST_node("MethodInvocation3", attr);
		//Semantics

		if(!(yyvsp[(1) - (5)].ptr)->is_error && (yyvsp[(1) - (5)].ptr)->expType!=4){
			string temp = string((yyvsp[(3) - (5)].str));
			sym_table* ret = find_table("CLASS_"+(yyvsp[(1) - (5)].ptr)->type);
			if(ret == nullptr){
				yyerror(("Class " + (yyvsp[(1) - (5)].ptr)->name + " not defined").c_str());
				(yyval.ptr)->is_error = 1;
			}
			sym_entry* r;
			r= find_in_table(temp, ret);
			if (r == nullptr){
				yyerror(("Class " + (yyvsp[(1) - (5)].ptr)->type + " has no field " + string((yyvsp[(3) - (5)].str))).c_str());
				(yyval.ptr)->is_error = 1;
			}
			else{
				(yyval.ptr)->type = r->type;
				(yyval.ptr)->temp_name = (yyvsp[(1) - (5)].ptr)->temp_name + "." + temp;
				
				qid temp_var = newtemp((yyval.ptr)->type);
				sym_entry* attr_sym = retTypeAttrEntry(r);
				emit(qid("member_access", NULL), (yyvsp[(1) - (5)].ptr)->place, qid(string((yyvsp[(3) - (5)].str)), attr_sym), temp_var, -1);
				temp_var.second->array_dims = attr_sym->array_dims;
				(yyval.ptr)->place = temp_var;
			}
		}
		else{
			if((yyvsp[(1) - (5)].ptr)->expType==4){
				yyerror("constant expression cannot be used as lvalue");
			}
			(yyval.ptr)->is_error = 1;
		}
		(yyval.ptr)->isInit = 1;
		string temp = postfixExpr((yyvsp[(1) - (5)].ptr)->type,2);
		// blank_s = {};
		currArgs.push_back(""); 

		if(temp.empty()){
			temp = getFuncType((yyvsp[(1) - (5)].ptr)->temp_name);
		}

		if(!((yyvsp[(1) - (5)].ptr)->is_error) && (yyvsp[(1) - (5)].ptr)->expType!=4){
			if(!temp.empty()){	
				(yyval.ptr)->type = temp;
				if((yyvsp[(1) - (5)].ptr)->expType == 3){
					vector<string> funcArg = getFuncArgs((yyvsp[(1) - (5)].ptr)->temp_name);
					if(!funcArg.empty()){
						yyerror(("Too few Arguments to Function " + (yyvsp[(1) - (5)].ptr)->temp_name).c_str());
					}
					else{

					//--3AC
						qid q = newtemp(temp);
						(yyval.ptr)->nextlist.clear();

						emit(qid("CALL", NULL),qid((yyval.ptr)->temp_name,NULL), qid("0", NULL), q, -1);
						// currArgs.pop_back();
						currArgs.clear();
						//if(currArgs.size()>1)currArgs.push_back($$->type) ;
						(yyval.ptr)->place = q;

						if(func_usage_map.find((yyvsp[(1) - (5)].ptr)->temp_name) != func_usage_map.end()){
							func_usage_map[(yyvsp[(1) - (5)].ptr)->temp_name] = 1;
						}
					}
				}
			}
			else{
				yyerror(("Function " + (yyvsp[(1) - (5)].ptr)->temp_name + " not declared in this scope").c_str());
				(yyval.ptr)->is_error=1;
			}
		}
		else{
			if((yyvsp[(1) - (5)].ptr)->expType==4){
				yyerror("constant expression cannot be used as lvalue");
			}
			(yyval.ptr)->is_error=1;
		}

		
	;}
    break;

  case 280:
#line 3655 "parser.y"
    {
		
		vector<treeNode> attr;
		add_attribute(attr, create_AST_leaf((yyvsp[(1) - (6)].str), ""), "", 1);
		add_attribute(attr, create_AST_leaf((yyvsp[(2) - (6)].str), ""), "", 1);
		add_attribute(attr, (yyvsp[(3) - (6)].ptr), "", 1);
		add_attribute(attr, (yyvsp[(5) - (6)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("MethodInvocation4", attr);
	;}
    break;

  case 281:
#line 3664 "parser.y"
    {
		vector<treeNode> attr;
		add_attribute(attr, create_AST_leaf((yyvsp[(1) - (5)].str), ""), "", 1);
		add_attribute(attr, create_AST_leaf((yyvsp[(2) - (5)].str), ""), "", 1);
		add_attribute(attr, (yyvsp[(3) - (5)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("MethodInvocation5", attr);
	;}
    break;

  case 282:
#line 3674 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, create_AST_leaf((yyvsp[(1) - (4)].str), ""), "", 1);
		add_attribute(v, (yyvsp[(2) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(4) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ArrCreationExpr1", v);

	;}
    break;

  case 283:
#line 3683 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, create_AST_leaf((yyvsp[(1) - (3)].str), ""), "", 1);
		add_attribute(v, (yyvsp[(2) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ArrCreationExpr2", v);
		(yyval.ptr)->dims= (yyvsp[(3) - (3)].ptr)->dims;
		//cout<<"NEW "<<$3->dims.size()<<" "<<$3->dims[0]<<"\n";

		qid tmp = newtemp((yyval.ptr)->type);
		qid tmp1 = newtemp((yyval.ptr)->type);
		// cout<<"If found kdhe "<<if_found<<"\n";
		int temp=1;
		//cout<<"SISZEE "<<$3->dims[0]<<" "<<$3->dims.size()<<endl;
		//cout<<"DA TYPE IS "<<$2->type<<endl;
		for(int i=0;i<(yyvsp[(3) - (3)].ptr)->dims.size();i++)
		{
			temp*=(yyvsp[(3) - (3)].ptr)->dims[i];
		}
		// emit(qid("NEW", NULL), qid(to_string(temp*GetSize($2->type)), NULL), qid("", NULL), tmp, -1);
			emit(qid("NEW", NULL), qid(to_string(temp*GetSize((yyvsp[(2) - (3)].ptr)->type)), NULL), tmp1, tmp, -1);	
		(yyval.ptr)->place= tmp1;
		// emit(qid("NEW", NULL), qid(to_string(temp*GetSize($2->type)), NULL), qid("", NULL), qid("", NULL), -1);
		// $$->place = tmp;

		// $$= $3;
	;}
    break;

  case 284:
#line 3710 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, create_AST_leaf((yyvsp[(1) - (4)].str), ""), "", 1);
		add_attribute(v, (yyvsp[(2) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (4)].ptr), "", 1);
		add_attribute(v, (yyvsp[(4) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ArrCreationExpr3", v);
	;}
    break;

  case 285:
#line 3718 "parser.y"
    {
		vector<treeNode> v;
		add_attribute(v, create_AST_leaf((yyvsp[(1) - (3)].str), ""), "", 1);
		add_attribute(v, (yyvsp[(2) - (3)].ptr), "", 1);
		add_attribute(v, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("ArrCreationExpr4", v);
	;}
    break;

  case 286:
#line 3728 "parser.y"
    { 
			vector<treeNode> attr;
			add_attribute(attr, (yyvsp[(1) - (2)].ptr), "", 1);
			add_attribute(attr, (yyvsp[(2) - (2)].ptr), "", 1);
			(yyval.ptr) = create_AST_node("dim_exprs",attr);
			(yyval.ptr)->dims= (yyvsp[(1) - (2)].ptr)->dims;	
			(yyval.ptr)->dims.push_back((yyvsp[(2) - (2)].ptr)->int_val);
			// cout<<"INTVAL "<<$2->int_val;
		;}
    break;

  case 287:
#line 3737 "parser.y"
    {	(yyval.ptr) = (yyvsp[(1) - (1)].ptr);
								vector<int> temp;
								temp.push_back((yyvsp[(1) - (1)].ptr)->int_val);
								cout<<"INTVAL "<<(yyvsp[(1) - (1)].ptr)->int_val;
							 	(yyval.ptr)->dims= temp;
							 ;}
    break;

  case 288:
#line 3746 "parser.y"
    {(yyval.ptr)= (yyvsp[(2) - (3)].ptr);;}
    break;

  case 289:
#line 3749 "parser.y"
    {(yyval.ptr) = create_AST_leaf("[ ]", "EMPTY_EXP") ;;}
    break;

  case 290:
#line 3750 "parser.y"
    { 
			vector<treeNode> attr;
			add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
			add_attribute(attr, create_AST_leaf("[ ]", "EMPTY_EXP"), "", 1);
			(yyval.ptr) = create_AST_node("dims",attr);
		;}
    break;

  case 291:
#line 3758 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr); 	;}
    break;

  case 292:
#line 3761 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 293:
#line 3762 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 294:
#line 3765 "parser.y"
    {if_found = 0;;}
    break;

  case 295:
#line 3765 "parser.y"
    {
							vector<treeNode> attr;
							add_attribute(attr, (yyvsp[(1) - (4)].ptr), "", 1);
							add_attribute(attr, (yyvsp[(4) - (4)].ptr), "", 1);
							(yyval.ptr) = create_AST_node((yyvsp[(2) - (4)].str),attr);
							// cout<<"Assign Expression "<<$1->temp_name<<" "<<$1->type<<" "<<string($2)<<" "<<$4->temp_name<<" "<<$4->type<<"\n";

							//Semantics
		string temp = asgnExpr((yyvsp[(1) - (4)].ptr)->type,(yyvsp[(4) - (4)].ptr)->type,string((yyvsp[(2) - (4)].str)));

		if(!(yyvsp[(1) - (4)].ptr)->is_error && !(yyvsp[(4) - (4)].ptr)->is_error && (yyvsp[(1) - (4)].ptr)->expType!=4){
			if(!temp.empty()){
				if(temp =="ok"){
					(yyval.ptr)->type = (yyvsp[(1) - (4)].ptr)->type;
				}
				else if(temp == "warning"){
				(yyval.ptr)->type = (yyvsp[(1) - (4)].ptr)->type;
				yyerror("Assignment with incompatible pointer types: maybe passed lesser dimensions to array");
			} 
				if((yyvsp[(1) - (4)].ptr)->expType == 3 && (yyvsp[(4) - (4)].ptr)->isInit){
					UpdateInit((yyvsp[(1) - (4)].ptr)->temp_name);
				}
				// cout<<"Type of first arg "<<$1->type<<"\n";
				// 3ac 
				int num;
				// if($1->place.first.substr(0,5)=="CLASS")
				// {
				// 	emit(qid("",NULL),qid("",NULL),qid("",NULL),qid("",NULL),-1);
				// } 
				
				// else  
				// {
					num = assign_exp((yyvsp[(2) - (4)].str), (yyval.ptr)->type, (yyvsp[(1) - (4)].ptr)->type, (yyvsp[(4) - (4)].ptr)->type, (yyvsp[(1) - (4)].ptr)->place, (yyvsp[(4) - (4)].ptr)->place);
				// }
				(yyval.ptr)->place = (yyvsp[(1) - (4)].ptr)->place;
				backpatch((yyvsp[(4) - (4)].ptr)->nextlist, num);
			}
			else{
				yyerror(("Incompatible types when assigning " + (yyvsp[(4) - (4)].ptr)->type + " type to " + (yyvsp[(1) - (4)].ptr)->type).c_str());
				(yyval.ptr)->is_error = 1;
			}
		}
		else{
			if((yyvsp[(1) - (4)].ptr)->expType==4){
				yyerror("Left operand in assignment operation cannot be a constant expression");
			}
			(yyval.ptr)->is_error = 1;
		}
						;}
    break;

  case 296:
#line 3816 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 297:
#line 3817 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 298:
#line 3818 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 299:
#line 3821 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); ;}
    break;

  case 300:
#line 3822 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); ;}
    break;

  case 301:
#line 3823 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); ;}
    break;

  case 302:
#line 3824 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); ;}
    break;

  case 303:
#line 3825 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); ;}
    break;

  case 304:
#line 3826 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); ;}
    break;

  case 305:
#line 3827 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); ;}
    break;

  case 306:
#line 3828 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); ;}
    break;

  case 307:
#line 3829 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); ;}
    break;

  case 308:
#line 3830 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); ;}
    break;

  case 309:
#line 3831 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); ;}
    break;

  case 310:
#line 3832 "parser.y"
    { (yyval.str) = (yyvsp[(1) - (1)].str); ;}
    break;

  case 311:
#line 3835 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 312:
#line 3836 "parser.y"
    {
											vector<treeNode> attr;
											add_attribute(attr, (yyvsp[(1) - (7)].ptr), "", 1);
											add_attribute(attr, (yyvsp[(3) - (7)].ptr), "", 1);
											add_attribute(attr, (yyvsp[(7) - (7)].ptr), "", 1);
											(yyval.ptr) = create_AST_node("ternary operator",attr);
										    // Semantics
											// string temp = condExp($3->type, $5->type);
											//if (!temp.empty()){
												//$ $->type = "int";
											//}
// 											//else {
												 //yyerror("Type mismatch in Conditional Expression");
											// }
// 											if// ($1->isInit==1 && $3->isInit==1 && $5->isInit==1) $$->isInit=1;
	
											string temp = condExp((yyvsp[(3) - (7)].ptr)->type, (yyvsp[(7) - (7)].ptr)->type);

											if(!(yyvsp[(1) - (7)].ptr)->is_error && !(yyvsp[(3) - (7)].ptr)->is_error && !(yyvsp[(7) - (7)].ptr)->is_error){
												if(!temp.empty()){

													if_found = previous_if_found;
													(yyval.ptr)->type = string("int");
													if((yyvsp[(1) - (7)].ptr)->int_val) (yyval.ptr)->int_val = (yyvsp[(3) - (7)].ptr)->int_val;
													else (yyval.ptr)->int_val = (yyvsp[(7) - (7)].ptr)->int_val;
													if((yyvsp[(1) - (7)].ptr)->isInit==1 && (yyvsp[(3) - (7)].ptr)->isInit==1 && (yyvsp[(7) - (7)].ptr)->isInit==1) (yyval.ptr)->isInit=1;

													// 3AC
													qid temp1 = newtemp((yyval.ptr)->type);

													backpatch((yyvsp[(1) - (7)].ptr)->truelist, (yyvsp[(2) - (7)].number));
													backpatch((yyvsp[(1) - (7)].ptr)->falselist, (yyvsp[(6) - (7)].number));
													backpatch((yyvsp[(3) - (7)].ptr)->nextlist, (yyvsp[(4) - (7)].number)-1);
													backpatch((yyvsp[(3) - (7)].ptr)->truelist, (yyvsp[(4) - (7)].number)-1);
													backpatch((yyvsp[(3) - (7)].ptr)->falselist, (yyvsp[(4) - (7)].number)-1);

													code[(yyvsp[(4) - (7)].number)-1].arg1 = (yyvsp[(3) - (7)].ptr)->place;
													code[(yyvsp[(4) - (7)].number)-1].res = temp1;

													backpatch((yyvsp[(7) - (7)].ptr)->nextlist, code.size());
													backpatch((yyvsp[(7) - (7)].ptr)->falselist, code.size());
													backpatch((yyvsp[(7) - (7)].ptr)->truelist, code.size());

													emit(qid("=", NULL), (yyvsp[(7) - (7)].ptr)->place, qid("", NULL), temp1, -1);
													(yyval.ptr)->nextlist.push_back((yyvsp[(4) - (7)].number));
													(yyval.ptr)->place = temp1;
												}
												else {
													yyerror("type mismatch in conditional expression");
													(yyval.ptr)->is_error = 1;
												}
											}									
										;}
    break;

  case 313:
#line 3892 "parser.y"
    {
		previous_if_found = if_found;
		if_found = 0;
		(yyval.ptr) = (yyvsp[(1) - (2)].ptr);
		if(!(yyvsp[(1) - (2)].ptr)->is_error){
			if((yyvsp[(1) - (2)].ptr)->truelist.empty()){
				backpatch((yyvsp[(1) - (2)].ptr)->nextlist, code.size());
				emit(qid("GOTO", NULL), qid("IF", Lookup("if")), (yyvsp[(1) - (2)].ptr)->place, qid("", NULL), 0);
				(yyvsp[(1) - (2)].ptr)->truelist.push_back(code.size()-1);
				emit(qid("GOTO", NULL), qid("", NULL), qid("", NULL), qid("", NULL), 0);
				(yyvsp[(1) - (2)].ptr)->falselist.push_back(code.size()-1);
			}
		}
		else (yyval.ptr)->is_error = 1;
	;}
    break;

  case 314:
#line 3910 "parser.y"
    {
		emit(qid("=", NULL), qid("", NULL), qid("", NULL), qid("", NULL), -1);
		emit(qid("GOTO", NULL), qid("", NULL), qid("", NULL), qid("", NULL), 0);
		(yyval.number) = code.size()-1;
	;}
    break;

  case 315:
#line 3917 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 316:
#line 3918 "parser.y"
    {
		vector<treeNode> attr;
		add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("||" ,attr);

		// Semantics

		if(!(yyvsp[(1) - (3)].ptr)->is_error && !(yyvsp[(3) - (3)].ptr)->is_error){
			(yyval.ptr)->type = string("int");
			(yyval.ptr)->isInit = (((yyvsp[(1) - (3)].ptr)->isInit) & ((yyvsp[(3) - (3)].ptr)->isInit));   
			(yyval.ptr)->int_val = (yyvsp[(1) - (3)].ptr)->int_val || (yyvsp[(3) - (3)].ptr)->int_val;

			// 3AC
			if((yyvsp[(3) - (3)].ptr)->truelist.empty() && if_found){
				// cout<<"If found "<<if_found<<"\n";

				backpatch((yyvsp[(3) - (3)].ptr)->nextlist, code.size());
				emit(qid("GOTO", NULL), qid("IF", Lookup("if")), (yyvsp[(3) - (3)].ptr)->place, qid("", NULL), 0);
				(yyvsp[(3) - (3)].ptr)->truelist.push_back(code.size()-1);
				emit(qid("GOTO", NULL), qid("", NULL), qid("", NULL), qid("", NULL), 0);
				(yyvsp[(3) - (3)].ptr)->falselist.push_back(code.size()-1);
			}
			else {
				qid tmp = newtemp((yyval.ptr)->type);
				// cout<<"If found kdhe "<<if_found<<"\n";
				emit(qid("||", NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, tmp, -1);
				(yyval.ptr)->place = tmp;
			}
			backpatch((yyvsp[(1) - (3)].ptr)->falselist, (yyvsp[(2) - (3)].number));
			(yyval.ptr)->truelist = (yyvsp[(1) - (3)].ptr)->truelist;
			(yyval.ptr)->truelist.insert((yyval.ptr)->truelist.end(), (yyvsp[(3) - (3)].ptr)->truelist.begin(), (yyvsp[(3) - (3)].ptr)->truelist.end());
			(yyval.ptr)->falselist = (yyvsp[(3) - (3)].ptr)->falselist;
		}
		else{
			(yyval.ptr)->is_error = 1;
		}
	;}
    break;

  case 317:
#line 3959 "parser.y"
    {
		(yyval.ptr) = (yyvsp[(1) - (2)].ptr);
		if(!(yyvsp[(1) - (2)].ptr)->is_error){
			if((yyvsp[(1) - (2)].ptr)->truelist.empty() && if_found){
				backpatch((yyvsp[(1) - (2)].ptr)->nextlist, code.size());
				emit(qid("GOTO", NULL), qid("IF", Lookup("if")), (yyvsp[(1) - (2)].ptr)->place, qid("", NULL), 0);
				(yyvsp[(1) - (2)].ptr)->truelist.push_back(code.size()-1);
				emit(qid("GOTO", NULL), qid("", NULL), qid("", NULL), qid("", NULL), 0);
				(yyvsp[(1) - (2)].ptr)->falselist.push_back(code.size()-1);
			}
		}
		else (yyval.ptr)->is_error = 1;
		
	;}
    break;

  case 318:
#line 3975 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 319:
#line 3976 "parser.y"
    {
		vector<treeNode> attr;
		add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("&&" ,attr);
		// cout<<"In and rule \n";
		// Semantics
		if(!(yyvsp[(1) - (3)].ptr)->is_error && !(yyvsp[(3) - (3)].ptr)->is_error){
			(yyval.ptr)->type = string("int");
			(yyval.ptr)->isInit = (((yyvsp[(1) - (3)].ptr)->isInit) & ((yyvsp[(3) - (3)].ptr)->isInit));   
			(yyval.ptr)->int_val = (yyvsp[(1) - (3)].ptr)->int_val && (yyvsp[(3) - (3)].ptr)->int_val;

			// 3AC
			if((yyvsp[(3) - (3)].ptr)->truelist.empty() && if_found){
				// cout<<"If found "<<if_found<<"\n";
				backpatch((yyvsp[(3) - (3)].ptr)->nextlist, code.size());
				// cout<<"In and rule1 \n";
				emit(qid("GOTO", NULL), qid("IF", Lookup("if")), (yyvsp[(3) - (3)].ptr)->place, qid("", NULL), 0);
				(yyvsp[(3) - (3)].ptr)->truelist.push_back(code.size()-1);
				emit(qid("GOTO", NULL), qid("", NULL), qid("", NULL), qid("", NULL), 0);
				(yyvsp[(3) - (3)].ptr)->falselist.push_back(code.size()-1);
			}
			else {
				qid tmp = newtemp((yyval.ptr)->type);
				// cout<<"In and rule2 \n";
				emit(qid("&&", NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, tmp, -1);
				(yyval.ptr)->place = tmp;
			}
			backpatch((yyvsp[(1) - (3)].ptr)->truelist, (yyvsp[(2) - (3)].number));
			(yyval.ptr)->truelist = (yyvsp[(3) - (3)].ptr)->truelist;
			(yyval.ptr)->falselist = (yyvsp[(1) - (3)].ptr)->falselist;
			(yyval.ptr)->falselist.insert((yyval.ptr)->falselist.end(), (yyvsp[(3) - (3)].ptr)->falselist.begin(), (yyvsp[(3) - (3)].ptr)->falselist.end());
		}
		else{
			(yyval.ptr)->is_error = 1;
		}

	;}
    break;

  case 320:
#line 4017 "parser.y"
    {
		(yyval.ptr) = (yyvsp[(1) - (2)].ptr);
		
		if(!(yyvsp[(1) - (2)].ptr)->is_error){
			if((yyvsp[(1) - (2)].ptr)->truelist.empty() && if_found){
				backpatch((yyvsp[(1) - (2)].ptr)->nextlist, code.size());
				emit(qid("GOTO", NULL), qid("IF", Lookup("if")), (yyvsp[(1) - (2)].ptr)->place, qid("", NULL), 0);
				(yyvsp[(1) - (2)].ptr)->truelist.push_back(code.size()-1);
				emit(qid("GOTO", NULL), qid("", NULL), qid("", NULL), qid("", NULL), 0);
				(yyvsp[(1) - (2)].ptr)->falselist.push_back(code.size()-1);
			}
		}
		else (yyval.ptr)->is_error = 1;
	;}
    break;

  case 321:
#line 4034 "parser.y"
    {
		(yyval.number) = code.size();
	;}
    break;

  case 322:
#line 4039 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 323:
#line 4040 "parser.y"
    {
																	vector<treeNode> attr;
																	add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
																	add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
																	(yyval.ptr) = create_AST_node((yyvsp[(2) - (3)].str) ,attr);
																	//Semantics
																// if($1->isInit ==1 && $3->isInit ==1) $$->isInit = 1;
																
															
																	// if(!temp.empty()){
																	// 	if(temp =="ok"){
																	// 		$$->type = "bool";
																	// 	}
																	// 	else $$->type = "long long";
																		
																	// }
																	// else{
																	// 	yyerror("Invalid operands to binary |");
																	// }
																	if((yyvsp[(1) - (3)].ptr)->isInit ==1 && (yyvsp[(3) - (3)].ptr)->isInit ==1) (yyval.ptr)->isInit = 1;
																	// else if($1->isInit == 0){
																	// 	yyerror(($1->name + " is not initialized\n").c_str());
																	// 	$$->is_error = 1;
																	// }
																	// else {
																	// 	yyerror(($3->name + " is not initialized\n").c_str());
																	// 	$$->is_error = 1;
																	// }
																	string temp = bitExpr((yyvsp[(1) - (3)].ptr)->type,(yyvsp[(3) - (3)].ptr)->type);

																	if(!(yyvsp[(1) - (3)].ptr)->is_error && !(yyvsp[(3) - (3)].ptr)->is_error){
																		if(!temp.empty()){
																			if(temp =="ok"){
																				(yyval.ptr)->type = "bool";
																			}
																			else (yyval.ptr)->type = "long long";
																			
																			(yyval.ptr)->int_val = (yyvsp[(1) - (3)].ptr)->int_val | (yyvsp[(3) - (3)].ptr)->int_val;

																			// 3AC
																			if((yyvsp[(1) - (3)].ptr)->expType == 4 && (yyvsp[(3) - (3)].ptr)->expType == 4){
																				(yyval.ptr)->place = qid(to_string((yyval.ptr)->int_val), (yyvsp[(1) - (3)].ptr)->place.second);
																				(yyval.ptr)->expType = 4;
																			}
																			else{
																				qid temp1 = newtemp((yyval.ptr)->type);
																				emit(qid("|", NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, temp1, -1);
																				(yyval.ptr)->place = temp1;
																			}
																			(yyval.ptr)->nextlist.clear();
																		}
																		else{
																			yyerror(("Invalid operands of types \'" + (yyvsp[(1) - (3)].ptr)->type + "\' and \'" + (yyvsp[(3) - (3)].ptr)->type + "\' to binary |").c_str());
																			(yyval.ptr)->is_error = 1;
																		}
																	}
																	else{
																		(yyval.ptr)->is_error = 1;
																	}
																;}
    break;

  case 324:
#line 4102 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 325:
#line 4103 "parser.y"
    {
															vector<treeNode> attr;
															add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
															add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
															(yyval.ptr) = create_AST_node((yyvsp[(2) - (3)].str) ,attr);

															//Semantics
														     
															if((yyvsp[(1) - (3)].ptr)->isInit ==1 && (yyvsp[(3) - (3)].ptr)->isInit ==1) (yyval.ptr)->isInit = 1;
															
															string temp = bitExpr((yyvsp[(1) - (3)].ptr)->type,(yyvsp[(3) - (3)].ptr)->type);

															if(!(yyvsp[(1) - (3)].ptr)->is_error && !(yyvsp[(3) - (3)].ptr)->is_error){
																if(!temp.empty()){
																	if(temp =="ok"){
																		(yyval.ptr)->type = "bool";
																	}
																	else (yyval.ptr)->type = "long long";

																	(yyval.ptr)->int_val = (yyvsp[(1) - (3)].ptr)->int_val ^ (yyvsp[(3) - (3)].ptr)->int_val;

																	// 3AC
																	if((yyvsp[(1) - (3)].ptr)->expType == 4 && (yyvsp[(3) - (3)].ptr)->expType == 4){
																		(yyval.ptr)->place = qid(to_string((yyval.ptr)->int_val), (yyvsp[(1) - (3)].ptr)->place.second);
																		(yyval.ptr)->expType = 4;
																	}
																	else{
																		qid temp1 = newtemp((yyval.ptr)->type);
																		emit(qid("^", NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, temp1, -1);
																		(yyval.ptr)->place = temp1; 
																	}
																	(yyval.ptr)->nextlist.clear();
																}
																else{
																	yyerror(("Invalid operands of types \'" + (yyvsp[(1) - (3)].ptr)->type + "\' and \'" + (yyvsp[(3) - (3)].ptr)->type + "\' to binary ^").c_str());
																	(yyval.ptr)->is_error = 1;
																}
															}
															else{
																(yyval.ptr)->is_error = 1;
															}
														;}
    break;

  case 326:
#line 4147 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 327:
#line 4148 "parser.y"
    {
												vector<treeNode> attr;
												add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
												add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
												(yyval.ptr) = create_AST_node((yyvsp[(2) - (3)].str) ,attr);
												//Semantics
											
												if((yyvsp[(1) - (3)].ptr)->isInit ==1 && (yyvsp[(3) - (3)].ptr)->isInit ==1) (yyval.ptr)->isInit = 1;
											
												string temp = bitExpr((yyvsp[(1) - (3)].ptr)->type,(yyvsp[(3) - (3)].ptr)->type);

												if(!(yyvsp[(1) - (3)].ptr)->is_error && !(yyvsp[(3) - (3)].ptr)->is_error){
													if(!temp.empty()){
														if(temp =="ok"){
															(yyval.ptr)->type = "bool";
														}
														else (yyval.ptr)->type = "long long";
														
														(yyval.ptr)->int_val = (yyvsp[(1) - (3)].ptr)->int_val & (yyvsp[(3) - (3)].ptr)->int_val;

														// 3AC
														if((yyvsp[(1) - (3)].ptr)->expType == 4 && (yyvsp[(3) - (3)].ptr)->expType == 4){
															(yyval.ptr)->place = qid(to_string((yyval.ptr)->int_val), (yyvsp[(1) - (3)].ptr)->place.second);
															(yyval.ptr)->expType = 4;
														}
														else{
															qid temp1 = newtemp((yyval.ptr)->type);
															emit(qid("&", NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, temp1, -1);
															(yyval.ptr)->place = temp1;
														}
														(yyval.ptr)->nextlist.clear();
													}
													else{
														yyerror(("Invalid operands of types \'" + (yyvsp[(1) - (3)].ptr)->type + "\' and \'" + (yyvsp[(3) - (3)].ptr)->type + "\' to binary &").c_str());
														(yyval.ptr)->is_error = 1;
													}
												}
												else{
													(yyval.ptr)->is_error = 1;
												}
											;}
    break;

  case 328:
#line 4191 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 329:
#line 4192 "parser.y"
    {
												vector<treeNode> attr;
												add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
												add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
												(yyval.ptr) = create_AST_node((yyvsp[(2) - (3)].str) ,attr);
												//Semantics
												
												if((yyvsp[(1) - (3)].ptr)->isInit ==1 && (yyvsp[(3) - (3)].ptr)->isInit ==1) (yyval.ptr)->isInit = 1;
												// else if($1->isInit == 0){
												
												string temp = eqlExpr((yyvsp[(1) - (3)].ptr)->type,(yyvsp[(3) - (3)].ptr)->type);

												if(!(yyvsp[(1) - (3)].ptr)->is_error && !(yyvsp[(3) - (3)].ptr)->is_error){
													if(!temp.empty()){
														if(temp =="ok"){
															warning("Comparison between pointer and integer");
														}
														(yyval.ptr)->type = "bool";

														if((yyvsp[(1) - (3)].ptr)->int_val == (yyvsp[(3) - (3)].ptr)->int_val) (yyval.ptr)->int_val = 1;
														else (yyval.ptr)->int_val = 0;

														// 3AC
														if((yyvsp[(1) - (3)].ptr)->expType == 4 && (yyvsp[(3) - (3)].ptr)->expType == 4){
															(yyval.ptr)->place = qid(to_string((yyval.ptr)->int_val), (yyvsp[(1) - (3)].ptr)->place.second);
															(yyval.ptr)->expType = 4;
														}
														else{
															qid temp1 = newtemp((yyval.ptr)->type);
															emit(qid("==", NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, temp1, -1);
															(yyval.ptr)->place = temp1;
														}
														(yyval.ptr)->nextlist.clear();
													}
													else{
														yyerror(("Invalid operands of types \'" + (yyvsp[(1) - (3)].ptr)->type + "\' and \'" + (yyvsp[(3) - (3)].ptr)->type + "\' to binary ==").c_str());
														(yyval.ptr)->is_error = 1;
													}
												}
												else{
													(yyval.ptr)->is_error = 1;
												}
											;}
    break;

  case 330:
#line 4235 "parser.y"
    {
													vector<treeNode> attr;
													add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
													add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
													(yyval.ptr) = create_AST_node((yyvsp[(2) - (3)].str) ,attr);
													//Semantics
											
													if((yyvsp[(1) - (3)].ptr)->isInit ==1 && (yyvsp[(3) - (3)].ptr)->isInit ==1) (yyval.ptr)->isInit = 1;
												
													string temp = eqlExpr((yyvsp[(1) - (3)].ptr)->type,(yyvsp[(3) - (3)].ptr)->type);

													if(!(yyvsp[(1) - (3)].ptr)->is_error && !(yyvsp[(3) - (3)].ptr)->is_error){
														if(!temp.empty()){
															if(temp =="ok"){
																//warning("Comparison between pointer and integer");
															}
															(yyval.ptr)->type = "int";

															if((yyvsp[(1) - (3)].ptr)->int_val != (yyvsp[(3) - (3)].ptr)->int_val) (yyval.ptr)->int_val = 1;
															else (yyval.ptr)->int_val = 0;

															// 3AC
															if((yyvsp[(1) - (3)].ptr)->expType == 4 && (yyvsp[(3) - (3)].ptr)->expType == 4){
																(yyval.ptr)->place = qid(to_string((yyval.ptr)->int_val), (yyvsp[(1) - (3)].ptr)->place.second);
																(yyval.ptr)->expType = 4;
															}
															else{
																qid temp1 = newtemp((yyval.ptr)->type);
																emit(qid("!=", NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, temp1, -1);
																(yyval.ptr)->place = temp1; 
															}
															(yyval.ptr)->nextlist.clear();
														}
														else{
															yyerror(("Invalid operands of types \'" + (yyvsp[(1) - (3)].ptr)->type + "\' and \'" + (yyvsp[(3) - (3)].ptr)->type + "\' to binary !=").c_str());
															(yyval.ptr)->is_error = 1;
														}
													}
													else{
														(yyval.ptr)->is_error = 1;
													}
												;}
    break;

  case 331:
#line 4279 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr); ;}
    break;

  case 332:
#line 4280 "parser.y"
    {
																		vector<treeNode> attr;
																		add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
																		add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
																		(yyval.ptr) = create_AST_node((yyvsp[(2) - (3)].str) ,attr);

																		//Semantic
																if((yyvsp[(1) - (3)].ptr)->isInit ==1 && (yyvsp[(3) - (3)].ptr)->isInit ==1) (yyval.ptr)->isInit = 1;
															
																		string temp = relExpr((yyvsp[(1) - (3)].ptr)->type,(yyvsp[(3) - (3)].ptr)->type);

																		if(!(yyvsp[(1) - (3)].ptr)->is_error && !(yyvsp[(3) - (3)].ptr)->is_error){
																			if(!temp.empty()){
																				if(temp == "bool"){
																					(yyval.ptr)->type = "bool";
																				}
																				else if(temp == "Bool"){
																					(yyval.ptr)->type = "bool";
																					//warning("Comparison between pointer and integer");
																				}
																				if((yyvsp[(1) - (3)].ptr)->int_val >= (yyvsp[(3) - (3)].ptr)->int_val) (yyval.ptr)->int_val = 1;
																				else (yyval.ptr)->int_val = 0;

																				// 3AC
																				if((yyvsp[(1) - (3)].ptr)->expType == 4 && (yyvsp[(3) - (3)].ptr)->expType == 4){
																					(yyval.ptr)->place = qid(to_string((yyval.ptr)->int_val), (yyvsp[(1) - (3)].ptr)->place.second);
																					(yyval.ptr)->expType = 4;
																				}
																				else{
																					qid temp1 = newtemp((yyval.ptr)->type);
																					emit(qid(">=", NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, temp1, -1);
																					(yyval.ptr)->place = temp1;
																				}
																				(yyval.ptr)->nextlist.clear();
																				
																			}
																			else{
																				yyerror(("Invalid operands of types \'" + (yyvsp[(1) - (3)].ptr)->type + "\' and \'" + (yyvsp[(3) - (3)].ptr)->type + "\' to binary >=").c_str());
																				(yyval.ptr)->is_error = 1;
																			}
																		}
																		else{
																			(yyval.ptr)->is_error = 1;
																		}
																	;}
    break;

  case 333:
#line 4325 "parser.y"
    {
		vector<treeNode> attr;
		add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
		add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
		(yyval.ptr) = create_AST_node((yyvsp[(2) - (3)].str) ,attr);
	;}
    break;

  case 334:
#line 4331 "parser.y"
    {
														vector<treeNode> attr;
														add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
														add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
														(yyval.ptr) = create_AST_node((yyvsp[(2) - (3)].str) ,attr);
														//Semantic
												        
														if((yyvsp[(1) - (3)].ptr)->isInit ==1 && (yyvsp[(3) - (3)].ptr)->isInit ==1) (yyval.ptr)->isInit = 1;
														
														string temp = relExpr((yyvsp[(1) - (3)].ptr)->type,(yyvsp[(3) - (3)].ptr)->type);

														if(!(yyvsp[(1) - (3)].ptr)->is_error && !(yyvsp[(3) - (3)].ptr)->is_error){
															if(!temp.empty()){
																if(temp == "bool"){
																	(yyval.ptr)->type = "bool";
																}
																else if(temp == "Bool"){
																	(yyval.ptr)->type = "bool";
																	warning("Comparison between pointer and integer");
																}

																if((yyvsp[(1) - (3)].ptr)->int_val < (yyvsp[(3) - (3)].ptr)->int_val) (yyval.ptr)->int_val = 1;
																else (yyval.ptr)->int_val = 0;

																// 3AC
																if((yyvsp[(1) - (3)].ptr)->expType == 4 && (yyvsp[(3) - (3)].ptr)->expType == 4){
																	(yyval.ptr)->place = qid(to_string((yyval.ptr)->int_val), (yyvsp[(1) - (3)].ptr)->place.second);
																	(yyval.ptr)->expType = 4;
																}
																else{
																	qid temp1 = newtemp((yyval.ptr)->type);
																	emit(qid("<", NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, temp1, -1);
																	(yyval.ptr)->place = temp1; 
																}
																(yyval.ptr)->nextlist.clear();
																
															}
															else{
																yyerror(("Invalid operands of types \'" + (yyvsp[(1) - (3)].ptr)->type + "\' and \'" + (yyvsp[(3) - (3)].ptr)->type + "\' to binary <").c_str());
																(yyval.ptr)->is_error = 1;
															}
														}
														else{
															(yyval.ptr)->is_error = 1;
														}
													;}
    break;

  case 335:
#line 4377 "parser.y"
    {
														vector<treeNode> attr;
														add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
														add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
														(yyval.ptr) = create_AST_node((yyvsp[(2) - (3)].str) ,attr);
														

														//Semantic
														
														if((yyvsp[(1) - (3)].ptr)->isInit ==1 && (yyvsp[(3) - (3)].ptr)->isInit ==1) (yyval.ptr)->isInit = 1;
														// else if($1->isInit == 0){
														// 	yyerror(($1->name + " is not initialized\n").c_str());
														// 	$$->is_error = 1;
														// }
														// else {
														// 	yyerror(($3->name + " is not initialized\n").c_str());
														// 	$$->is_error = 1;
														// }
														string temp = relExpr((yyvsp[(1) - (3)].ptr)->type,(yyvsp[(3) - (3)].ptr)->type);

														if(!(yyvsp[(1) - (3)].ptr)->is_error && !(yyvsp[(3) - (3)].ptr)->is_error){
															if(!temp.empty()){
																if(temp == "bool"){
																	(yyval.ptr)->type = "bool";
																}
																else if(temp == "Bool"){
																	(yyval.ptr)->type = "bool";
																	warning("Comparison between pointer and integer");
																}

																if((yyvsp[(1) - (3)].ptr)->int_val > (yyvsp[(3) - (3)].ptr)->int_val) (yyval.ptr)->int_val = 1;
																else (yyval.ptr)->int_val = 0;
																// 3AC
																if((yyvsp[(1) - (3)].ptr)->expType == 4 && (yyvsp[(3) - (3)].ptr)->expType == 4){
																	(yyval.ptr)->place = qid(to_string((yyval.ptr)->int_val), (yyvsp[(1) - (3)].ptr)->place.second);
																	(yyval.ptr)->expType = 4;
																}
																else{
																	qid temp1 = newtemp((yyval.ptr)->type);
																	emit(qid(">", NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, temp1, -1);
																	(yyval.ptr)->place = temp1; 
																}
																(yyval.ptr)->nextlist.clear();
															}
															else{
																yyerror(("Invalid operands of types \'" + (yyvsp[(1) - (3)].ptr)->type + "\' and \'" + (yyvsp[(3) - (3)].ptr)->type + "\' to binary >").c_str());
																(yyval.ptr)->is_error = 1;
															}
														}
														else{
															(yyval.ptr)->is_error = 1;
														}
													;}
    break;

  case 336:
#line 4430 "parser.y"
    {
													vector<treeNode> attr;
													add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
													add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
													(yyval.ptr) = create_AST_node((yyvsp[(2) - (3)].str) ,attr);
													//Semantic
												
												
													if((yyvsp[(1) - (3)].ptr)->isInit ==1 && (yyvsp[(3) - (3)].ptr)->isInit ==1) (yyval.ptr)->isInit = 1;
													
													string temp = relExpr((yyvsp[(1) - (3)].ptr)->type,(yyvsp[(3) - (3)].ptr)->type);

													if(!(yyvsp[(1) - (3)].ptr)->is_error && !(yyvsp[(3) - (3)].ptr)->is_error){
														if(!temp.empty()){
															if(temp == "bool"){
																(yyval.ptr)->type = "int";
															}
															else if(temp == "Bool"){
																(yyval.ptr)->type = "int";
																//warning("Comparison between pointer and integer");
															}
															if((yyvsp[(1) - (3)].ptr)->int_val <= (yyvsp[(3) - (3)].ptr)->int_val) (yyval.ptr)->int_val = 1;
															else (yyval.ptr)->int_val = 0;

															// 3AC
															if((yyvsp[(1) - (3)].ptr)->expType == 4 && (yyvsp[(3) - (3)].ptr)->expType == 4){
																(yyval.ptr)->place = qid(to_string((yyval.ptr)->int_val), (yyvsp[(1) - (3)].ptr)->place.second);
																(yyval.ptr)->expType = 4;
															}
															else{
																qid temp1 = newtemp((yyval.ptr)->type);
																emit(qid("<=", NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, temp1, -1);
																(yyval.ptr)->place = temp1; 
															}
															(yyval.ptr)->nextlist.clear();
														}
														else{
															yyerror(("Invalid operands of types \'" + (yyvsp[(1) - (3)].ptr)->type + "\' and \'" + (yyvsp[(3) - (3)].ptr)->type + "\' to binary <=").c_str());
															(yyval.ptr)->is_error = 1;
														}
													}
													else{
														(yyval.ptr)->is_error = 1;
													}
												;}
    break;

  case 337:
#line 4478 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 338:
#line 4479 "parser.y"
    {
												vector<treeNode> attr;
												add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
												add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
												(yyval.ptr) = create_AST_node((yyvsp[(2) - (3)].str) ,attr);
												//Semantic
												if(!(yyvsp[(1) - (3)].ptr)->is_error && !(yyvsp[(3) - (3)].ptr)->is_error){
												
																if((yyvsp[(1) - (3)].ptr)->isInit ==1 && (yyvsp[(3) - (3)].ptr)->isInit ==1) (yyval.ptr)->isInit = 1;
																// else if($1->isInit == 0){
																// 	yyerror(($1->name + " is not initialized\n").c_str());
																// 	$$->is_error = 1;
																// }
																// else {
																// 	yyerror(($3->name + " is not initialized\n").c_str());
																// 	$$->is_error = 1;
																// }
													string temp = shiftExpr((yyvsp[(1) - (3)].ptr)->type,(yyvsp[(3) - (3)].ptr)->type);
													if(!temp.empty()){
														(yyval.ptr)->type = (yyvsp[(1) - (3)].ptr)->type;
														(yyval.ptr)->int_val = (yyvsp[(1) - (3)].ptr)->int_val << (yyvsp[(3) - (3)].ptr)->int_val;
														(yyval.ptr)->temp_name = (yyvsp[(1) - (3)].ptr)->temp_name + " << " + (yyvsp[(3) - (3)].ptr)->temp_name;

														// 3AC
														if((yyvsp[(1) - (3)].ptr)->expType == 4 && (yyvsp[(3) - (3)].ptr)->expType == 4){
															(yyval.ptr)->place = qid(to_string((yyval.ptr)->int_val), (yyvsp[(1) - (3)].ptr)->place.second);
															(yyval.ptr)->expType = 4;
														}
														else{
															qid temp1 = newtemp((yyval.ptr)->type);
															emit(qid("<<", NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, temp1, -1);
															(yyval.ptr)->place = temp1;
														}
														(yyval.ptr)->nextlist.clear();
													}
													else{
														yyerror(("Invalid operands of types \'" + (yyvsp[(1) - (3)].ptr)->type + "\' and \'" + (yyvsp[(3) - (3)].ptr)->type + "\' to binary <<").c_str());
														(yyval.ptr)->is_error = 1;
													}
												}
												else{
													(yyval.ptr)->is_error = 1;
												}
											;}
    break;

  case 339:
#line 4526 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 340:
#line 4527 "parser.y"
    {
											vector<treeNode> attr;
											add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
											add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
											(yyval.ptr) = create_AST_node((yyvsp[(2) - (3)].str) ,attr);
											//Semantic
											
																if((yyvsp[(1) - (3)].ptr)->isInit ==1 && (yyvsp[(3) - (3)].ptr)->isInit ==1) (yyval.ptr)->isInit = 1;
																// else if($1->isInit == 0){
																// 	yyerror(($1->name + " is not initialized\n").c_str());
																// 	$$->is_error = 1;
																// }
																// else {
																// 	yyerror(($3->name + " is not initialized\n").c_str());
																// 	$$->is_error = 1;
																// }
											(yyval.ptr)->int_val = (yyvsp[(1) - (3)].ptr)->int_val + (yyvsp[(3) - (3)].ptr)->int_val;
											string temp = addExpr((yyvsp[(1) - (3)].ptr)->type,(yyvsp[(3) - (3)].ptr)->type,'+');
											
											if(!(yyvsp[(1) - (3)].ptr)->is_error && !(yyvsp[(3) - (3)].ptr)->is_error){
												if(!temp.empty()){
													if(temp == "int")	(yyval.ptr)->type = "int";
													else if(temp == "real")	(yyval.ptr)->type = "float";
													else (yyval.ptr)->type =  temp;

													(yyval.ptr)->int_val = (yyvsp[(1) - (3)].ptr)->int_val + (yyvsp[(3) - (3)].ptr)->int_val;
													(yyval.ptr)->real_val = (yyvsp[(1) - (3)].ptr)->real_val + (yyvsp[(3) - (3)].ptr)->real_val;
													(yyval.ptr)->temp_name = (yyvsp[(1) - (3)].ptr)->temp_name + " + " + (yyvsp[(3) - (3)].ptr)->temp_name;

													// 3AC

													if((yyvsp[(1) - (3)].ptr)->expType == 4 && (yyvsp[(3) - (3)].ptr)->expType == 4){
														(yyval.ptr)->place = qid(to_string((yyval.ptr)->int_val), (yyvsp[(1) - (3)].ptr)->place.second);
														(yyval.ptr)->expType = 4;
													}
													else{
														qid temp1 = newtemp((yyval.ptr)->type);
														int cond1 = (checkIfInteger((yyvsp[(1) - (3)].ptr)->type) && checkIfFloatingPt((yyvsp[(3) - (3)].ptr)->type));
														int cond2 = (checkIfInteger((yyvsp[(3) - (3)].ptr)->type) && checkIfFloatingPt((yyvsp[(1) - (3)].ptr)->type));

														if(cond1){
															qid temp2 = newtemp((yyvsp[(3) - (3)].ptr)->type);
															emit(qid("inttoreal", NULL), (yyvsp[(1) - (3)].ptr)->place, qid("", NULL), temp2, -1);
															emit(qid("+"+temp, NULL), temp2, (yyvsp[(3) - (3)].ptr)->place, temp1, -1);
														}
														else if(cond2){
															qid temp2 = newtemp((yyvsp[(1) - (3)].ptr)->type);
															emit(qid("inttoreal", NULL), (yyvsp[(3) - (3)].ptr)->place, qid("", NULL), temp2, -1);
															emit(qid("+"+temp, NULL), (yyvsp[(1) - (3)].ptr)->place, temp2, temp1, -1);
														}
														else{
															emit(qid("+"+temp, NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, temp1, -1);
														}
														(yyval.ptr)->place = temp1;
													}
													(yyval.ptr)->nextlist.clear();
												}
												else{
													
													yyerror(("Incompatible types \'" + (yyvsp[(1) - (3)].ptr)->type + "\' and \'" + (yyvsp[(3) - (3)].ptr)->type + "\' for + operator").c_str());
													// $$->is_error = 1;
												}
											}
											else{
												(yyval.ptr)->is_error = 1;
											}
										;}
    break;

  case 341:
#line 4594 "parser.y"
    {
													vector<treeNode> attr;
													add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
													add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
													(yyval.ptr) = create_AST_node((yyvsp[(2) - (3)].str) ,attr);
													// //Semantic
																if((yyvsp[(1) - (3)].ptr)->isInit ==1 && (yyvsp[(3) - (3)].ptr)->isInit ==1) (yyval.ptr)->isInit = 1;
																// else if($1->isInit == 0){
																// 	yyerror(($1->name + " is not initialized\n").c_str());
																// 	$$->is_error = 1;
																// }
																// else {
																// 	yyerror(($3->name + " is not initialized\n").c_str());
																// 	$$->is_error = 1;
																// }
                                                    (yyval.ptr)->int_val = (yyvsp[(1) - (3)].ptr)->int_val - (yyvsp[(3) - (3)].ptr)->int_val;
													string temp = addExpr((yyvsp[(1) - (3)].ptr)->type,(yyvsp[(3) - (3)].ptr)->type,'-');
													if(!(yyvsp[(1) - (3)].ptr)->is_error && !(yyvsp[(3) - (3)].ptr)->is_error){
														if(!temp.empty()){
															if(temp == "int")(yyval.ptr)->type = "int";
															else if(temp == "real")(yyval.ptr)->type = "float";
															else (yyval.ptr)->type = temp;

															(yyval.ptr)->int_val = (yyvsp[(1) - (3)].ptr)->int_val - (yyvsp[(3) - (3)].ptr)->int_val;
															(yyval.ptr)->real_val = (yyvsp[(1) - (3)].ptr)->real_val - (yyvsp[(3) - (3)].ptr)->real_val;
															(yyval.ptr)->temp_name = (yyvsp[(1) - (3)].ptr)->temp_name + " - " + (yyvsp[(3) - (3)].ptr)->temp_name;

															// 3AC

															if((yyvsp[(1) - (3)].ptr)->expType == 4 && (yyvsp[(3) - (3)].ptr)->expType == 4){
																(yyval.ptr)->place = qid(to_string((yyval.ptr)->int_val), (yyvsp[(1) - (3)].ptr)->place.second);
																(yyval.ptr)->expType = 4;
															}
															else{
																qid temp1 = newtemp((yyval.ptr)->type);
																int cond1 = (checkIfInteger((yyvsp[(1) - (3)].ptr)->type) && checkIfFloatingPt((yyvsp[(3) - (3)].ptr)->type));
																int cond2 = (checkIfInteger((yyvsp[(3) - (3)].ptr)->type) && checkIfFloatingPt((yyvsp[(1) - (3)].ptr)->type));

																if(cond1){
																	qid temp2 = newtemp((yyvsp[(3) - (3)].ptr)->type);
																	emit(qid("inttoreal", NULL), (yyvsp[(1) - (3)].ptr)->place, qid("", NULL), temp2, -1);
																	emit(qid("-"+temp, NULL), temp2, (yyvsp[(3) - (3)].ptr)->place, temp1, -1);
																}
																else if(cond2){
																	qid temp2 = newtemp((yyvsp[(1) - (3)].ptr)->type);
																	emit(qid("inttoreal", NULL), (yyvsp[(3) - (3)].ptr)->place, qid("", NULL), temp2, -1);
																	emit(qid("-"+temp, NULL), (yyvsp[(1) - (3)].ptr)->place, temp2, temp1, -1);
																}
																else{
																	emit(qid("-"+temp, NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, temp1, -1);
																}
																(yyval.ptr)->place = temp1;
															}
															(yyval.ptr)->nextlist.clear();
															
														}
														else{
															yyerror(("Incompatible types \'" + (yyvsp[(1) - (3)].ptr)->type + "\' and \'" + (yyvsp[(3) - (3)].ptr)->type + "\' for - operator").c_str());
															(yyval.ptr)->is_error = 1;
														}
													}
													else{
														(yyval.ptr)->is_error = 1;
													}
												;}
    break;

  case 342:
#line 4661 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 343:
#line 4662 "parser.y"
    {
															vector<treeNode> attr;
															add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
															add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
															(yyval.ptr) = create_AST_node((yyvsp[(2) - (3)].str) ,attr);

															if(!((yyvsp[(1) - (3)].ptr)->is_error || (yyvsp[(3) - (3)].ptr)->is_error)){
															// 	//Semantic
																(yyval.ptr)->int_val = (yyvsp[(1) - (3)].ptr)->int_val * (yyvsp[(3) - (3)].ptr)->int_val; 

																if((yyvsp[(1) - (3)].ptr)->isInit ==1 && (yyvsp[(3) - (3)].ptr)->isInit ==1) (yyval.ptr)->isInit = 1;
															
																string temp = multExpr((yyvsp[(1) - (3)].ptr)->type, (yyvsp[(3) - (3)].ptr)->type, '*');
		// cout<<"Temp is "<<temp<<"\n";
																if(!temp.empty()){
																	(yyval.ptr)->type = temp;
																	if((yyvsp[(1) - (3)].ptr)->expType == 4 && (yyvsp[(3) - (3)].ptr)->expType == 4){
																		(yyval.ptr)->place = qid(to_string((yyval.ptr)->int_val), (yyvsp[(1) - (3)].ptr)->place.second);
																		(yyval.ptr)->expType = 4;
																	}
																	else{
																		if(temp == "int"){
																			(yyval.ptr)->type = "int" ;

																			//--3AC
																			qid q = newtemp("int");
																			(yyval.ptr)->place = q;
																			(yyval.ptr)->nextlist.clear();
																			emit(qid("*int", NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, q, -1);
																		}
																		else if(temp == "float"){
																			(yyval.ptr)->type = "float";

																			//--3AC

																			qid q = newtemp("float");
																			(yyval.ptr)->place = q;
																			(yyval.ptr)->nextlist.clear();

																			if(checkIfInteger((yyvsp[(1) - (3)].ptr)->type)){
																				qid q1 = newtemp((yyval.ptr)->type);
																				emit(qid("inttoreal", NULL), (yyvsp[(1) - (3)].ptr)->place, qid("", NULL), q1, -1);

																				emit(qid("*real", NULL), q1, (yyvsp[(3) - (3)].ptr)->place, q, -1);
																			}
																			else if(checkIfInteger((yyvsp[(3) - (3)].ptr)->type)){
																				qid q1 = newtemp((yyval.ptr)->type);
																				emit(qid("inttoreal", NULL), (yyvsp[(3) - (3)].ptr)->place, qid("", NULL), q1, -1);
																				emit(qid("*real", NULL), (yyvsp[(1) - (3)].ptr)->place, q1, q, -1);
																			}
																			else{
																				emit(qid("*real", NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, q, -1);
																			}
																		}
																	}
																	(yyval.ptr)->nextlist.clear();
																}
																else{
																	yyerror(("Incompatible types \'" + (yyvsp[(1) - (3)].ptr)->type + "\' and \'" + (yyvsp[(3) - (3)].ptr)->type + "\' for * operator").c_str());
																	(yyval.ptr)->is_error = 1;
																}
															}
															else{
																(yyval.ptr)->is_error = 1;
															}
														;}
    break;

  case 344:
#line 4728 "parser.y"
    {
															vector<treeNode> attr;
															add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
															add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
															(yyval.ptr) = create_AST_node((yyvsp[(2) - (3)].str) ,attr);
															if(!((yyvsp[(1) - (3)].ptr)->is_error || (yyvsp[(3) - (3)].ptr)->is_error)){
																//Semantic
																if((yyvsp[(3) - (3)].ptr)->int_val!=0)(yyval.ptr)->int_val = (yyvsp[(1) - (3)].ptr)->int_val / (yyvsp[(3) - (3)].ptr)->int_val;
															
																if((yyvsp[(1) - (3)].ptr)->isInit ==1 && (yyvsp[(3) - (3)].ptr)->isInit ==1) (yyval.ptr)->isInit = 1;
															
																string temp =multExpr((yyvsp[(1) - (3)].ptr)->type,(yyvsp[(3) - (3)].ptr)->type,'/');
																if(!temp.empty()){
																	(yyval.ptr)->type = temp;

																	if((yyvsp[(1) - (3)].ptr)->expType == 4 && (yyvsp[(3) - (3)].ptr)->expType == 4){
																		(yyval.ptr)->place = qid(to_string((yyval.ptr)->int_val), (yyvsp[(1) - (3)].ptr)->place.second);
																		(yyval.ptr)->expType = 4;
																	}
																	else{
																		if(temp == "int"){
																			(yyval.ptr)->type = "int" ;

																			//--3AC
																			qid q = newtemp("int");
																			(yyval.ptr)->place = q;
																			(yyval.ptr)->nextlist.clear();
																			emit(qid("/int", NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, q, -1);
																		}
																		else if(temp == "float"){
																			(yyval.ptr)->type = "float";

															// 				//--3AC
																			qid q = newtemp("float");
																			(yyval.ptr)->place = q;
																			(yyval.ptr)->nextlist.clear();
																			if(checkIfInteger((yyvsp[(1) - (3)].ptr)->type)){
																				qid q1 = newtemp((yyval.ptr)->type);
																				emit(qid("inttoreal", NULL), (yyvsp[(1) - (3)].ptr)->place, qid("", NULL), q1, -1);

																				emit(qid("/real", NULL), q1, (yyvsp[(3) - (3)].ptr)->place, q, -1);
																			}
																			else if(checkIfInteger((yyvsp[(3) - (3)].ptr)->type)){
																				qid q1 = newtemp((yyval.ptr)->type);
																				emit(qid("inttoreal", NULL), (yyvsp[(3) - (3)].ptr)->place, qid("", NULL), q1, -1);

																				emit(qid("/real", NULL), (yyvsp[(1) - (3)].ptr)->place, q1, q, -1);
																			}
																			else{
																				emit(qid("/real", NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, q, -1);
																			}
																		}
																	}
																	(yyval.ptr)->nextlist.clear();
																}
																else{
																	yyerror(("Incompatible types \'" + (yyvsp[(1) - (3)].ptr)->type + "\' and \'" + (yyvsp[(3) - (3)].ptr)->type + "\' for / operator").c_str());
																	(yyval.ptr)->is_error = 1;
																}
																}
															else{
																(yyval.ptr)->is_error = 1;
															}
														;}
    break;

  case 345:
#line 4792 "parser.y"
    {
														vector<treeNode> attr;
														add_attribute(attr, (yyvsp[(1) - (3)].ptr), "", 1);
														add_attribute(attr, (yyvsp[(3) - (3)].ptr), "", 1);
														(yyval.ptr) = create_AST_node((yyvsp[(2) - (3)].str) ,attr);
														if(!((yyvsp[(1) - (3)].ptr)->is_error || (yyvsp[(3) - (3)].ptr)->is_error)){
															//Semantic
															    if((yyvsp[(1) - (3)].ptr)->isInit ==1 && (yyvsp[(3) - (3)].ptr)->isInit ==1) (yyval.ptr)->isInit = 1;
																
															if((yyvsp[(3) - (3)].ptr)->int_val!=0)(yyval.ptr)->int_val = (yyvsp[(1) - (3)].ptr)->int_val % (yyvsp[(3) - (3)].ptr)->int_val;
															string temp =multExpr((yyvsp[(1) - (3)].ptr)->type,(yyvsp[(3) - (3)].ptr)->type,'%');
															if(temp == "int"){
																(yyval.ptr)->type = "int" ;

																//--3AC
																if((yyvsp[(1) - (3)].ptr)->expType == 4 && (yyvsp[(3) - (3)].ptr)->expType == 4){
																	(yyval.ptr)->place = qid(to_string((yyval.ptr)->int_val), (yyvsp[(1) - (3)].ptr)->place.second);
																	(yyval.ptr)->expType = 4;
																}
																else{
																	qid q = newtemp("int");
																	(yyval.ptr)->place = q;
																	emit(qid("%", NULL), (yyvsp[(1) - (3)].ptr)->place, (yyvsp[(3) - (3)].ptr)->place, q, -1);
																}
																(yyval.ptr)->nextlist.clear();

															}
															else{
																yyerror(("Incompatible types \'" + (yyvsp[(1) - (3)].ptr)->type + "\' and \'" + (yyvsp[(3) - (3)].ptr)->type + "\' for % operator").c_str());
																(yyval.ptr)->is_error = 1;
															}
														}
														else{
															(yyval.ptr)->is_error = 1;
														}
													;}
    break;

  case 346:
#line 4830 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 347:
#line 4831 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 348:
#line 4832 "parser.y"
    {
														vector<treeNode> attr;
														add_attribute(attr, create_AST_leaf((yyvsp[(1) - (2)].str), ""), "", 1);
														add_attribute(attr, (yyvsp[(2) - (2)].ptr), "", 1);
														(yyval.ptr) = create_AST_node("unary_exp_plus",attr);
														(yyval.ptr)->place = qid("unary+", Lookup("+"));
													;}
    break;

  case 349:
#line 4839 "parser.y"
    {
													vector<treeNode> attr;
													add_attribute(attr, create_AST_leaf((yyvsp[(1) - (2)].str), ""), "", 1);
													add_attribute(attr, (yyvsp[(2) - (2)].ptr), "", 1);
													(yyval.ptr) = create_AST_node("unary_exp_minus",attr);
													(yyval.ptr)->place = qid("unary-", Lookup("-"));
												;}
    break;

  case 350:
#line 4846 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr); 
											// cout<<"unary "<<$1->dims.size()<<"\n";
												
												
												;}
    break;

  case 351:
#line 4851 "parser.y"
    {
										vector<treeNode> attr;
										add_attribute(attr, create_AST_leaf((yyvsp[(1) - (2)].str), ""), "", 1);
										add_attribute(attr, (yyvsp[(2) - (2)].ptr), "", 1);
										(yyval.ptr) = create_AST_node("unary_exp_tilde",attr);
										(yyval.ptr)->place = qid("~", Lookup("~"));
									;}
    break;

  case 352:
#line 4858 "parser.y"
    {
									vector<treeNode> attr;
									add_attribute(attr, create_AST_leaf((yyvsp[(1) - (2)].str), ""), "", 1);
									add_attribute(attr, create_AST_leaf((yyvsp[(1) - (2)].str), "NOT"), "", 1);
									(yyval.ptr) = create_AST_node("unary_exp_not",attr);
									(yyval.ptr)->place = qid("unary!", Lookup("!"));
								
								;}
    break;

  case 353:
#line 4869 "parser.y"
    {
		vector<treeNode> attr;
		add_attribute(attr, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node((yyvsp[(1) - (2)].str),attr);
		//Semantic
		
		if(!(yyvsp[(2) - (2)].ptr)->is_error && (yyvsp[(2) - (2)].ptr)->expType!=4){
			(yyval.ptr)->isInit = (yyvsp[(2) - (2)].ptr)->isInit;
			string temp = postfixExpr((yyvsp[(2) - (2)].ptr)->type,6);
			
			if(!temp.empty()){
				(yyval.ptr)->type = temp;
				(yyval.ptr)->int_val = (yyvsp[(2) - (2)].ptr)->int_val +1;

				//--3AC
				qid q = newtemp(temp);
				(yyval.ptr)->place = q;
				(yyval.ptr)->nextlist.clear();
				emit(qid("++P", NULL), (yyvsp[(2) - (2)].ptr)->place, qid("", NULL), q, -1);
			}
			else{
				yyerror("Increment not defined for this type");
				(yyval.ptr)->is_error = 1;
			}
		}
		else{
			if((yyvsp[(2) - (2)].ptr)->expType==4){
				yyerror("constant expression cannot be used as lvalue");
			}
			(yyval.ptr)->is_error = 1;
		}
	;}
    break;

  case 354:
#line 4903 "parser.y"
    {
		vector<treeNode> attr;
		add_attribute(attr, (yyvsp[(2) - (2)].ptr), "", 1);
		(yyval.ptr) = create_AST_node((yyvsp[(1) - (2)].str),attr);
		//Semantic
		if(!(yyvsp[(2) - (2)].ptr)->is_error && (yyvsp[(2) - (2)].ptr)->expType!=4){
			(yyval.ptr)->isInit = (yyvsp[(2) - (2)].ptr)->isInit;
			string temp = postfixExpr((yyvsp[(2) - (2)].ptr)->type,7);
			if(!temp.empty()){
				(yyval.ptr)->type = temp;
				(yyval.ptr)->int_val = (yyvsp[(2) - (2)].ptr)->int_val -1;

				//--3AC
				qid q = newtemp(temp);
				(yyval.ptr)->place = q;
				(yyval.ptr)->nextlist.clear();
				emit(qid("--P", NULL), (yyvsp[(2) - (2)].ptr)->place, qid("", NULL), q, -1);
			}
			else{
				yyerror("Decrement not defined for this type");
			}
		}
		else{
			if((yyvsp[(2) - (2)].ptr)->expType==4){
				yyerror("constant expression cannot be used as lvalue");
			}
			(yyval.ptr)->is_error = 1;
		}
	;}
    break;

  case 355:
#line 4934 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 356:
#line 4935 "parser.y"
    {
													(yyval.ptr) = (yyvsp[(1) - (1)].ptr);
												;}
    break;

  case 357:
#line 4940 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 358:
#line 4941 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 359:
#line 4942 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 360:
#line 4943 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;

  case 361:
#line 4946 "parser.y"
    {  // TYPECHECK
						vector<treeNode> attr;
						add_attribute(attr, (yyvsp[(1) - (2)].ptr), "", 1);
						(yyval.ptr) = create_AST_node((yyvsp[(2) - (2)].str), attr);
						//Semantics
						(yyval.ptr)->isInit = (yyvsp[(1) - (2)].ptr)->isInit;
						if(!(yyvsp[(1) - (2)].ptr)->is_error && (yyvsp[(1) - (2)].ptr)->expType!=4){
							string temp = postfixExpr((yyvsp[(1) - (2)].ptr)->type,6);
							if(!temp.empty()){
								(yyval.ptr)->type = temp;
								(yyval.ptr)->int_val = (yyvsp[(1) - (2)].ptr)->int_val + 1; // increment value 

						 		//--3AC

						 		qid q = newtemp(temp);
						 		(yyval.ptr)->place = q;
						 		(yyval.ptr)->nextlist.clear();
						 		emit(qid("++S", NULL), (yyvsp[(1) - (2)].ptr)->place, qid("", NULL), q, -1);
						 	}
							else{
								yyerror("Increment not defined for this type");
								(yyval.ptr)->is_error = 1;
							}
						}
						else{
							if((yyvsp[(1) - (2)].ptr)->expType==4){
								yyerror("constant expression cannot be used as lvalue");
							}

							(yyval.ptr)->is_error = 1;
						}
				;}
    break;

  case 362:
#line 4979 "parser.y"
    { // TYPECHECK
						vector<treeNode> attr;
						add_attribute(attr, (yyvsp[(1) - (2)].ptr), "", 1);
						(yyval.ptr) = create_AST_node((yyvsp[(2) - (2)].str), attr);
						//Semantics
						if(!(yyvsp[(1) - (2)].ptr)->is_error && (yyvsp[(1) - (2)].ptr)->expType!=4){
							(yyval.ptr)->isInit = (yyvsp[(1) - (2)].ptr)->isInit;
							string temp = postfixExpr((yyvsp[(1) - (2)].ptr)->type,7);
							if(!temp.empty()){
								(yyval.ptr)->type = temp;
								(yyval.ptr)->int_val = (yyvsp[(1) - (2)].ptr)->int_val - 1; // decrement value 

								//--3AC

								qid q = newtemp(temp);
								(yyval.ptr)->place = q;
								(yyval.ptr)->nextlist.clear();
								emit(qid("--S", NULL), (yyvsp[(1) - (2)].ptr)->place, qid("", NULL), q, -1);

							}
							else{
								yyerror("Decrement not defined for this type");
								(yyval.ptr)->is_error = 1;
							}
						}
						else{
							if((yyvsp[(1) - (2)].ptr)->expType==4){
								yyerror("constant expression cannot be used as lvalue");
							}
							(yyval.ptr)->is_error = 1;
						}
				;}
    break;

  case 363:
#line 5013 "parser.y"
    { // TYPECASTING	
		vector<treeNode> attr;
		add_attribute(attr, (yyvsp[(2) - (5)].ptr), "", 1);
		add_attribute(attr, (yyvsp[(3) - (5)].ptr), "", 1);
		add_attribute(attr, (yyvsp[(5) - (5)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("cast_Expr1" ,attr);
		
		// $$->type = $2->type;
		// $$->isInit = $5->isInit;
		if(!((yyvsp[(2) - (5)].ptr)->is_error || (yyvsp[(5) - (5)].ptr)->is_error)){
			//Semantic
			(yyval.ptr)->type = (yyvsp[(2) - (5)].ptr)->type;
			(yyval.ptr)->isInit = (yyvsp[(5) - (5)].ptr)->isInit;

			//--3AC
			// qid q = newtemp($$->type);
			(yyval.ptr)->place = (yyvsp[(5) - (5)].ptr)->place;
			(yyval.ptr)->place.second->type = (yyvsp[(2) - (5)].ptr)->type;
			(yyvsp[(5) - (5)].ptr)->nextlist.clear();
			// cout<<"In cast\n";
		}
		else{
			// cout<<"NOT IN cast\n";
			(yyval.ptr)->is_error = 1;
		}
	;}
    break;

  case 364:
#line 5040 "parser.y"
    {
		vector<treeNode> attr;
		add_attribute(attr, (yyvsp[(2) - (4)].ptr), "", 1);
		add_attribute(attr, (yyvsp[(4) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("cast_Expr3" ,attr);

		// $$->type = $2->type;
		// $$->isInit = $4->isInit;
		if(!((yyvsp[(2) - (4)].ptr)->is_error || (yyvsp[(4) - (4)].ptr)->is_error)){
			//Semantic
			(yyval.ptr)->type = (yyvsp[(2) - (4)].ptr)->type;
			(yyval.ptr)->isInit = (yyvsp[(4) - (4)].ptr)->isInit;
			// cout<<"In castExpr"<<endl;

			//--3AC
			// qid q = newtemp($$->type);
			(yyval.ptr)->place = (yyvsp[(4) - (4)].ptr)->place;
			(yyval.ptr)->place.second->type = (yyvsp[(2) - (4)].ptr)->type;
			(yyvsp[(4) - (4)].ptr)->nextlist.clear();
		}
		else{
			(yyval.ptr)->is_error = 1;
		}
	;}
    break;

  case 365:
#line 5066 "parser.y"
    {
		vector<treeNode> attr;
		add_attribute(attr, (yyvsp[(2) - (4)].ptr), "", 1);
		add_attribute(attr, (yyvsp[(4) - (4)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("cast_Expr2" ,attr);
	;}
    break;

  case 366:
#line 5073 "parser.y"
    {
		vector<treeNode> attr;
		add_attribute(attr, (yyvsp[(2) - (5)].ptr), "", 1);
		add_attribute(attr, (yyvsp[(3) - (5)].ptr), "", 1);
		add_attribute(attr, (yyvsp[(5) - (5)].ptr), "", 1);
		(yyval.ptr) = create_AST_node("cast_Expr4" ,attr);
		
		// $$->type = $2->type;
		// $$->isInit = $5->isInit;
		if(!((yyvsp[(2) - (5)].ptr)->is_error || (yyvsp[(5) - (5)].ptr)->is_error)){
			//Semantic
			(yyval.ptr)->type = (yyvsp[(2) - (5)].ptr)->type;
			(yyval.ptr)->isInit = (yyvsp[(5) - (5)].ptr)->isInit;

			//--3AC
			// qid q = newtemp($$->type);
			(yyval.ptr)->place = (yyvsp[(5) - (5)].ptr)->place;
			(yyval.ptr)->place.second->type = (yyvsp[(2) - (5)].ptr)->type;
			(yyvsp[(5) - (5)].ptr)->nextlist.clear();
		}
		else{
			(yyval.ptr)->is_error = 1;
		}
	;}
    break;

  case 367:
#line 5100 "parser.y"
    {(yyval.ptr) = (yyvsp[(1) - (1)].ptr);;}
    break;


/* Line 1267 of yacc.c.  */
#line 9009 "parser.cpp"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}


#line 5103 "parser.y"


void help(){
	fprintf(stdout, "Usage Guidelines:\n");
	fprintf(stdout, "./ans [OPTIONS]\n");
	fprintf(stdout, "Where options are:\n");
	fprintf(stdout, "\t--help: For usage guidelines\n");
	fprintf(stdout, "\t-input <file>: Passes the input java file to the parser to be read.\n");
	fprintf(stdout, "\t-output <file>: Creates the dot script containing the AST in <file>\n");
}

bool check_fp(FILE* fp, char* name)
{
	if(fp == NULL){
		fprintf(stdout, "Error: Unable to open %s. Please retry.\n", name);
		return false;
	}
	else return true; //successfully opened file 

}

int main(int argc, char** argv) 

{
	char* output_dot_file = "graph.dot";
	char* input_java_file = "test.java";
	if(argc <= 1){
		fprintf(stdout, "Please pass arguments for input and output and retry.\n");
		return 1;
	}
	for(int i = 1; i<argc; i++){
		if(!strcmp(argv[i], "--help")){
			help();
			return 0;
		}
	}
	InitSymbolTable();
	for(int i=1;i<argc; ++i)
	{
		if(!strcmp(argv[i], "-input"))
		{
			if(i+1 >= argc || argv[i+1][0] == '-')
			{
				fprintf(stdout, "Error: Please add the input filename after \"-input\" and retry.\n");
				return 1; //error detected
			}
			else
			{
				input_java_file = argv[i+1]; //output file name
				i++;
			}
		}
		if(!strcmp(argv[i], "-output"))
		{
			if(i+1 >= argc || argv[i+1][0] == '-')
			{
				fprintf(stdout, "Error: Please add the output filename after \"-output\" and retry.\n");
				return 2; //error detected
			}
			else
			{
				output_dot_file = argv[i+1]; //output file name
				i++;
			}
		}
		if(!strcmp(argv[i], "-verbose")) verbose= true; //give better error messages 
	}
	yyin = fopen(input_java_file, "r"); // this opens the java input file
	dotfile = fopen(output_dot_file, "w"); // opens output dot file 
	if(!check_fp(yyin, input_java_file)) return 3;
	if(!check_fp(dotfile, output_dot_file)) return 4;
	fprintf(dotfile, "digraph AST {\n\tordering=out;\n");
    int column = 0;
	file = input_java_file;
	yyrestart(yyin); 
	InitSymbolTable();
	yyparse();
	printSymbolTable(&gst, "#Global_Symbol_Table#.csv");
	fprintf(dotfile, "}\n"); 	// Dot file has been completely written to 
	fclose(dotfile);
	if(!interrupt_compiler){
		print3AC_code();
		printSymbolTable(&gst, "#Global_Symbol_Table#.csv");
	}
	return 0;
}


void print_warning(){
	cout<<"\033[1;36mWarning: \033[0m";
}

int warning(const char* s) { 
	FILE *dupfile = fopen(curr_file, "r");
	int count = 1;

	char currline[512]; /* or other suitable maximum line size */
	while (fgets(currline, sizeof(currline), dupfile) != NULL) {
		if (count == yylineno){
			cout<<curr_file<<":"<<yylineno<<":"<<column+1-strlen(yytext)<<":: "<<currline;
			print_warning();
			cout<<s<<"\n\n";
			return -1;
		}
		else{
			count++;
		}
	}

	fclose(dupfile);
	return 1;
}



int yyerror(const char *s) { 
	interrupt_compiler = 1;
	FILE *duplicate_input_file = fopen(file, "r");
	int count = 1;
	if(!verbose)
	{
		fprintf(stderr, "Error on line number %d: %s\n",yylineno, s);
		exit(1);
	}
	//verbose error message prints entire line. 
	char input_line[512];  //possible maximum line size 
	while (fgets(input_line, sizeof(input_line), duplicate_input_file) != NULL) {
		if (count == yylineno){
			fprintf(stderr, "Error on line number:%d\n",yylineno);
			fprintf(stderr, "Error reported by parser: %s\n",s);
			fprintf(stderr, "Check error near line: %s\n",input_line);
			return 4;
		}
		else{
			count++;
		}
	}
	fclose(duplicate_input_file);
	return -1;
}


